import { delay, getDb, mutate, newId, nowIso, stamped } from "@/lib/mock-db";
import type { AttendanceSlot, ProgramSlug } from "@/types";

export interface AttendanceSummary {
  scheduled: number;
  attended: number;
  missed: number;
  excused: number;
  upcoming: number;
  rate: number;
  streak: number;
}

export const attendanceService = {
  async listForUser(userId: string): Promise<AttendanceSlot[]> {
    return delay(
      getDb()
        .slots.filter((s) => s.userId === userId)
        .sort((a, b) => a.scheduledAt.localeCompare(b.scheduledAt)),
    );
  },

  async listAll(programId?: ProgramSlug): Promise<AttendanceSlot[]> {
    const rows = getDb().slots.filter((s) => !programId || s.programId === programId);
    return delay(rows);
  },

  async summaryForUser(userId: string): Promise<AttendanceSummary> {
    const rows = getDb().slots.filter((s) => s.userId === userId);
    return delay(summarize(rows));
  },

  async checkIn(slotId: string): Promise<AttendanceSlot> {
    await delay(null, 220);
    return mutate((db) => {
      const slot = db.slots.find((s) => s.id === slotId);
      if (!slot) throw new Error("Session not found");
      slot.status = "attended";
      slot.checkedInAt = nowIso();
      slot.updatedAt = nowIso();
      return slot;
    });
  },

  async setStatus(slotId: string, status: AttendanceSlot["status"]): Promise<AttendanceSlot> {
    await delay(null, 180);
    return mutate((db) => {
      const slot = db.slots.find((s) => s.id === slotId);
      if (!slot) throw new Error("Session not found");
      slot.status = status;
      if (status === "attended") slot.checkedInAt = nowIso();
      slot.updatedAt = nowIso();
      return slot;
    });
  },

  async create(input: Omit<AttendanceSlot, "id" | "createdAt" | "updatedAt">): Promise<AttendanceSlot> {
    await delay(null, 200);
    return mutate((db) => {
      const slot = stamped({ id: newId("slt"), ...input }) as AttendanceSlot;
      db.slots.push(slot);
      return slot;
    });
  },
};

export function summarize(rows: AttendanceSlot[]): AttendanceSummary {
  const past = rows.filter((s) => s.status !== "upcoming");
  const attended = past.filter((s) => s.status === "attended").length;
  const missed = past.filter((s) => s.status === "missed").length;
  const excused = past.filter((s) => s.status === "excused").length;
  const counted = attended + missed;
  const sorted = [...past].sort((a, b) => b.scheduledAt.localeCompare(a.scheduledAt));
  let streak = 0;
  for (const s of sorted) {
    if (s.status === "attended") streak += 1;
    else if (s.status === "missed") break;
  }
  return {
    scheduled: past.length,
    attended,
    missed,
    excused,
    upcoming: rows.filter((s) => s.status === "upcoming").length,
    rate: counted === 0 ? 0 : Math.round((attended / counted) * 100),
    streak,
  };
}

/** A session can be checked into from 30 minutes before start until it ends. */
export function withinCheckInWindow(slot: AttendanceSlot, now = new Date()): boolean {
  const start = new Date(slot.scheduledAt).getTime();
  const end = start + slot.durationMinutes * 60000;
  const t = now.getTime();
  return t >= start - 30 * 60000 && t <= end;
}
