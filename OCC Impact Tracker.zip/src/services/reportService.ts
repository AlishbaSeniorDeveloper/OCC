import Papa from "papaparse";
import { MISSION } from "@/data/programs";
import { delay, getDb, mutate, newId, nowIso, stamped } from "@/lib/mock-db";
import type { Report } from "@/types";

export interface ReportSection {
  heading: string;
  paragraphs?: string[];
  kpis?: { label: string; value: string }[];
  table?: { columns: string[]; rows: (string | number)[][] };
}

export interface ReportDocument {
  title: string;
  subtitle: string;
  generatedFor: string;
  dateRange: string;
  sections: ReportSection[];
}

const HUNTER: [number, number, number] = [53, 94, 59];
const GOLD: [number, number, number] = [201, 149, 44];
const CREAM: [number, number, number] = [247, 242, 234];
const INK: [number, number, number] = [34, 32, 29];
const SAGE: [number, number, number] = [143, 168, 139];

export const reportService = {
  async saved(): Promise<Report[]> {
    return delay([...getDb().reports].sort((a, b) => b.generatedAt.localeCompare(a.generatedAt)));
  },

  async record(input: Omit<Report, "id" | "createdAt" | "updatedAt" | "generatedAt">): Promise<Report> {
    await delay(null, 150);
    return mutate((db) => {
      const report = stamped({ id: newId("rpt"), generatedAt: nowIso(), ...input }) as Report;
      db.reports.unshift(report);
      return report;
    });
  },

  async remove(id: string): Promise<void> {
    await delay(null, 150);
    mutate((db) => {
      db.reports = db.reports.filter((r) => r.id !== id);
    });
  },

  async exportCsv(fileName: string, rows: Record<string, string | number>[]): Promise<void> {
    const csv = Papa.unparse(rows);
    downloadBlob(new Blob([csv], { type: "text/csv;charset=utf-8;" }), `${slug(fileName)}.csv`);
    await delay(null, 120);
  },

  async exportPdf(doc: ReportDocument): Promise<void> {
    const { jsPDF } = await import("jspdf");
    const autoTable = (await import("jspdf-autotable")).default;

    const pdf = new jsPDF({ unit: "pt", format: "letter" });
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();

    // Page background
    const paintBackground = () => {
      pdf.setFillColor(...CREAM);
      pdf.rect(0, 0, pageWidth, pageHeight, "F");
    };
    paintBackground();

    // Hunter green header band
    pdf.setFillColor(...HUNTER);
    pdf.rect(0, 0, pageWidth, 96, "F");
    pdf.setTextColor(247, 242, 234);
    pdf.setFont("times", "bold");
    pdf.setFontSize(20);
    pdf.text("Ollivier Community Circle", 42, 40);
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(8.5);
    const missionLines = pdf.splitTextToSize(MISSION, pageWidth - 84);
    pdf.text(missionLines.slice(0, 2), 42, 58);

    let y = 128;
    pdf.setTextColor(...INK);
    pdf.setFont("times", "bold");
    pdf.setFontSize(22);
    pdf.text(doc.title, 42, y);
    y += 20;
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(10);
    pdf.setTextColor(90, 88, 82);
    pdf.text(`${doc.subtitle}  •  ${doc.dateRange}`, 42, y);
    y += 14;
    pdf.text(`Prepared for ${doc.generatedFor}`, 42, y);
    y += 22;

    for (const section of doc.sections) {
      if (y > pageHeight - 140) {
        pdf.addPage();
        paintBackground();
        y = 64;
      }
      pdf.setFont("times", "bold");
      pdf.setFontSize(14);
      pdf.setTextColor(...HUNTER);
      pdf.text(section.heading, 42, y);
      y += 6;
      pdf.setDrawColor(...SAGE);
      pdf.setLineWidth(0.75);
      pdf.line(42, y, pageWidth - 42, y);
      y += 18;

      if (section.kpis?.length) {
        let x = 42;
        for (const kpi of section.kpis) {
          pdf.setFont("times", "bold");
          pdf.setFontSize(20);
          pdf.setTextColor(...GOLD);
          pdf.text(kpi.value, x, y + 8);
          pdf.setFont("helvetica", "normal");
          pdf.setFontSize(7.5);
          pdf.setTextColor(120, 118, 110);
          pdf.text(kpi.label.toUpperCase(), x, y + 22);
          x += (pageWidth - 84) / Math.min(4, section.kpis.length);
          if (x > pageWidth - 100) {
            x = 42;
            y += 42;
          }
        }
        y += 46;
      }

      for (const paragraph of section.paragraphs ?? []) {
        pdf.setFont("helvetica", "normal");
        pdf.setFontSize(10);
        pdf.setTextColor(...INK);
        const lines = pdf.splitTextToSize(paragraph, pageWidth - 84);
        if (y + lines.length * 13 > pageHeight - 80) {
          pdf.addPage();
          paintBackground();
          y = 64;
        }
        pdf.text(lines, 42, y);
        y += lines.length * 13 + 8;
      }

      if (section.table && section.table.rows.length) {
        autoTable(pdf, {
          startY: y,
          head: [section.table.columns],
          body: section.table.rows.map((r) => r.map((c) => String(c))),
          margin: { left: 42, right: 42 },
          styles: { font: "helvetica", fontSize: 8.5, textColor: INK, cellPadding: 5 },
          headStyles: { fillColor: HUNTER, textColor: CREAM, font: "times", fontStyle: "bold", fontSize: 9.5 },
          alternateRowStyles: { fillColor: [243, 236, 225] },
          bodyStyles: { fillColor: [252, 250, 246] },
          didDrawPage: () => {
            /* keep the band on continuation pages */
          },
        });
        y = ((pdf as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable?.finalY ?? y) + 24;
      }
    }

    // Footer with page numbers
    const total = pdf.getNumberOfPages();
    for (let i = 1; i <= total; i++) {
      pdf.setPage(i);
      pdf.setDrawColor(...SAGE);
      pdf.setLineWidth(0.5);
      pdf.line(42, pageHeight - 46, pageWidth - 42, pageHeight - 46);
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(8);
      pdf.setTextColor(120, 118, 110);
      pdf.text(
        `Generated ${new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}  •  Ollivier Community Circle`,
        42,
        pageHeight - 30,
      );
      pdf.text(`Page ${i} of ${total}`, pageWidth - 42, pageHeight - 30, { align: "right" });
    }

    pdf.save(`${slug(doc.title)}.pdf`);
    await delay(null, 150);
  },
};

function slug(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function downloadBlob(blob: Blob, fileName: string) {
  if (typeof window === "undefined") return;
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
