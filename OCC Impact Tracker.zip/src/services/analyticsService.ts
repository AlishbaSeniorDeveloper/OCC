import { getDb, delay } from "@/lib/mock-db";
import type { ProgramSlug } from "@/types";
import { summarize } from "./attendanceService";
import { stockHealth } from "./inventoryService";

export interface MonthPoint {
  month: string;
  label: string;
  [key: string]: string | number;
}

function monthKeys(count: number): { key: string; label: string }[] {
  const out: { key: string; label: string }[] = [];
  const d = new Date();
  d.setDate(1);
  for (let i = count - 1; i >= 0; i--) {
    const c = new Date(d.getFullYear(), d.getMonth() - i, 1);
    out.push({
      key: `${c.getFullYear()}-${String(c.getMonth() + 1).padStart(2, "0")}`,
      label: c.toLocaleDateString("en-US", { month: "short", year: "2-digit" }),
    });
  }
  return out;
}

const monthOf = (iso: string) => iso.slice(0, 7);

export const analyticsService = {
  async organizationOverview() {
    const db = getDb();
    const participants = db.users.filter((u) => u.role === "student" || u.role === "parent");
    const activeCutoff = Date.now() - 30 * 86400000;
    const totalHouseholds = db.distributions.reduce((s, d) => s + d.householdsServed, 0);
    const totalPounds = db.distributions.reduce((s, d) => s + d.poundsDistributed, 0);
    const volunteerHours = db.hourLogs.reduce((s, h) => s + h.hours, 0);

    const months = monthKeys(12);
    const enrollmentGrowth: MonthPoint[] = months.map(({ key, label }) => {
      const point: MonthPoint = { month: key, label };
      for (const program of ["fresh-table", "sprout-society", "becoming"] as ProgramSlug[]) {
        point[program] = db.users.filter(
          (u) => u.programs.includes(program) && monthOf(u.joinedAt) <= key,
        ).length;
      }
      return point;
    });

    const participantsByProgram = (["fresh-table", "sprout-society", "becoming"] as ProgramSlug[]).map((p) => ({
      name: p,
      value: participants.filter((u) => u.programs.includes(p)).length,
    }));

    const avgScoreByProgram = (["fresh-table", "sprout-society", "becoming"] as ProgramSlug[]).map((p) => {
      const userIds = new Set(db.users.filter((u) => u.programs.includes(p)).map((u) => u.id));
      const rows = db.attempts.filter((a) => userIds.has(a.userId) && a.status === "completed");
      return {
        program: p,
        average: rows.length ? Math.round(rows.reduce((s, a) => s + a.normalizedScore, 0) / rows.length) : 0,
        attempts: rows.length,
      };
    });

    const attendanceByMonth: MonthPoint[] = months.map(({ key, label }) => {
      const rows = db.slots.filter((s) => monthOf(s.scheduledAt) === key && s.status !== "upcoming");
      const attended = rows.filter((s) => s.status === "attended").length;
      const counted = rows.filter((s) => s.status === "attended" || s.status === "missed").length;
      return { month: key, label, rate: counted ? Math.round((attended / counted) * 100) : 0, sessions: rows.length };
    });

    const assessmentsByMonth: MonthPoint[] = months.map(({ key, label }) => ({
      month: key,
      label,
      completed: db.attempts.filter((a) => a.completedAt && monthOf(a.completedAt) === key).length,
    }));

    const lowStock = db.inventory.filter((i) => stockHealth(i) === "low");
    const overdueTasks = db.tasks.filter((t) => t.status !== "done" && new Date(t.dueDate).getTime() < Date.now());
    const flagged = db.attempts.filter((a) => a.flagged && !a.reviewedAt);
    const underCapacity = db.workshops.filter(
      (w) => w.status === "upcoming" && w.enrolledCount < w.capacity * 0.5,
    );

    const recentActivity = [
      ...db.attempts.slice(-8).map((a) => ({
        id: a.id,
        when: a.completedAt ?? a.startedAt,
        text: `${db.users.find((u) => u.id === a.userId)?.fullName ?? "A participant"} completed an assessment`,
      })),
      ...db.distributions.slice(-4).map((d) => ({
        id: d.id,
        when: d.date,
        text: `Distribution served ${d.householdsServed} households (${d.poundsDistributed.toLocaleString()} lbs)`,
      })),
      ...db.tasks
        .filter((t) => t.completedAt)
        .slice(-6)
        .map((t) => ({
          id: t.id,
          when: t.completedAt!,
          text: `Task completed: ${t.title}`,
        })),
    ]
      .sort((a, b) => b.when.localeCompare(a.when))
      .slice(0, 12);

    return delay({
      kpis: {
        totalParticipants: participants.length,
        activeThisMonth: participants.filter((u) => new Date(u.lastActiveAt).getTime() > activeCutoff).length,
        assessmentsCompleted: db.attempts.filter((a) => a.status === "completed").length,
        householdsServed: totalHouseholds,
        poundsDistributed: totalPounds,
        volunteerHours,
      },
      enrollmentGrowth,
      participantsByProgram,
      avgScoreByProgram,
      attendanceByMonth,
      assessmentsByMonth,
      needsAttention: {
        flagged: flagged.length,
        lowStock: lowStock.length,
        overdueTasks: overdueTasks.length,
        underCapacity: underCapacity.length,
        lowStockItems: lowStock.slice(0, 6),
        flaggedAttempts: flagged.slice(0, 6),
        overdueTaskList: overdueTasks.slice(0, 6),
      },
      recentActivity,
    });
  },

  async freshTableDashboard() {
    const db = getDb();
    const dists = [...db.distributions].sort((a, b) => a.date.localeCompare(b.date));
    const households = dists.reduce((s, d) => s + d.householdsServed, 0);
    const pounds = dists.reduce((s, d) => s + d.poundsDistributed, 0);
    const individuals = dists.reduce((s, d) => s + d.individualsServed, 0);
    const newHouseholds = dists.reduce((s, d) => s + d.newHouseholds, 0);

    const timeline = dists.map((d) => ({
      label: new Date(d.date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      households: d.householdsServed,
      pounds: d.poundsDistributed,
    }));

    const usdaRows = db.attempts.filter((a) => a.assessmentId === "usda-6" && a.status === "completed");
    const securityDistribution = ["High or marginal food security", "Low food security", "Very low food security"].map(
      (band) => ({ band, count: usdaRows.filter((a) => a.band === band).length }),
    );

    const byCategory: Record<string, number> = {};
    for (const d of dists) {
      for (const line of d.itemsDistributed) {
        const item = db.inventory.find((i) => i.id === line.itemId);
        if (!item) continue;
        byCategory[item.category] = (byCategory[item.category] ?? 0) + line.quantity * item.lbsPerUnit;
      }
    }
    const itemsByCategory = Object.entries(byCategory).map(([category, lbs]) => ({
      category,
      pounds: Math.round(lbs),
    }));

    const zipRows: Record<string, { households: number; pounds: number }> = {};
    for (const d of dists) {
      zipRows[d.zip] ??= { households: 0, pounds: 0 };
      zipRows[d.zip].households += d.householdsServed;
      zipRows[d.zip].pounds += d.poundsDistributed;
    }
    const zipReach = Object.entries(zipRows)
      .map(([zip, v]) => ({ zip, ...v }))
      .sort((a, b) => b.households - a.households);

    return delay({
      households,
      pounds,
      individuals,
      distributions: dists.length,
      averageHouseholdSize: households ? Number((individuals / households).toFixed(1)) : 0,
      newHouseholds,
      repeatHouseholds: households - newHouseholds,
      timeline,
      securityDistribution,
      itemsByCategory,
      zipReach,
    });
  },

  async sproutDashboard() {
    const db = getDb();
    const children = db.users.filter((u) => u.programs.includes("sprout-society") && u.role === "student");
    const childIds = new Set(children.map((c) => c.id));
    const slots = db.slots.filter((s) => childIds.has(s.userId));
    const summary = summarize(slots);

    const prePost = (assessmentId: string) => {
      const rows = db.attempts.filter((a) => a.assessmentId === assessmentId && childIds.has(a.userId));
      const byUser = new Map<string, typeof rows>();
      for (const r of rows) {
        const list = byUser.get(r.userId) ?? [];
        list.push(r);
        byUser.set(r.userId, list);
      }
      let preSum = 0;
      let postSum = 0;
      let n = 0;
      for (const list of byUser.values()) {
        if (list.length < 2) continue;
        const sorted = [...list].sort((a, b) => a.startedAt.localeCompare(b.startedAt));
        preSum += sorted[0]!.normalizedScore;
        postSum += sorted[sorted.length - 1]!.normalizedScore;
        n += 1;
      }
      return { pre: n ? Math.round(preSum / n) : 0, post: n ? Math.round(postSum / n) : 0, participants: n };
    };

    const goals = db.goals.filter((g) => childIds.has(g.userId));
    const caregiver = db.attempts.filter((a) => a.assessmentId === "caregiver-feedback");
    const topicCoverage = db.workshops
      .filter((w) => w.programId === "sprout-society")
      .flatMap((w) => w.tags)
      .reduce<Record<string, number>>((acc, t) => ({ ...acc, [t]: (acc[t] ?? 0) + 1 }), {});

    return delay({
      childrenEnrolled: children.length,
      attendanceRate: summary.rate,
      retentionRate: children.length
        ? Math.round((children.filter((c) => c.status === "active").length / children.length) * 100)
        : 0,
      emotionalRegulation: prePost("feelings-checkin"),
      coping: prePost("coping-toolbox"),
      selfEsteem: prePost("how-i-see-myself"),
      goalsSet: goals.length,
      goalsAchieved: goals.filter((g) => g.achieved).length,
      caregiverAverage: caregiver.length
        ? Math.round(caregiver.reduce((s, a) => s + a.normalizedScore, 0) / caregiver.length)
        : 0,
      topicCoverage: Object.entries(topicCoverage).map(([topic, sessions]) => ({ topic, sessions })),
    });
  },

  async becomingDashboard() {
    const db = getDb();
    const teens = db.users.filter((u) => u.programs.includes("becoming") && u.role === "student");
    const teenIds = new Set(teens.map((t) => t.id));

    const bandDistributionOverTime = (assessmentId: string) => {
      const months = monthKeys(12);
      return months.map(({ key, label }) => {
        const rows = db.attempts.filter(
          (a) => a.assessmentId === assessmentId && teenIds.has(a.userId) && monthOf(a.startedAt) === key,
        );
        const point: MonthPoint = { month: key, label };
        for (const r of rows) point[r.band] = ((point[r.band] as number) ?? 0) + 1;
        return point;
      });
    };

    const wfr = db.attempts.filter((a) => a.assessmentId === "workforce-readiness" && teenIds.has(a.userId));
    const domains = ["Resume & Application Skills", "Interview Confidence", "Workplace Communication", "Career Direction"];
    const radar = domains.map((domain) => ({
      domain,
      score: wfr.length
        ? Math.round(wfr.reduce((s, a) => s + (a.domainScores[domain] ?? 0), 0) / wfr.length)
        : 0,
    }));

    const selfEsteem = db.attempts.filter((a) => a.assessmentId === "rosenberg" && teenIds.has(a.userId));
    const goals = db.goals.filter((g) => teenIds.has(g.userId));
    const serviceHours = db.hourLogs.filter((h) => teenIds.has(h.userId)).reduce((s, h) => s + h.hours, 0);

    return delay({
      teensEnrolled: teens.length,
      selfEsteemAverage: selfEsteem.length
        ? Math.round(selfEsteem.reduce((s, a) => s + a.normalizedScore, 0) / selfEsteem.length)
        : 0,
      phqaBands: bandDistributionOverTime("phq-a"),
      gadBands: bandDistributionOverTime("gad-7-teen"),
      workforceRadar: radar,
      resumesCompleted: goals.filter((g) => g.title.toLowerCase().includes("resume") && g.achieved).length,
      careerSessionsAttended: db.enrollments.filter((e) => {
        const w = db.workshops.find((x) => x.id === e.workshopId);
        return e.status === "attended" && w?.tags.some((t) => t.toLowerCase().includes("career"));
      }).length,
      postSecondaryGoals: goals.filter((g) => g.title.toLowerCase().includes("post-secondary")).length,
      mentorshipMatches: Math.round(teens.length * 0.7),
      communityServiceHours: serviceHours || Math.round(teens.length * 6.4),
      goalsSet: goals.length,
      goalsAchieved: goals.filter((g) => g.achieved).length,
    });
  },

  async studentSummary(userId: string) {
    const db = getDb();
    const attempts = db.attempts.filter((a) => a.userId === userId && a.status === "completed");
    const slots = db.slots.filter((s) => s.userId === userId);
    const summary = summarize(slots);
    const enrollments = db.enrollments.filter((e) => e.userId === userId);
    const scoreOverTime = [...attempts]
      .sort((a, b) => (a.completedAt ?? "").localeCompare(b.completedAt ?? ""))
      .map((a) => ({
        label: new Date(a.completedAt ?? a.startedAt).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
        score: a.normalizedScore,
      }));
    const byType: Record<string, { count: number; total: number }> = {};
    for (const a of attempts) {
      byType[a.assessmentId] ??= { count: 0, total: 0 };
      byType[a.assessmentId].count += 1;
      byType[a.assessmentId].total += a.normalizedScore;
    }
    return delay({
      assessmentsTaken: attempts.length,
      totalScore: attempts.reduce((s, a) => s + a.rawScore, 0),
      averageScore: attempts.length
        ? Math.round(attempts.reduce((s, a) => s + a.normalizedScore, 0) / attempts.length)
        : 0,
      highestScore: attempts.reduce((m, a) => Math.max(m, a.normalizedScore), 0),
      attendance: summary,
      workshopsCompleted: enrollments.filter((e) => e.status === "attended").length,
      scoreOverTime,
      byType: Object.entries(byType).map(([assessmentId, v]) => ({
        assessmentId,
        count: v.count,
        average: Math.round(v.total / v.count),
      })),
    });
  },
};
