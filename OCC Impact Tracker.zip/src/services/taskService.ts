import { delay, getDb, mutate, newId, nowIso, stamped } from "@/lib/mock-db";
import type { Task, TaskComment } from "@/types";

export const taskService = {
  async listForUser(userId: string): Promise<Task[]> {
    return delay(
      getDb()
        .tasks.filter((t) => t.assignedTo === userId)
        .sort((a, b) => a.dueDate.localeCompare(b.dueDate)),
    );
  },

  async listAll(): Promise<Task[]> {
    return delay([...getDb().tasks].sort((a, b) => a.dueDate.localeCompare(b.dueDate)));
  },

  async get(id: string): Promise<Task | null> {
    return delay(getDb().tasks.find((t) => t.id === id) ?? null);
  },

  async create(input: Omit<Task, "id" | "createdAt" | "updatedAt" | "comments" | "attachments"> & { comments?: TaskComment[] }): Promise<Task> {
    await delay(null, 280);
    return mutate((db) => {
      const task = stamped({ id: newId("tsk"), attachments: [], comments: [], ...input }) as Task;
      db.tasks.push(task);
      db.notifications.unshift(
        stamped({
          id: newId("ntf"),
          userId: task.assignedTo,
          type: "task" as const,
          title: "A task was assigned to you",
          body: task.title,
          read: false,
          linkTo: "/tasks",
        }) as never,
      );
      return task;
    });
  },

  async bulkCreate(base: Omit<Task, "id" | "createdAt" | "updatedAt" | "comments" | "attachments" | "assignedTo">, userIds: string[]): Promise<number> {
    await delay(null, 380);
    return mutate((db) => {
      for (const userId of userIds) {
        db.tasks.push(stamped({ id: newId("tsk"), attachments: [], comments: [], assignedTo: userId, ...base }) as Task);
        db.notifications.unshift(
          stamped({
            id: newId("ntf"),
            userId,
            type: "task" as const,
            title: "A task was assigned to you",
            body: base.title,
            read: false,
            linkTo: "/tasks",
          }) as never,
        );
      }
      return userIds.length;
    });
  },

  async updateStatus(id: string, status: Task["status"], completionNote?: string): Promise<Task> {
    await delay(null, 180);
    return mutate((db) => {
      const task = db.tasks.find((t) => t.id === id);
      if (!task) throw new Error("Task not found");
      task.status = status;
      task.updatedAt = nowIso();
      if (status === "done") {
        task.completedAt = nowIso();
        if (completionNote) task.completionNote = completionNote;
      } else {
        delete task.completedAt;
      }
      return task;
    });
  },

  async update(id: string, patch: Partial<Task>): Promise<Task> {
    await delay(null, 200);
    return mutate((db) => {
      const task = db.tasks.find((t) => t.id === id);
      if (!task) throw new Error("Task not found");
      Object.assign(task, patch, { updatedAt: nowIso() });
      return task;
    });
  },

  async addComment(id: string, authorId: string, body: string): Promise<Task> {
    await delay(null, 200);
    return mutate((db) => {
      const task = db.tasks.find((t) => t.id === id);
      if (!task) throw new Error("Task not found");
      task.comments.push({ id: newId("cmt"), authorId, body, createdAt: nowIso() });
      task.updatedAt = nowIso();
      return task;
    });
  },

  async addAttachment(id: string, fileName: string): Promise<Task> {
    await delay(null, 200);
    return mutate((db) => {
      const task = db.tasks.find((t) => t.id === id);
      if (!task) throw new Error("Task not found");
      task.attachments.push(fileName);
      task.updatedAt = nowIso();
      return task;
    });
  },

  async remove(id: string): Promise<void> {
    await delay(null, 180);
    mutate((db) => {
      db.tasks = db.tasks.filter((t) => t.id !== id);
    });
  },
};

export function isOverdue(task: Task): boolean {
  return task.status !== "done" && new Date(task.dueDate).getTime() < Date.now();
}
