import { delay, getDb, mutate, newId, nowIso, stamped } from "@/lib/mock-db";
import type { Distribution, InventoryItem, InventoryTransaction } from "@/types";

export type StockHealth = "healthy" | "watch" | "low";

export function stockHealth(item: InventoryItem): StockHealth {
  if (item.quantityOnHand >= item.parLevel) return "healthy";
  if (item.quantityOnHand >= item.reorderPoint) return "watch";
  return "low";
}

export interface RestockLine {
  itemId: string;
  quantity: number;
  source: string;
  notes: string;
  occurredAt: string;
}

export const inventoryService = {
  async list(): Promise<InventoryItem[]> {
    return delay([...getDb().inventory].sort((a, b) => a.name.localeCompare(b.name)));
  },

  async get(id: string): Promise<InventoryItem | null> {
    return delay(getDb().inventory.find((i) => i.id === id) ?? null);
  },

  async transactions(itemId?: string): Promise<InventoryTransaction[]> {
    const rows = getDb().transactions.filter((t) => !itemId || t.itemId === itemId);
    return delay([...rows].sort((a, b) => b.occurredAt.localeCompare(a.occurredAt)));
  },

  async submitRestockBatch(lines: RestockLine[], staffId: string): Promise<number> {
    await delay(null, 400);
    return mutate((db) => {
      for (const line of lines) {
        const item = db.inventory.find((i) => i.id === line.itemId);
        if (!item) continue;
        item.quantityOnHand += line.quantity;
        item.lastRestockedAt = line.occurredAt;
        item.updatedAt = nowIso();
        db.transactions.unshift(
          stamped({
            id: newId("txn"),
            itemId: item.id,
            type: "restock" as const,
            quantity: line.quantity,
            unit: item.unit,
            staffId,
            notes: line.notes || `Received from ${line.source || "donation"}`,
            occurredAt: line.occurredAt,
            source: line.source,
          }) as InventoryTransaction,
        );
      }
      return lines.length;
    });
  },

  async recordDistribution(input: {
    lines: { itemId: string; quantity: number }[];
    staffId: string;
    eventId: string;
    householdsServed: number;
    individualsServed: number;
    volunteersPresent: number;
    zip: string;
    notes: string;
    occurredAt: string;
  }): Promise<Distribution> {
    await delay(null, 420);
    return mutate((db) => {
      let pounds = 0;
      for (const line of input.lines) {
        const item = db.inventory.find((i) => i.id === line.itemId);
        if (!item) continue;
        item.quantityOnHand = Math.max(0, item.quantityOnHand - line.quantity);
        item.updatedAt = nowIso();
        pounds += line.quantity * item.lbsPerUnit;
        db.transactions.unshift(
          stamped({
            id: newId("txn"),
            itemId: item.id,
            type: "distribution" as const,
            quantity: line.quantity,
            unit: item.unit,
            staffId: input.staffId,
            notes: input.notes || "Distribution",
            occurredAt: input.occurredAt,
          }) as InventoryTransaction,
        );
      }
      const dist = stamped({
        id: newId("dst"),
        eventId: input.eventId,
        date: input.occurredAt,
        householdsServed: input.householdsServed,
        individualsServed: input.individualsServed,
        poundsDistributed: Math.round(pounds),
        itemsDistributed: input.lines,
        volunteersPresent: input.volunteersPresent,
        notes: input.notes,
        zip: input.zip,
        newHouseholds: Math.round(input.householdsServed * 0.2),
      }) as Distribution;
      db.distributions.push(dist);
      return dist;
    });
  },

  async adjust(itemId: string, quantity: number, type: InventoryTransaction["type"], staffId: string, notes: string) {
    await delay(null, 240);
    return mutate((db) => {
      const item = db.inventory.find((i) => i.id === itemId);
      if (!item) throw new Error("Item not found");
      item.quantityOnHand = Math.max(0, item.quantityOnHand + (type === "restock" ? quantity : -quantity));
      item.updatedAt = nowIso();
      db.transactions.unshift(
        stamped({
          id: newId("txn"),
          itemId,
          type,
          quantity,
          unit: item.unit,
          staffId,
          notes,
          occurredAt: nowIso(),
        }) as InventoryTransaction,
      );
      return item;
    });
  },

  async updateParLevels(itemId: string, parLevel: number, reorderPoint: number): Promise<InventoryItem> {
    await delay(null, 200);
    return mutate((db) => {
      const item = db.inventory.find((i) => i.id === itemId);
      if (!item) throw new Error("Item not found");
      item.parLevel = parLevel;
      item.reorderPoint = reorderPoint;
      item.updatedAt = nowIso();
      return item;
    });
  },

  async distributions(): Promise<Distribution[]> {
    return delay([...getDb().distributions].sort((a, b) => b.date.localeCompare(a.date)));
  },
};
