import { delay, getDb, mutate, newId, nowIso, stamped } from "@/lib/mock-db";
import type { Event, Notification, ProgramSlug, VolunteerHourLog } from "@/types";

const RSVP_KEY = "occ_rsvps";

function readRsvps(): string[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(window.localStorage.getItem(RSVP_KEY) ?? "[]") as string[];
  } catch {
    return [];
  }
}

export const eventService = {
  async list(filters: { programId?: ProgramSlug; type?: Event["type"]; upcomingOnly?: boolean } = {}): Promise<Event[]> {
    let rows = [...getDb().events];
    if (filters.programId) rows = rows.filter((e) => e.programId === filters.programId);
    if (filters.type) rows = rows.filter((e) => e.type === filters.type);
    if (filters.upcomingOnly) rows = rows.filter((e) => new Date(e.startsAt).getTime() >= Date.now());
    return delay(rows.sort((a, b) => a.startsAt.localeCompare(b.startsAt)));
  },

  async get(id: string): Promise<Event | null> {
    return delay(getDb().events.find((e) => e.id === id) ?? null);
  },

  async myRsvps(): Promise<string[]> {
    return delay(readRsvps());
  },

  async rsvp(eventId: string): Promise<void> {
    await delay(null, 220);
    mutate((db) => {
      const event = db.events.find((e) => e.id === eventId);
      if (event) event.rsvpCount += 1;
    });
    if (typeof window !== "undefined") {
      const list = new Set(readRsvps());
      list.add(eventId);
      window.localStorage.setItem(RSVP_KEY, JSON.stringify([...list]));
    }
  },

  async cancelRsvp(eventId: string): Promise<void> {
    await delay(null, 200);
    mutate((db) => {
      const event = db.events.find((e) => e.id === eventId);
      if (event) event.rsvpCount = Math.max(0, event.rsvpCount - 1);
    });
    if (typeof window !== "undefined") {
      const list = readRsvps().filter((id) => id !== eventId);
      window.localStorage.setItem(RSVP_KEY, JSON.stringify(list));
    }
  },

  async create(input: Omit<Event, "id" | "createdAt" | "updatedAt" | "rsvpCount">): Promise<Event> {
    await delay(null, 300);
    return mutate((db) => {
      const event = stamped({ id: newId("evt"), rsvpCount: 0, ...input }) as Event;
      db.events.push(event);
      return event;
    });
  },

  async update(id: string, patch: Partial<Event>): Promise<Event> {
    await delay(null, 240);
    return mutate((db) => {
      const event = db.events.find((e) => e.id === id);
      if (!event) throw new Error("Event not found");
      Object.assign(event, patch, { updatedAt: nowIso() });
      return event;
    });
  },

  async remove(id: string): Promise<void> {
    await delay(null, 200);
    mutate((db) => {
      db.events = db.events.filter((e) => e.id !== id);
    });
  },

  /* Volunteer hours */
  async hoursForUser(userId: string): Promise<VolunteerHourLog[]> {
    return delay(
      getDb()
        .hourLogs.filter((h) => h.userId === userId)
        .sort((a, b) => b.date.localeCompare(a.date)),
    );
  },

  async allHours(): Promise<VolunteerHourLog[]> {
    return delay([...getDb().hourLogs]);
  },

  async logHours(input: { userId: string; eventId?: string; hours: number; activity: string; date: string }): Promise<VolunteerHourLog> {
    await delay(null, 260);
    return mutate((db) => {
      const log = stamped({ id: newId("hrs"), ...input }) as VolunteerHourLog;
      db.hourLogs.unshift(log);
      return log;
    });
  },
};

export const notificationService = {
  async listForUser(userId: string): Promise<Notification[]> {
    return delay(
      getDb()
        .notifications.filter((n) => n.userId === userId)
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
    );
  },

  async markRead(id: string): Promise<void> {
    mutate((db) => {
      const n = db.notifications.find((x) => x.id === id);
      if (n) n.read = true;
    });
    await delay(null, 80);
  },

  async markAllRead(userId: string): Promise<void> {
    mutate((db) => {
      db.notifications.filter((n) => n.userId === userId).forEach((n) => (n.read = true));
    });
    await delay(null, 120);
  },
};
