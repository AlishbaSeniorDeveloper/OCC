import { delay, getDb, mutate, newId, nowIso, stamped } from "@/lib/mock-db";
import type { Audience, ProgramSlug, Workshop, WorkshopEnrollment } from "@/types";

export const workshopService = {
  async list(filters: { programId?: ProgramSlug; audience?: Audience; status?: Workshop["status"] } = {}): Promise<Workshop[]> {
    let rows = [...getDb().workshops];
    if (filters.programId) rows = rows.filter((w) => w.programId === filters.programId);
    if (filters.audience) rows = rows.filter((w) => w.audience === filters.audience);
    if (filters.status) rows = rows.filter((w) => w.status === filters.status);
    return delay(rows.sort((a, b) => b.startsAt.localeCompare(a.startsAt)));
  },

  async get(id: string): Promise<Workshop | null> {
    return delay(getDb().workshops.find((w) => w.id === id) ?? null);
  },

  async enrollmentsForUser(userId: string): Promise<WorkshopEnrollment[]> {
    return delay(getDb().enrollments.filter((e) => e.userId === userId));
  },

  async roster(workshopId: string): Promise<WorkshopEnrollment[]> {
    return delay(getDb().enrollments.filter((e) => e.workshopId === workshopId));
  },

  async allEnrollments(): Promise<WorkshopEnrollment[]> {
    return delay([...getDb().enrollments]);
  },

  async register(workshopId: string, userId: string): Promise<WorkshopEnrollment> {
    await delay(null, 260);
    return mutate((db) => {
      const workshop = db.workshops.find((w) => w.id === workshopId);
      if (!workshop) throw new Error("Workshop not found");
      if (workshop.enrolledCount >= workshop.capacity) throw new Error("This workshop is full.");
      const existing = db.enrollments.find((e) => e.workshopId === workshopId && e.userId === userId);
      if (existing) return existing;
      const enrollment = stamped({
        id: newId("enr"),
        workshopId,
        userId,
        status: "registered" as const,
      }) as WorkshopEnrollment;
      db.enrollments.push(enrollment);
      workshop.enrolledCount += 1;
      return enrollment;
    });
  },

  async cancel(enrollmentId: string): Promise<void> {
    await delay(null, 200);
    mutate((db) => {
      const idx = db.enrollments.findIndex((e) => e.id === enrollmentId);
      if (idx < 0) return;
      const [removed] = db.enrollments.splice(idx, 1);
      const workshop = db.workshops.find((w) => w.id === removed?.workshopId);
      if (workshop) workshop.enrolledCount = Math.max(0, workshop.enrolledCount - 1);
    });
  },

  async markAttendance(enrollmentId: string, status: WorkshopEnrollment["status"]): Promise<WorkshopEnrollment> {
    await delay(null, 160);
    return mutate((db) => {
      const e = db.enrollments.find((x) => x.id === enrollmentId);
      if (!e) throw new Error("Enrollment not found");
      e.status = status;
      e.updatedAt = nowIso();
      return e;
    });
  },

  async bulkMarkAttendance(workshopId: string, userIds: string[]): Promise<number> {
    await delay(null, 300);
    return mutate((db) => {
      const set = new Set(userIds);
      let n = 0;
      for (const e of db.enrollments) {
        if (e.workshopId === workshopId && set.has(e.userId)) {
          e.status = "attended";
          e.updatedAt = nowIso();
          n += 1;
        }
      }
      return n;
    });
  },

  async submitFeedback(enrollmentId: string, rating: number, comment: string): Promise<WorkshopEnrollment> {
    await delay(null, 260);
    return mutate((db) => {
      const e = db.enrollments.find((x) => x.id === enrollmentId);
      if (!e) throw new Error("Enrollment not found");
      e.feedbackRating = rating;
      e.feedbackComment = comment;
      e.updatedAt = nowIso();
      return e;
    });
  },

  async create(input: Omit<Workshop, "id" | "createdAt" | "updatedAt" | "enrolledCount">): Promise<Workshop> {
    await delay(null, 300);
    return mutate((db) => {
      const w = stamped({ id: newId("wsp"), enrolledCount: 0, ...input }) as Workshop;
      db.workshops.push(w);
      return w;
    });
  },

  async update(id: string, patch: Partial<Workshop>): Promise<Workshop> {
    await delay(null, 240);
    return mutate((db) => {
      const w = db.workshops.find((x) => x.id === id);
      if (!w) throw new Error("Workshop not found");
      Object.assign(w, patch, { updatedAt: nowIso() });
      return w;
    });
  },

  async remove(id: string): Promise<void> {
    await delay(null, 200);
    mutate((db) => {
      db.workshops = db.workshops.filter((w) => w.id !== id);
      db.enrollments = db.enrollments.filter((e) => e.workshopId !== id);
    });
  },
};
