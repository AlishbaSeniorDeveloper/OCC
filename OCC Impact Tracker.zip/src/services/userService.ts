import { delay, getDb, mutate, newId, nowIso, stamped } from "@/lib/mock-db";
import type { ProgramSlug, Role, User } from "@/types";

export interface UserFilters {
  role?: Role | "all";
  program?: ProgramSlug | "all";
  status?: User["status"] | "all";
  ageBand?: "under12" | "12to18" | "adult" | "all";
  search?: string;
  flaggedOnly?: boolean;
}

export const userService = {
  async list(filters: UserFilters = {}): Promise<User[]> {
    const db = getDb();
    const flaggedIds = new Set(db.attempts.filter((a) => a.flagged).map((a) => a.userId));
    let rows = [...db.users];
    if (filters.role && filters.role !== "all") rows = rows.filter((u) => u.role === filters.role);
    if (filters.program && filters.program !== "all")
      rows = rows.filter((u) => u.programs.includes(filters.program as ProgramSlug));
    if (filters.status && filters.status !== "all") rows = rows.filter((u) => u.status === filters.status);
    if (filters.ageBand && filters.ageBand !== "all") {
      rows = rows.filter((u) =>
        filters.ageBand === "under12" ? u.age < 12 : filters.ageBand === "12to18" ? u.age >= 12 && u.age <= 18 : u.age > 18,
      );
    }
    if (filters.flaggedOnly) rows = rows.filter((u) => flaggedIds.has(u.id));
    if (filters.search) {
      const s = filters.search.toLowerCase();
      rows = rows.filter(
        (u) => u.fullName.toLowerCase().includes(s) || u.email.toLowerCase().includes(s) || u.zip.includes(s),
      );
    }
    return delay(rows.sort((a, b) => a.fullName.localeCompare(b.fullName)));
  },

  async get(id: string): Promise<User | null> {
    return delay(getDb().users.find((u) => u.id === id) ?? null);
  },

  async getMany(ids: string[]): Promise<User[]> {
    const set = new Set(ids);
    return delay(getDb().users.filter((u) => set.has(u.id)));
  },

  async childrenOf(guardianId: string): Promise<User[]> {
    return delay(getDb().users.filter((u) => u.guardianId === guardianId));
  },

  async participantsForStaff(staffId: string): Promise<User[]> {
    const db = getDb();
    const staff = db.users.find((u) => u.id === staffId);
    if (!staff) return delay([]);
    const programs = new Set(staff.programs);
    return delay(
      db.users.filter(
        (u) => (u.role === "student" || u.role === "parent") && u.programs.some((p) => programs.has(p)),
      ),
    );
  },

  async create(input: Partial<User> & { email: string; fullName: string; role: Role }): Promise<User> {
    await delay(null, 250);
    return mutate((db) => {
      const user = stamped({
        id: newId("usr"),
        programs: [],
        dateOfBirth: "1990-01-01",
        age: 36,
        phone: "",
        zip: "",
        preferredLanguage: "English",
        status: "active" as const,
        joinedAt: nowIso(),
        lastActiveAt: nowIso(),
        ...input,
      }) as User;
      db.users.push(user);
      return user;
    });
  },

  async update(id: string, patch: Partial<User>): Promise<User> {
    await delay(null, 200);
    return mutate((db) => {
      const user = db.users.find((u) => u.id === id);
      if (!user) throw new Error("User not found");
      Object.assign(user, patch, { updatedAt: nowIso() });
      return user;
    });
  },

  async setStatus(id: string, status: User["status"]): Promise<User> {
    return this.update(id, { status });
  },

  async linkGuardian(childId: string, guardianId: string): Promise<User> {
    return this.update(childId, { guardianId });
  },

  async resetPassword(id: string): Promise<void> {
    await delay(null, 250);
    void id;
  },
};
