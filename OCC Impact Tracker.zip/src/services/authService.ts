import { delay, getDb, mutate, newId, nowIso, resetDb, stamped } from "@/lib/mock-db";
import type { ProgramSlug, Role, User } from "@/types";

const SESSION_KEY = "occ_demo_session";

function readSessionId(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(SESSION_KEY);
}

function writeSessionId(id: string | null) {
  if (typeof window === "undefined") return;
  if (id) window.localStorage.setItem(SESSION_KEY, id);
  else window.localStorage.removeItem(SESSION_KEY);
}

export const authService = {
  async getCurrentUser(): Promise<User | null> {
    const id = readSessionId();
    if (!id) return delay(null, 60);
    const user = getDb().users.find((u) => u.id === id) ?? null;
    return delay(user, 80);
  },

  async signIn(email: string, _password: string, expectedRole?: Role): Promise<User> {
    const db = getDb();
    const user = db.users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
    await delay(null, 300);
    if (!user) throw new Error("We couldn't find an account with that email.");
    if (expectedRole && user.role !== expectedRole) {
      throw new Error(`That account is a ${user.role} account. Use the ${user.role} sign-in page.`);
    }
    writeSessionId(user.id);
    return user;
  },

  async signInWithGoogle(role: Role): Promise<User> {
    const db = getDb();
    const user = db.users.find((u) => u.role === role && u.status === "active");
    await delay(null, 400);
    if (!user) throw new Error("No demo account available for that role yet.");
    writeSessionId(user.id);
    return user;
  },

  async signInAsRole(role: Role): Promise<User> {
    const db = getDb();
    const preferred: Record<Role, string> = {
      admin: "usr_admin",
      staff: "usr_staff",
      volunteer: "usr_volunteer",
      parent: "usr_parent",
      student: "usr_student",
    };
    const user =
      db.users.find((u) => u.id === preferred[role]) ?? db.users.find((u) => u.role === role);
    await delay(null, 120);
    if (!user) throw new Error("No seeded user for that role.");
    writeSessionId(user.id);
    return user;
  },

  async signUp(input: {
    email: string;
    password: string;
    fullName: string;
    role: Role;
    programs: ProgramSlug[];
    dateOfBirth: string;
    phone: string;
    zip: string;
    preferredLanguage: string;
    guardianName?: string;
    guardianEmail?: string;
  }): Promise<User> {
    await delay(null, 350);
    return mutate((db) => {
      if (db.users.some((u) => u.email.toLowerCase() === input.email.toLowerCase())) {
        throw new Error("An account with that email already exists.");
      }
      let guardianId: string | undefined;
      if (input.guardianEmail) {
        const existing = db.users.find(
          (u) => u.email.toLowerCase() === input.guardianEmail!.toLowerCase(),
        );
        if (existing) guardianId = existing.id;
        else {
          const guardian = stamped({
            id: newId("usr"),
            email: input.guardianEmail,
            fullName: input.guardianName ?? "Guardian",
            role: "parent" as Role,
            programs: input.programs,
            dateOfBirth: "1988-01-01",
            age: 38,
            phone: input.phone,
            zip: input.zip,
            preferredLanguage: input.preferredLanguage,
            status: "pending" as const,
            joinedAt: nowIso(),
            lastActiveAt: nowIso(),
          }) as User;
          db.users.push(guardian);
          guardianId = guardian.id;
        }
      }
      const birth = new Date(input.dateOfBirth);
      const age = Math.floor((Date.now() - birth.getTime()) / (365.25 * 86400000));
      const user = stamped({
        id: newId("usr"),
        email: input.email,
        fullName: input.fullName,
        role: input.role,
        programs: input.programs,
        dateOfBirth: input.dateOfBirth,
        age,
        phone: input.phone,
        zip: input.zip,
        preferredLanguage: input.preferredLanguage,
        ...(guardianId ? { guardianId } : {}),
        status: "active" as const,
        joinedAt: nowIso(),
        lastActiveAt: nowIso(),
      }) as User;
      db.users.push(user);
      writeSessionId(user.id);
      return user;
    });
  },

  async signOut(): Promise<void> {
    writeSessionId(null);
    await delay(null, 100);
  },

  async resetDemoData(): Promise<void> {
    resetDb();
    await delay(null, 200);
  },
};

export function ageBandForProgram(program: ProgramSlug): { min: number; max: number } | null {
  if (program === "sprout-society") return { min: 5, max: 11 };
  if (program === "becoming") return { min: 12, max: 18 };
  return null;
}
