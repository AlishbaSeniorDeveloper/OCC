import { assessments as baseAssessments } from "@/data/assessments";
import { delay, getDb, mutate, newId, nowIso, stamped } from "@/lib/mock-db";
import { scoreAttempt } from "@/lib/scoring";
import type { Assessment, AssessmentAttempt, AttemptResponse, Audience, ProgramSlug } from "@/types";

function allAssessments(): Assessment[] {
  const overrides = getDb().assessmentOverrides ?? [];
  return baseAssessments.map((a) => overrides.find((o) => o.id === a.id) ?? a);
}

export const assessmentService = {
  async listInstruments(filters: { programId?: ProgramSlug; audience?: Audience; activeOnly?: boolean } = {}): Promise<Assessment[]> {
    let rows = allAssessments();
    if (filters.programId) rows = rows.filter((a) => a.programId === filters.programId);
    if (filters.audience) rows = rows.filter((a) => a.audience === filters.audience);
    if (filters.activeOnly) rows = rows.filter((a) => a.isActive);
    return delay(rows);
  },

  async getInstrument(id: string): Promise<Assessment | null> {
    return delay(allAssessments().find((a) => a.id === id) ?? null);
  },

  async updateInstrument(id: string, patch: Partial<Assessment>): Promise<Assessment> {
    await delay(null, 200);
    return mutate((db) => {
      const current = allAssessments().find((a) => a.id === id);
      if (!current) throw new Error("Instrument not found");
      const next = { ...current, ...patch, updatedAt: nowIso() };
      const idx = db.assessmentOverrides.findIndex((o) => o.id === id);
      if (idx >= 0) db.assessmentOverrides[idx] = next;
      else db.assessmentOverrides.push(next);
      return next;
    });
  },

  async attemptsForUser(userId: string): Promise<AssessmentAttempt[]> {
    return delay(
      getDb()
        .attempts.filter((a) => a.userId === userId)
        .sort((a, b) => (b.completedAt ?? b.startedAt).localeCompare(a.completedAt ?? a.startedAt)),
    );
  },

  async allAttempts(): Promise<AssessmentAttempt[]> {
    return delay([...getDb().attempts].sort((a, b) => b.startedAt.localeCompare(a.startedAt)));
  },

  async flaggedAttempts(programs?: ProgramSlug[]): Promise<AssessmentAttempt[]> {
    const db = getDb();
    let rows = db.attempts.filter((a) => a.flagged);
    if (programs?.length) {
      const set = new Set(programs);
      rows = rows.filter((a) => {
        const user = db.users.find((u) => u.id === a.userId);
        return user?.programs.some((p) => set.has(p));
      });
    }
    return delay(rows.sort((a, b) => b.startedAt.localeCompare(a.startedAt)));
  },

  async getAttempt(id: string): Promise<AssessmentAttempt | null> {
    return delay(getDb().attempts.find((a) => a.id === id) ?? null);
  },

  async startAttempt(assessmentId: string, userId: string): Promise<AssessmentAttempt> {
    await delay(null, 180);
    return mutate((db) => {
      const existing = db.attempts.find(
        (a) => a.assessmentId === assessmentId && a.userId === userId && a.status === "in-progress",
      );
      if (existing) return existing;
      const attempt = stamped({
        id: newId("att"),
        assessmentId,
        userId,
        startedAt: nowIso(),
        status: "in-progress" as const,
        responses: [] as AttemptResponse[],
        rawScore: 0,
        normalizedScore: 0,
        band: "",
        domainScores: {},
        flagged: false,
      }) as AssessmentAttempt;
      db.attempts.push(attempt);
      return attempt;
    });
  },

  async inProgressFor(userId: string): Promise<AssessmentAttempt | null> {
    return delay(getDb().attempts.find((a) => a.userId === userId && a.status === "in-progress") ?? null);
  },

  async saveProgress(attemptId: string, responses: AttemptResponse[]): Promise<void> {
    mutate((db) => {
      const attempt = db.attempts.find((a) => a.id === attemptId);
      if (attempt) {
        attempt.responses = responses;
        attempt.updatedAt = nowIso();
      }
    });
    await delay(null, 80);
  },

  async submitAttempt(attemptId: string, responses: AttemptResponse[]): Promise<AssessmentAttempt> {
    await delay(null, 320);
    return mutate((db) => {
      const attempt = db.attempts.find((a) => a.id === attemptId);
      if (!attempt) throw new Error("Attempt not found");
      const instrument = allAssessments().find((a) => a.id === attempt.assessmentId);
      if (!instrument) throw new Error("Instrument not found");
      const result = scoreAttempt(instrument, responses);
      Object.assign(attempt, {
        responses,
        status: "completed" as const,
        completedAt: nowIso(),
        updatedAt: nowIso(),
        rawScore: result.rawScore,
        normalizedScore: result.normalizedScore,
        band: result.band,
        domainScores: result.domainScores,
        flagged: result.flagged,
      });

      if (result.flagged) {
        const participant = db.users.find((u) => u.id === attempt.userId);
        const recipients = db.users.filter(
          (u) => u.role === "admin" || (u.role === "staff" && u.programs.some((p) => participant?.programs.includes(p))),
        );
        for (const r of recipients) {
          db.notifications.unshift(
            stamped({
              id: newId("ntf"),
              userId: r.id,
              type: "safety" as const,
              title: "Assessment needs review",
              body: `${participant?.fullName ?? "A participant"} completed ${instrument.title} and was flagged for follow-up.`,
              read: false,
              linkTo: "/staff",
            }) as never,
          );
        }
        if (participant?.guardianId) {
          db.notifications.unshift(
            stamped({
              id: newId("ntf"),
              userId: participant.guardianId,
              type: "safety" as const,
              title: "Support resources for your child",
              body: `A recent check-in suggests ${participant.fullName.split(" ")[0]} could use extra support. A staff member will reach out.`,
              read: false,
              linkTo: "/parent/my-child",
            }) as never,
          );
        }
      }
      return attempt;
    });
  },

  async reviewAttempt(attemptId: string, reviewerId: string, notes: string): Promise<AssessmentAttempt> {
    await delay(null, 220);
    return mutate((db) => {
      const attempt = db.attempts.find((a) => a.id === attemptId);
      if (!attempt) throw new Error("Attempt not found");
      attempt.reviewedBy = reviewerId;
      attempt.reviewedAt = nowIso();
      attempt.staffNotes = notes;
      attempt.updatedAt = nowIso();
      return attempt;
    });
  },

  async availableFor(userId: string): Promise<Assessment[]> {
    const db = getDb();
    const user = db.users.find((u) => u.id === userId);
    if (!user) return delay([]);
    const audience: Audience = user.age < 12 ? "child" : user.age <= 18 ? "teen" : "adult";
    const rows = allAssessments().filter(
      (a) => a.isActive && (user.programs.includes(a.programId) || a.audience === audience) && a.audience === audience,
    );
    return delay(rows);
  },
};
