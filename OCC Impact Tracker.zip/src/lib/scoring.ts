import type { Assessment, AttemptResponse, ScoreBand } from "@/types";

export interface ScoreResult {
  rawScore: number;
  maxScore: number;
  normalizedScore: number;
  band: string;
  bandTone: ScoreBand["tone"];
  interpretation: string;
  domainScores: Record<string, number>;
  flagged: boolean;
  flagReason?: string;
}

export function maxRawScore(assessment: Assessment): number {
  return assessment.questions.reduce((sum, q) => {
    if (q.type === "text" || q.options.length === 0) return sum;
    return sum + Math.max(...q.options.map((o) => o.value));
  }, 0);
}

export function minRawScore(assessment: Assessment): number {
  return assessment.questions.reduce((sum, q) => {
    if (q.type === "text" || q.options.length === 0) return sum;
    return sum + Math.min(...q.options.map((o) => o.value));
  }, 0);
}

export function scoreAttempt(assessment: Assessment, responses: AttemptResponse[]): ScoreResult {
  const byId = new Map(responses.map((r) => [r.questionId, r.value]));
  let raw = 0;
  const domainTotals: Record<string, { sum: number; max: number }> = {};

  for (const question of assessment.questions) {
    if (question.type === "text" || question.options.length === 0) continue;
    const value = byId.get(question.id);
    if (value === undefined) continue;
    const values = question.options.map((o) => o.value);
    const hi = Math.max(...values);
    const lo = Math.min(...values);
    const effective = question.reverseScored ? hi + lo - value : value;
    raw += effective;
    const domain = question.domain ?? "Overall";
    domainTotals[domain] ??= { sum: 0, max: 0 };
    domainTotals[domain].sum += effective;
    domainTotals[domain].max += hi;
  }

  const max = maxRawScore(assessment);
  const min = minRawScore(assessment);
  const normalized = max === min ? 0 : Math.round(((raw - min) / (max - min)) * 100);

  const bandMatch =
    assessment.bands.find((b) => raw >= b.min && raw <= b.max) ??
    assessment.bands[assessment.bands.length - 1];

  const domainScores: Record<string, number> = {};
  for (const [domain, t] of Object.entries(domainTotals)) {
    domainScores[domain] = t.max === 0 ? 0 : Math.round((t.sum / t.max) * 100);
  }

  let flagged = false;
  let flagReason: string | undefined;

  if (assessment.safetyItemId) {
    const safetyValue = byId.get(assessment.safetyItemId) ?? 0;
    if (safetyValue > 0) {
      flagged = true;
      flagReason = "Endorsed thoughts of self-harm on the safety item.";
    }
  }
  if (bandMatch?.tone === "severe") {
    flagged = true;
    flagReason ??= `Scored in the ${bandMatch.label} band.`;
  }

  return {
    rawScore: raw,
    maxScore: max,
    normalizedScore: normalized,
    band: bandMatch?.label ?? "Unscored",
    bandTone: bandMatch?.tone ?? "good",
    interpretation: bandMatch?.interpretation ?? "",
    domainScores,
    flagged,
    flagReason,
  };
}

export function bandToneClass(tone: ScoreBand["tone"]): string {
  switch (tone) {
    case "good":
      return "bg-accent text-accent-foreground border-primary/25";
    case "watch":
      return "bg-secondary text-secondary-foreground border-sage/50";
    case "alert":
      return "bg-terracotta/12 text-terracotta border-terracotta/35";
    case "severe":
      return "bg-terracotta/20 text-terracotta border-terracotta/55";
  }
}

export const CRISIS_RESOURCES = [
  {
    name: "988 Suicide & Crisis Lifeline",
    detail: "Call or text 988 — free, confidential, 24/7",
    action: "tel:988",
  },
  {
    name: "Crisis Text Line",
    detail: "Text HOME to 741741",
    action: "sms:741741&body=HOME",
  },
  {
    name: "OCC Staff Support",
    detail: "Nia Ollivier, Program Director — (757) 555-0142",
    action: "tel:7575550142",
  },
];
