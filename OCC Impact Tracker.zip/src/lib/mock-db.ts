import { generateSeed } from "@/data/seed/generate";
import type { MockDb } from "@/types";

const STORAGE_KEY = "occ_mock_db";
const VERSION_KEY = "occ_mock_db_version";
const VERSION = "1";

let cache: MockDb | null = null;
const listeners = new Set<() => void>();

function load(): MockDb {
  if (cache) return cache;
  if (typeof window !== "undefined") {
    try {
      const version = window.localStorage.getItem(VERSION_KEY);
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw && version === VERSION) {
        cache = JSON.parse(raw) as MockDb;
        return cache;
      }
    } catch {
      /* fall through to a fresh seed */
    }
  }
  cache = generateSeed();
  persist();
  return cache;
}

function persist() {
  if (typeof window === "undefined" || !cache) return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(cache));
    window.localStorage.setItem(VERSION_KEY, VERSION);
  } catch {
    /* storage full or unavailable — the in-memory copy still works */
  }
}

export function getDb(): MockDb {
  return load();
}

/** Mutate the mock database and persist + notify subscribers. */
export function mutate<T>(fn: (db: MockDb) => T): T {
  const db = load();
  const result = fn(db);
  persist();
  listeners.forEach((l) => l());
  return result;
}

export function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function resetDb(): void {
  cache = generateSeed();
  persist();
  listeners.forEach((l) => l());
}

/** Simulated network latency so loading skeletons are real. */
export function delay<T>(value: T, ms = 150 + Math.floor(Math.random() * 150)): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(value), ms));
}

export function nowIso(): string {
  return new Date().toISOString();
}

let counter = 0;
export function newId(prefix: string): string {
  counter += 1;
  return `${prefix}_${Date.now().toString(36)}${counter.toString(36)}`;
}

export function stamped<T extends object>(o: T) {
  const ts = nowIso();
  return { ...o, createdAt: ts, updatedAt: ts };
}
