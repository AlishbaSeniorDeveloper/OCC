import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { DataTable, type Column } from "@/components/kit/DataTable";
import { ErrorState, PageSkeleton } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/context/AuthContext";
import { analyticsService } from "@/services/analyticsService";
import { assessmentService } from "@/services/assessmentService";
import { eventService } from "@/services/eventService";
import { inventoryService, stockHealth } from "@/services/inventoryService";
import { reportService, type ReportSection } from "@/services/reportService";
import { userService } from "@/services/userService";
import type { ProgramSlug, Report, User } from "@/types";

export const Route = createFileRoute("/admin/reports")({
  head: () => ({
    meta: [
      { title: "Generate reports — OCC Impact Report Tracker" },
      { name: "description", content: "Build branded impact reports for any program or participant and export as PDF or CSV." },
      { property: "og:title", content: "Generate reports — OCC Impact Report Tracker" },
      { property: "og:description", content: "Build branded impact reports for any program or participant and export as PDF or CSV." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["admin"]}>
      <ReportsPage />
    </ProtectedRoute>
  ),
});

const PROGRAMS: ProgramSlug[] = ["fresh-table", "sprout-society", "becoming"];
const PROGRAM_LABEL: Record<ProgramSlug, string> = {
  "fresh-table": "The Fresh Table",
  "sprout-society": "Sprout Society",
  becoming: "Becoming",
};

const REPORT_TYPES = [
  { value: "organization-impact", label: "Organization impact" },
  { value: "program-impact", label: "Program impact" },
  { value: "individual-participant", label: "Individual participant" },
  { value: "inventory", label: "Inventory" },
  { value: "volunteer-hours", label: "Volunteer hours" },
  { value: "assessment-summary", label: "Assessment summary" },
] as const;
type ReportType = (typeof REPORT_TYPES)[number]["value"];

const NEEDS_PROGRAM: ReportType[] = ["program-impact", "assessment-summary"];
const NEEDS_USER: ReportType[] = ["individual-participant"];

function ReportsPage() {
  const { user: me } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [saved, setSaved] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const [type, setType] = useState<ReportType>("organization-impact");
  const [program, setProgram] = useState<ProgramSlug>("fresh-table");
  const [userSearch, setUserSearch] = useState("");
  const [userId, setUserId] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [generating, setGenerating] = useState(false);

  const load = () => {
    setLoading(true);
    setError(false);
    Promise.all([userService.list(), reportService.saved()])
      .then(([u, r]) => {
        setUsers(u);
        setSaved(r);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const filteredUsers = useMemo(() => {
    if (!userSearch) return users.slice(0, 20);
    const s = userSearch.toLowerCase();
    return users.filter((u) => u.fullName.toLowerCase().includes(s) || u.email.toLowerCase().includes(s)).slice(0, 20);
  }, [users, userSearch]);

  const dateRangeLabel = startDate && endDate ? `${startDate} to ${endDate}` : "All time";

  const buildSections = async (): Promise<{ title: string; sections: ReportSection[]; csvRows: Record<string, string | number>[] }> => {
    switch (type) {
      case "organization-impact": {
        const data = await analyticsService.organizationOverview();
        return {
          title: "Organization impact report",
          sections: [
            {
              heading: "Organization KPIs",
              kpis: [
                { label: "Total participants", value: String(data.kpis.totalParticipants) },
                { label: "Active this month", value: String(data.kpis.activeThisMonth) },
                { label: "Assessments completed", value: String(data.kpis.assessmentsCompleted) },
                { label: "Households served", value: data.kpis.householdsServed.toLocaleString() },
                { label: "Pounds distributed", value: data.kpis.poundsDistributed.toLocaleString() },
                { label: "Volunteer hours", value: Math.round(data.kpis.volunteerHours).toLocaleString() },
              ],
            },
            {
              heading: "Participants by program",
              table: {
                columns: ["Program", "Participants"],
                rows: data.participantsByProgram.map((p) => [PROGRAM_LABEL[p.name as ProgramSlug] ?? p.name, p.value]),
              },
            },
            {
              heading: "Average score by program",
              table: {
                columns: ["Program", "Average score", "Attempts"],
                rows: data.avgScoreByProgram.map((p) => [PROGRAM_LABEL[p.program], p.average, p.attempts]),
              },
            },
          ],
          csvRows: data.participantsByProgram.map((p) => ({
            Program: PROGRAM_LABEL[p.name as ProgramSlug] ?? p.name,
            Participants: p.value,
          })),
        };
      }
      case "program-impact": {
        const dashboard =
          program === "fresh-table"
            ? await analyticsService.freshTableDashboard()
            : program === "sprout-society"
              ? await analyticsService.sproutDashboard()
              : await analyticsService.becomingDashboard();
        const kpis = Object.entries(dashboard)
          .filter(([, v]) => typeof v === "number")
          .slice(0, 6)
          .map(([label, value]) => ({ label, value: String(value) }));
        return {
          title: `${PROGRAM_LABEL[program]} impact report`,
          sections: [{ heading: "Program KPIs", kpis }],
          csvRows: Object.entries(dashboard)
            .filter(([, v]) => typeof v === "number")
            .map(([k, v]) => ({ Metric: k, Value: v as number })),
        };
      }
      case "individual-participant": {
        const target = users.find((u) => u.id === userId);
        if (!target) throw new Error("Select a user");
        const attempts = await assessmentService.attemptsForUser(target.id);
        return {
          title: `Participant report — ${target.fullName}`,
          sections: [
            {
              heading: "Profile",
              kpis: [
                { label: "Role", value: target.role },
                { label: "Status", value: target.status },
                { label: "Age", value: String(target.age) },
                { label: "Assessments completed", value: String(attempts.filter((a) => a.status === "completed").length) },
              ],
            },
            {
              heading: "Assessment history",
              table: {
                columns: ["Assessment", "Status", "Band", "Score", "Date"],
                rows: attempts.map((a) => [
                  a.assessmentId,
                  a.status,
                  a.band || "—",
                  String(a.normalizedScore),
                  new Date(a.completedAt ?? a.startedAt).toLocaleDateString("en-US"),
                ]),
              },
            },
          ],
          csvRows: attempts.map((a) => ({
            Assessment: a.assessmentId,
            Status: a.status,
            Band: a.band || "",
            Score: a.normalizedScore,
            Date: new Date(a.completedAt ?? a.startedAt).toLocaleDateString("en-US"),
          })),
        };
      }
      case "inventory": {
        const items = await inventoryService.list();
        return {
          title: "Inventory report",
          sections: [
            {
              heading: "Stock overview",
              kpis: [
                { label: "Total items", value: String(items.length) },
                { label: "Low stock", value: String(items.filter((i) => stockHealth(i) === "low").length) },
              ],
              table: {
                columns: ["Item", "On hand", "Par level", "Reorder point", "Health"],
                rows: items.map((i) => [i.name, i.quantityOnHand, i.parLevel, i.reorderPoint, stockHealth(i)]),
              },
            },
          ],
          csvRows: items.map((i) => ({
            Item: i.name,
            Category: i.category,
            "On hand": i.quantityOnHand,
            "Par level": i.parLevel,
            "Reorder point": i.reorderPoint,
            Health: stockHealth(i),
          })),
        };
      }
      case "volunteer-hours": {
        const hours = await eventService.allHours();
        const byUser = new Map<string, number>();
        for (const h of hours) byUser.set(h.userId, (byUser.get(h.userId) ?? 0) + h.hours);
        const usersById = new Map(users.map((u) => [u.id, u]));
        return {
          title: "Volunteer hours report",
          sections: [
            {
              heading: "Volunteer hours summary",
              kpis: [{ label: "Total hours logged", value: hours.reduce((s, h) => s + h.hours, 0).toFixed(1) }],
              table: {
                columns: ["Volunteer", "Total hours"],
                rows: [...byUser.entries()].map(([uid, total]) => [usersById.get(uid)?.fullName ?? uid, total.toFixed(1)]),
              },
            },
          ],
          csvRows: [...byUser.entries()].map(([uid, total]) => ({
            Volunteer: usersById.get(uid)?.fullName ?? uid,
            "Total hours": total,
          })),
        };
      }
      case "assessment-summary": {
        const all = await assessmentService.allAttempts();
        const userIds = new Set(users.filter((u) => u.programs.includes(program)).map((u) => u.id));
        const rows = all.filter((a) => userIds.has(a.userId) && a.status === "completed");
        return {
          title: `${PROGRAM_LABEL[program]} assessment summary`,
          sections: [
            {
              heading: "Assessment summary",
              kpis: [
                { label: "Completed assessments", value: String(rows.length) },
                {
                  label: "Average score",
                  value: rows.length ? String(Math.round(rows.reduce((s, a) => s + a.normalizedScore, 0) / rows.length)) : "0",
                },
                { label: "Flagged", value: String(rows.filter((a) => a.flagged).length) },
              ],
              table: {
                columns: ["Assessment", "Band", "Score", "Flagged"],
                rows: rows.map((a) => [a.assessmentId, a.band || "—", String(a.normalizedScore), a.flagged ? "Yes" : "No"]),
              },
            },
          ],
          csvRows: rows.map((a) => ({
            Assessment: a.assessmentId,
            Band: a.band || "",
            Score: a.normalizedScore,
            Flagged: a.flagged ? "Yes" : "No",
          })),
        };
      }
    }
  };

  const generate = async (format: "pdf" | "csv") => {
    if (NEEDS_USER.includes(type) && !userId) {
      toast.error("Select a participant first");
      return;
    }
    setGenerating(true);
    try {
      const { title, sections, csvRows } = await buildSections();
      const scope = NEEDS_USER.includes(type) ? userId : NEEDS_PROGRAM.includes(type) ? program : "organization";
      if (format === "pdf") {
        await reportService.exportPdf({
          title,
          subtitle: REPORT_TYPES.find((t) => t.value === type)?.label ?? "Report",
          generatedFor: NEEDS_USER.includes(type) ? users.find((u) => u.id === userId)?.fullName ?? "—" : "OCC Leadership",
          dateRange: dateRangeLabel,
          sections,
        });
      } else {
        await reportService.exportCsv(title, csvRows);
      }
      await reportService.record({
        title,
        type,
        scope,
        filters: { startDate, endDate },
        generatedBy: me?.id ?? "admin",
        format,
      });
      const rows = await reportService.saved();
      setSaved(rows);
      toast.success(`Report generated (${format.toUpperCase()})`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not generate report");
    } finally {
      setGenerating(false);
    }
  };

  const savedColumns: Column<Report>[] = useMemo(
    () => [
      { key: "title", header: "Title", sortValue: (r) => r.title },
      { key: "type", header: "Type", sortValue: (r) => r.type, render: (r) => <span className="capitalize">{r.type.replace(/-/g, " ")}</span> },
      { key: "format", header: "Format", sortValue: (r) => r.format, render: (r) => <Badge variant="outline" className="uppercase">{r.format}</Badge> },
      {
        key: "generatedAt",
        header: "Generated",
        sortValue: (r) => r.generatedAt,
        render: (r) => new Date(r.generatedAt).toLocaleString("en-US"),
      },
      {
        key: "actions",
        header: "",
        render: (r) => (
          <Button
            size="sm"
            variant="ghost"
            onClick={async (e) => {
              e.stopPropagation();
              await reportService.remove(r.id);
              setSaved((prev) => prev.filter((x) => x.id !== r.id));
              toast.success("Report record removed");
            }}
          >
            Delete
          </Button>
        ),
      },
    ],
    [],
  );

  return (
    <PageShell>
      <PageHeader title="Reports" description="Generate branded impact reports for the organization, any program, or any participant." />

      {loading ? (
        <PageSkeleton />
      ) : error ? (
        <ErrorState onRetry={load} />
      ) : (
        <div className="space-y-8">
          <div className="surface-card space-y-4 p-5">
            <SectionHeading title="Build a report" description="Choose a report type and scope, then export as PDF or CSV." />

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <Label className="mb-1.5 block">Report type</Label>
                <Select value={type} onValueChange={(v) => setType(v as ReportType)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {REPORT_TYPES.map((t) => (
                      <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {NEEDS_PROGRAM.includes(type) && (
                <div>
                  <Label className="mb-1.5 block">Program</Label>
                  <Select value={program} onValueChange={(v) => setProgram(v as ProgramSlug)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {PROGRAMS.map((p) => (
                        <SelectItem key={p} value={p}>{PROGRAM_LABEL[p]}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {NEEDS_USER.includes(type) && (
                <div>
                  <Label className="mb-1.5 block">Participant</Label>
                  <Input
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    placeholder="Search by name or email…"
                    className="mb-2"
                  />
                  <Select value={userId} onValueChange={setUserId}>
                    <SelectTrigger><SelectValue placeholder="Choose a user" /></SelectTrigger>
                    <SelectContent className="max-h-72">
                      {filteredUsers.map((u) => (
                        <SelectItem key={u.id} value={u.id}>{u.fullName} — {u.email}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div>
                <Label className="mb-1.5 block">Start date</Label>
                <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
              </div>
              <div>
                <Label className="mb-1.5 block">End date</Label>
                <Input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
              </div>
            </div>

            <div className="flex flex-wrap gap-2 pt-2">
              <Button disabled={generating} onClick={() => generate("pdf")}>
                {generating ? "Generating…" : "Export branded PDF"}
              </Button>
              <Button variant="outline" disabled={generating} onClick={() => generate("csv")}>
                Export CSV
              </Button>
            </div>
          </div>

          <div>
            <SectionHeading title="Saved reports" description="Every report generated by the organization, with a record of when and by whom." />
            <DataTable
              rows={saved}
              columns={savedColumns}
              searchKeys={(r) => `${r.title} ${r.type}`}
              exportName="occ-saved-reports"
              emptyTitle="No reports generated yet"
              emptyDescription="Generate your first report above to see it recorded here."
            />
          </div>
        </div>
      )}
    </PageShell>
  );
}
