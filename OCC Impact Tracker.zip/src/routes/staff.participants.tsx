import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { DataTable, type Column } from "@/components/kit/DataTable";
import { PageSkeleton, EmptyState } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/context/AuthContext";
import { userService } from "@/services/userService";
import { assessmentService } from "@/services/assessmentService";
import { attendanceService, summarize, type AttendanceSummary } from "@/services/attendanceService";
import { bandToneClass } from "@/lib/scoring";
import { programs, programBySlug } from "@/data/programs";
import { assessmentById } from "@/data/assessments";
import type { AssessmentAttempt, AttendanceSlot, ProgramSlug, Role, User } from "@/types";
import { AlertTriangle, Flag, ShieldCheck, Users } from "lucide-react";

export const Route = createFileRoute("/staff/participants")({
  head: () => ({
    meta: [
      { title: "Participants — OCC Impact Report Tracker" },
      { name: "description", content: "Review participants in your programs, attendance, and assessment history." },
      { property: "og:title", content: "Participants — OCC Impact Report Tracker" },
      { property: "og:description", content: "Staff view of participant profiles, attendance, and flagged assessments." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["staff"]}>
      <ParticipantsPage />
    </ProtectedRoute>
  ),
});

function toneForBand(attempt: AssessmentAttempt): string {
  const assessment = assessmentById(attempt.assessmentId);
  const band = assessment?.bands.find((b) => b.label === attempt.band);
  return bandToneClass(band?.tone ?? "watch");
}

function ParticipantsPage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [participants, setParticipants] = useState<User[]>([]);
  const [attempts, setAttempts] = useState<AssessmentAttempt[]>([]);
  const [slots, setSlots] = useState<AttendanceSlot[]>([]);
  const [programFilter, setProgramFilter] = useState<ProgramSlug | "all">("all");
  const [roleFilter, setRoleFilter] = useState<Role | "all">("all");
  const [flaggedOnly, setFlaggedOnly] = useState(false);
  const [detail, setDetail] = useState<User | null>(null);
  const [reviewNotes, setReviewNotes] = useState("");
  const [reviewTarget, setReviewTarget] = useState<AssessmentAttempt | null>(null);

  const load = async () => {
    if (!user) return;
    const [p, a, s] = await Promise.all([
      userService.participantsForStaff(user.id),
      assessmentService.allAttempts(),
      attendanceService.listAll(),
    ]);
    setParticipants(p);
    setAttempts(a);
    setSlots(s);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, [user]);

  const flaggedIds = useMemo(() => new Set(attempts.filter((a) => a.flagged).map((a) => a.userId)), [attempts]);

  const summaryFor = (userId: string): AttendanceSummary => summarize(slots.filter((s) => s.userId === userId));

  const latestAttemptFor = (userId: string): AssessmentAttempt | undefined =>
    attempts.filter((a) => a.userId === userId && a.status === "completed").sort((a, b) => (b.completedAt ?? "").localeCompare(a.completedAt ?? ""))[0];

  const filtered = useMemo(() => {
    return participants.filter((p) => {
      if (programFilter !== "all" && !p.programs.includes(programFilter)) return false;
      if (roleFilter !== "all" && p.role !== roleFilter) return false;
      if (flaggedOnly && !flaggedIds.has(p.id)) return false;
      return true;
    });
  }, [participants, programFilter, roleFilter, flaggedOnly, flaggedIds]);

  if (loading || !user) {
    return (
      <PageShell>
        <PageHeader title="Participants" description="Loading participant roster…" />
        <PageSkeleton />
      </PageShell>
    );
  }

  const flaggedCount = participants.filter((p) => flaggedIds.has(p.id)).length;
  const avgAttendance = participants.length
    ? Math.round(participants.reduce((sum, p) => sum + summaryFor(p.id).rate, 0) / participants.length)
    : 0;

  const columns: Column<User>[] = [
    { key: "fullName", header: "Name", sortValue: (r) => r.fullName },
    { key: "age", header: "Age", sortValue: (r) => r.age, hideOnMobile: true },
    { key: "role", header: "Role", render: (r) => <Badge variant="outline" className="capitalize">{r.role}</Badge> },
    {
      key: "programs",
      header: "Programs",
      render: (r) => (
        <div className="flex flex-wrap gap-1">
          {r.programs.map((p) => (
            <Badge key={p} variant="outline">
              {programBySlug(p)?.name ?? p}
            </Badge>
          ))}
        </div>
      ),
    },
    {
      key: "status",
      header: "Status",
      render: (r) => (
        <Badge variant="outline" className={r.status === "active" ? "bg-accent text-accent-foreground border-primary/25" : "bg-secondary text-secondary-foreground border-sage/50"}>
          {r.status}
        </Badge>
      ),
    },
    {
      key: "attendance",
      header: "Attendance rate",
      sortValue: (r) => summaryFor(r.id).rate,
      csvValue: (r) => summaryFor(r.id).rate,
      render: (r) => `${summaryFor(r.id).rate}%`,
    },
    {
      key: "band",
      header: "Latest assessment",
      render: (r) => {
        const attempt = latestAttemptFor(r.id);
        if (!attempt) return <span className="text-xs text-muted-foreground">No attempts</span>;
        return (
          <Badge variant="outline" className={toneForBand(attempt)}>
            {attempt.band}
          </Badge>
        );
      },
    },
    {
      key: "flag",
      header: "Flagged",
      render: (r) => (flaggedIds.has(r.id) ? <Flag className="size-4 text-terracotta" aria-hidden /> : <span className="text-xs text-muted-foreground">—</span>),
    },
  ];

  const detailAttempts = detail ? attempts.filter((a) => a.userId === detail.id) : [];
  const detailSummary = detail ? summaryFor(detail.id) : null;

  const openReview = (attempt: AssessmentAttempt) => {
    setReviewTarget(attempt);
    setReviewNotes(attempt.staffNotes ?? "");
  };

  const submitReview = async () => {
    if (!reviewTarget || !user) return;
    try {
      await assessmentService.reviewAttempt(reviewTarget.id, user.id, reviewNotes.trim());
      toast.success("Review saved");
      setReviewTarget(null);
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not save review");
    }
  };

  return (
    <PageShell>
      <PageHeader title="Participants" description="Everyone enrolled in your programs, at a glance." />

      <StatGrid>
        <StatCard label="Total participants" value={participants.length} icon={Users} />
        <StatCard label="Flagged for review" value={flaggedCount} icon={AlertTriangle} />
        <StatCard label="Avg attendance rate" value={`${avgAttendance}%`} icon={ShieldCheck} />
        <StatCard label="Assessment attempts" value={attempts.filter((a) => participants.some((p) => p.id === a.userId)).length} icon={Flag} />
      </StatGrid>

      <div className="mt-8">
        <SectionHeading title="Roster" description="Filter by program, role, or flagged status" />
      </div>
      <div className="mb-4 flex flex-wrap gap-2">
        <Select value={programFilter} onValueChange={(v) => setProgramFilter(v as ProgramSlug | "all")}>
          <SelectTrigger className="w-52">
            <SelectValue placeholder="Program" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All programs</SelectItem>
            {programs.map((p) => (
              <SelectItem key={p.slug} value={p.slug}>
                {p.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={roleFilter} onValueChange={(v) => setRoleFilter(v as Role | "all")}>
          <SelectTrigger className="w-44">
            <SelectValue placeholder="Role" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All roles</SelectItem>
            <SelectItem value="student">Student</SelectItem>
            <SelectItem value="parent">Parent</SelectItem>
          </SelectContent>
        </Select>
        <Button variant={flaggedOnly ? "default" : "outline"} size="sm" onClick={() => setFlaggedOnly((v) => !v)}>
          <Flag className="mr-1.5 size-4" aria-hidden /> Flagged only
        </Button>
      </div>

      {participants.length === 0 ? (
        <EmptyState title="No participants yet" description="Once your programs enroll participants, they'll appear here." />
      ) : (
        <DataTable
          rows={filtered}
          columns={columns}
          searchKeys={(r) => `${r.fullName} ${r.email}`}
          onRowClick={(r) => setDetail(r)}
          exportName="participants"
          emptyTitle="No participants match"
          emptyDescription="Try adjusting the filters above."
        />
      )}

      <Dialog open={!!detail} onOpenChange={(open) => !open && setDetail(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{detail?.fullName}</DialogTitle>
          </DialogHeader>
          {detail && detailSummary && (
            <div className="max-h-[65vh] space-y-5 overflow-y-auto pr-1">
              <div className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
                <div className="surface-card p-3">
                  <p className="stat-label">Age</p>
                  <p className="stat-figure text-lg">{detail.age}</p>
                </div>
                <div className="surface-card p-3">
                  <p className="stat-label">Role</p>
                  <p className="stat-figure text-lg capitalize">{detail.role}</p>
                </div>
                <div className="surface-card p-3">
                  <p className="stat-label">Status</p>
                  <p className="stat-figure text-lg capitalize">{detail.status}</p>
                </div>
                <div className="surface-card p-3">
                  <p className="stat-label">Attendance rate</p>
                  <p className="stat-figure text-lg">{detailSummary.rate}%</p>
                </div>
              </div>
              <div>
                <p className="mb-1 text-sm font-medium text-foreground">Programs</p>
                <div className="flex flex-wrap gap-1.5">
                  {detail.programs.map((p) => (
                    <Badge key={p} variant="outline">
                      {programBySlug(p)?.name ?? p}
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <p className="mb-1 text-sm font-medium text-foreground">Attendance summary</p>
                <p className="text-sm text-muted-foreground">
                  {detailSummary.attended} attended · {detailSummary.missed} missed · {detailSummary.excused} excused ·{" "}
                  {detailSummary.upcoming} upcoming · streak {detailSummary.streak}
                </p>
              </div>
              <div>
                <p className="mb-2 text-sm font-medium text-foreground">Assessment attempts</p>
                {detailAttempts.length === 0 ? (
                  <p className="text-xs text-muted-foreground">No attempts recorded.</p>
                ) : (
                  <div className="space-y-2">
                    {detailAttempts.map((attempt) => (
                      <div key={attempt.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border p-2.5 text-sm">
                        <div>
                          <p className="font-medium text-foreground">{assessmentById(attempt.assessmentId)?.title ?? "Assessment"}</p>
                          <p className="text-xs text-muted-foreground">
                            {attempt.status === "completed" && attempt.completedAt
                              ? new Date(attempt.completedAt).toLocaleDateString("en-US")
                              : attempt.status}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          {attempt.status === "completed" && (
                            <Badge variant="outline" className={toneForBand(attempt)}>
                              {attempt.band}
                            </Badge>
                          )}
                          {attempt.flagged && (
                            <Button size="sm" variant="outline" onClick={() => openReview(attempt)}>
                              {attempt.reviewedAt ? "Update review" : "Review"}
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDetail(null)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!reviewTarget} onOpenChange={(open) => !open && setReviewTarget(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Review flagged attempt</DialogTitle>
          </DialogHeader>
          {reviewTarget && (
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">
                {assessmentById(reviewTarget.assessmentId)?.title} · Band: {reviewTarget.band}
              </p>
              <Textarea
                placeholder="Staff notes on this review…"
                value={reviewNotes}
                onChange={(e) => setReviewNotes(e.target.value)}
                rows={5}
              />
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setReviewTarget(null)}>
              Cancel
            </Button>
            <Button onClick={submitReview}>Save review</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageShell>
  );
}
