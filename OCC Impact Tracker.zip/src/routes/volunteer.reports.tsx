import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { FileDown, FileSpreadsheet, ClipboardCheck } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { DataTable, type Column } from "@/components/kit/DataTable";
import { PageSkeleton } from "@/components/kit/States";
import { useAuth } from "@/context/AuthContext";
import { taskService } from "@/services/taskService";
import { eventService } from "@/services/eventService";
import { reportService } from "@/services/reportService";
import type { Report, Task, VolunteerHourLog, Event } from "@/types";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/volunteer/reports")({
  head: () => ({
    meta: [
      { title: "My impact report — OCC Impact Report Tracker" },
      { name: "description", content: "Export a branded summary of your volunteer contributions to OCC." },
      { property: "og:title", content: "My impact report — OCC Impact Report Tracker" },
      { property: "og:description", content: "Download PDF or CSV summaries of your volunteer impact." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["volunteer"]}>
      <ReportsPage />
    </ProtectedRoute>
  ),
});

function ReportsPage() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [hours, setHours] = useState<VolunteerHourLog[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [rsvps, setRsvps] = useState<string[]>([]);
  const [saved, setSaved] = useState<Report[] | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    if (!user) return;
    setLoading(true);
    const [t, h, ev, mine, reports] = await Promise.all([
      taskService.listForUser(user.id),
      eventService.hoursForUser(user.id),
      eventService.list(),
      eventService.myRsvps(),
      reportService.saved(),
    ]);
    setTasks(t);
    setHours(h);
    setEvents(ev);
    setRsvps(mine);
    setSaved(reports.filter((r) => r.generatedBy === user.id));
    setLoading(false);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const completedTasks = tasks.filter((t) => t.status === "done").length;
  const totalHours = hours.reduce((sum, l) => sum + l.hours, 0);
  const eventsSupported = events.filter((e) => rsvps.includes(e.id)).length;

  const monthlyHours = useMemo(() => {
    const map = new Map<string, number>();
    for (const l of hours) {
      const key = new Date(l.date).toLocaleDateString("en-US", { month: "short", year: "2-digit" });
      map.set(key, (map.get(key) ?? 0) + l.hours);
    }
    return [...map.entries()];
  }, [hours]);

  const columns: Column<Report>[] = [
    { key: "title", header: "Report", sortValue: (r) => r.title },
    { key: "type", header: "Type", sortValue: (r) => r.type },
    { key: "format", header: "Format", sortValue: (r) => r.format.toUpperCase() },
    {
      key: "generatedAt",
      header: "Generated",
      sortValue: (r) => r.generatedAt,
      render: (r) => new Date(r.generatedAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
    },
  ];

  const exportPdf = async () => {
    if (!user) return;
    try {
      await reportService.exportPdf({
        title: "Volunteer impact summary",
        subtitle: "Personal contribution report",
        generatedFor: user.fullName,
        dateRange: "All time",
        sections: [
          {
            heading: "Overview",
            kpis: [
              { label: "Tasks completed", value: String(completedTasks) },
              { label: "Hours contributed", value: totalHours.toFixed(1) },
              { label: "Events supported", value: String(eventsSupported) },
            ],
          },
          {
            heading: "Hours by month",
            table: { columns: ["Month", "Hours"], rows: monthlyHours.map(([m, h]) => [m, h.toFixed(1)]) },
          },
          {
            heading: "Hour log detail",
            table: {
              columns: ["Date", "Activity", "Hours"],
              rows: hours.map((h) => [new Date(h.date).toLocaleDateString("en-US"), h.activity, h.hours]),
            },
          },
        ],
      });
      await reportService.record({
        title: "Volunteer impact summary",
        type: "volunteer-impact",
        scope: "self",
        filters: {},
        generatedBy: user.id,
        format: "pdf",
      });
      toast.success("PDF exported");
      load();
    } catch {
      toast.error("Couldn't export PDF");
    }
  };

  const exportCsv = async () => {
    if (!user) return;
    try {
      await reportService.exportCsv(
        "volunteer-hours",
        hours.map((h) => ({ date: h.date, activity: h.activity, hours: h.hours })),
      );
      await reportService.record({
        title: "Volunteer hours export",
        type: "volunteer-hours",
        scope: "self",
        filters: {},
        generatedBy: user.id,
        format: "csv",
      });
      toast.success("CSV exported");
      load();
    } catch {
      toast.error("Couldn't export CSV");
    }
  };

  if (loading) {
    return (
      <PageShell>
        <PageSkeleton />
      </PageShell>
    );
  }

  return (
    <PageShell>
      <PageHeader
        title="My impact report"
        description="A snapshot of your OCC volunteer contributions, ready to export and share."
        actions={
          <div className="flex gap-2">
            <Button variant="outline" onClick={exportCsv}>
              <FileSpreadsheet className="mr-1.5 size-4" aria-hidden /> Export CSV
            </Button>
            <Button onClick={exportPdf}>
              <FileDown className="mr-1.5 size-4" aria-hidden /> Export PDF
            </Button>
          </div>
        }
      />

      <StatGrid className="mb-8">
        <StatCard label="Tasks completed" value={completedTasks} icon={ClipboardCheck} />
        <StatCard label="Hours contributed" value={totalHours.toFixed(1)} />
        <StatCard label="Events supported" value={eventsSupported} />
        <StatCard label="Total tasks assigned" value={tasks.length} />
      </StatGrid>

      <SectionHeading title="Saved reports" description="Reports you've generated from this page." />
      <DataTable
        rows={saved ?? []}
        columns={columns}
        searchKeys={(r) => r.title}
        exportName="my-saved-reports"
        emptyTitle="No reports generated yet"
        emptyDescription="Export a PDF or CSV above to see it listed here."
      />
    </PageShell>
  );
}
