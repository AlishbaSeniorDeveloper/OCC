import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CalendarCheck2, Info, ShieldCheck, Target } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { StatCard, StatGrid, ProgressMeter } from "@/components/kit/StatCard";
import { PageSkeleton, EmptyState, ErrorState } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/context/AuthContext";
import { userService } from "@/services/userService";
import { attendanceService, type AttendanceSummary } from "@/services/attendanceService";
import { assessmentService } from "@/services/assessmentService";
import { bandToneClass } from "@/lib/scoring";
import type { AssessmentAttempt, Assessment, User } from "@/types";

export const Route = createFileRoute("/parent/my-child")({
  head: () => ({
    meta: [
      { title: "My child — OCC Impact Report Tracker" },
      { name: "description", content: "Program participation, attendance, and progress for your linked children." },
      { property: "og:title", content: "My child — OCC Impact Report Tracker" },
      { property: "og:description", content: "Track your child's programs, attendance, and check-in history." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["parent"]}>
      <MyChildPage />
    </ProtectedRoute>
  ),
});

function MyChildPage() {
  const { user } = useAuth();
  const [children, setChildren] = useState<User[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [summary, setSummary] = useState<AttendanceSummary | null>(null);
  const [attempts, setAttempts] = useState<AssessmentAttempt[]>([]);
  const [instruments, setInstruments] = useState<Assessment[]>([]);
  const [loading, setLoading] = useState(true);
  const [childLoading, setChildLoading] = useState(false);
  const [error, setError] = useState(false);

  const load = () => {
    if (!user) return;
    setLoading(true);
    setError(false);
    userService
      .childrenOf(user.id)
      .then((kids) => {
        setChildren(kids);
        setSelectedId((prev) => prev ?? kids[0]?.id ?? null);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(load, [user]);

  useEffect(() => {
    if (!selectedId) return;
    setChildLoading(true);
    Promise.all([
      attendanceService.summaryForUser(selectedId),
      assessmentService.attemptsForUser(selectedId),
      assessmentService.listInstruments(),
    ])
      .then(([sum, att, inst]) => {
        setSummary(sum);
        setAttempts(att);
        setInstruments(inst);
      })
      .catch(() => setError(true))
      .finally(() => setChildLoading(false));
  }, [selectedId]);

  if (loading) {
    return (
      <PageShell>
        <PageSkeleton />
      </PageShell>
    );
  }
  if (error) {
    return (
      <PageShell>
        <ErrorState onRetry={load} />
      </PageShell>
    );
  }

  if (children.length === 0) {
    return (
      <PageShell>
        <PageHeader title="My child" description="Program participation and progress for your linked children." />
        <EmptyState
          title="No children linked to your account yet"
          description="Once a program staff member links your child's profile to your account, their program information will appear here."
        />
      </PageShell>
    );
  }

  const child = children.find((c) => c.id === selectedId) ?? children[0];
  const instrumentById = new Map(instruments.map((i) => [i.id, i]));
  const completedAttempts = attempts.filter((a) => a.status === "completed");

  return (
    <PageShell>
      <PageHeader
        title="My child"
        description="Program participation, attendance, and progress snapshots for your linked children."
        actions={
          children.length > 1 ? (
            <Select value={child?.id} onValueChange={(v) => setSelectedId(v)}>
              <SelectTrigger className="w-56">
                <SelectValue placeholder="Choose a child" />
              </SelectTrigger>
              <SelectContent>
                {children.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.fullName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : undefined
        }
      />

      {!child ? null : childLoading || !summary ? (
        <PageSkeleton />
      ) : (
        <div className="space-y-6">
          <div className="surface-card flex flex-wrap items-center justify-between gap-4 p-5">
            <div>
              <h2 className="text-xl">{child.fullName}</h2>
              <p className="text-sm text-muted-foreground">
                Age {child.age} · {child.preferredLanguage}
              </p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {child.programs.length === 0 ? (
                  <span className="text-xs text-muted-foreground">No programs enrolled</span>
                ) : (
                  child.programs.map((p) => (
                    <Badge key={p} variant="secondary" className="capitalize">
                      {p.replace("-", " ")}
                    </Badge>
                  ))
                )}
              </div>
            </div>
            <Badge variant="outline" className="capitalize">
              {child.status}
            </Badge>
          </div>

          <div>
            <SectionHeading title="Attendance summary" description="Sessions and workshops for this program year" />
            <StatGrid>
              <StatCard label="Scheduled" value={summary.scheduled} icon={CalendarCheck2} />
              <StatCard label="Attended" value={summary.attended} />
              <StatCard label="Attendance rate" value={`${summary.rate}%`} />
              <StatCard label="Current streak" value={summary.streak} hint="Consecutive attended" />
            </StatGrid>
          </div>

          <div>
            <SectionHeading title="Assessment attempts" description="Completed check-ins and screeners" />
            {completedAttempts.length === 0 ? (
              <EmptyState title="No completed assessments yet" description="Completed check-ins will show a score band here once available." />
            ) : (
              <div className="grid gap-3 sm:grid-cols-2">
                {completedAttempts.slice(0, 6).map((a) => {
                  const instrument = instrumentById.get(a.assessmentId);
                  return (
                    <div key={a.id} className="surface-card space-y-2 p-4">
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-sm font-medium text-foreground">{instrument?.title ?? "Assessment"}</p>
                        <Badge className={bandToneClass(a.flagged ? "severe" : "good")}>
                          {a.band || "Scored"}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {a.completedAt ? new Date(a.completedAt).toLocaleDateString("en-US", { dateStyle: "medium" }) : "—"} ·
                        {" "}Score {a.rawScore}
                      </p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div>
            <SectionHeading title="Progress" description="Overall goal progress based on engagement" />
            <ProgressMeter label="Program engagement" value={summary.attended} max={Math.max(summary.scheduled, 1)} />
          </div>

          <Alert className="border-sage/40 bg-secondary/40">
            <ShieldCheck className="size-4 text-sage" aria-hidden />
            <AlertTitle>Caregiver feedback</AlertTitle>
            <AlertDescription>
              You can share your perspective on your child's progress through a caregiver feedback assessment when it's assigned by
              program staff. Ask your facilitator if one is available for this program cycle.
            </AlertDescription>
          </Alert>

          <Alert>
            <Info className="size-4 text-sage" aria-hidden />
            <AlertTitle>About clinical scores</AlertTitle>
            <AlertDescription>
              Detailed clinical scores, domain breakdowns, and safety flags are reviewed and shared directly by OCC staff. This page
              shows attendance and general progress only.
            </AlertDescription>
          </Alert>
        </div>
      )}
    </PageShell>
  );
}
