import { createFileRoute, Link } from "@tanstack/react-router";
import { GraduationCap, HeartHandshake, Shield, Users, Wrench } from "lucide-react";
import { PageHeader, PageShell } from "@/components/layout/PageShell";

const OPTIONS = [
  { role: "student", label: "Student", icon: GraduationCap, blurb: "Children and teens in Sprout Society or Becoming." },
  { role: "parent", label: "Parent or Adult", icon: HeartHandshake, blurb: "Caregivers and adults in workshops or Fresh Table." },
  { role: "volunteer", label: "Volunteer", icon: Users, blurb: "Shifts, tasks, and service hours." },
  { role: "staff", label: "Staff", icon: Wrench, blurb: "Program staff managing inventory and participants." },
  { role: "admin", label: "Administrator", icon: Shield, blurb: "Organization-wide oversight and reporting." },
] as const;


export const Route = createFileRoute("/signin/")({
  head: () => ({
    meta: [
      { title: "Sign in — OCC Impact Report Tracker" },
      { name: "description", content: "Choose your sign-in: student, parent, volunteer, staff, or administrator." },
      { property: "og:title", content: "Sign in — OCC Impact Report Tracker" },
      { property: "og:description", content: "Each role has its own sign-in page at Ollivier Community Circle." },
    ],
  }),
  component: SignInChooser,
});

function SignInChooser() {
  return (
    <PageShell>
      <PageHeader title="Welcome back" description="Pick the sign-in that matches your role." />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {OPTIONS.map((option) => {
          const Icon = option.icon;
          return (
            <Link key={option.role} to="/signin/$role" params={{ role: option.role }} className="surface-card flex flex-col gap-2 p-6 transition-colors hover:bg-secondary/50">
              <span className="flex size-10 items-center justify-center rounded-full bg-secondary">
                <Icon className="size-5 text-primary" aria-hidden />
              </span>
              <h2 className="text-lg">{option.label}</h2>
              <p className="text-sm text-muted-foreground">{option.blurb}</p>
            </Link>
          );
        })}
      </div>
      <p className="mt-8 text-sm text-muted-foreground">
        New to OCC?{" "}
        <Link to="/signup" className="text-primary underline-offset-2 hover:underline">
          Create an account
        </Link>
      </p>
    </PageShell>
  );
}
