import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Calendar, CheckCircle2, Trash2, Users } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { DataTable, type Column } from "@/components/kit/DataTable";
import { ErrorState, PageSkeleton } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { eventService } from "@/services/eventService";
import type { Event, ProgramSlug } from "@/types";

export const Route = createFileRoute("/admin/events")({
  head: () => ({
    meta: [
      { title: "Events — OCC Impact Report Tracker" },
      { name: "description", content: "Manage community events, distributions, and volunteer gatherings across every program." },
      { property: "og:title", content: "Events — OCC Impact Report Tracker" },
      { property: "og:description", content: "Manage community events, distributions, and volunteer gatherings across every program." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["admin"]}>
      <EventsPage />
    </ProtectedRoute>
  ),
});

const PROGRAMS: ProgramSlug[] = ["fresh-table", "sprout-society", "becoming"];
const PROGRAM_LABEL: Record<ProgramSlug, string> = {
  "fresh-table": "The Fresh Table",
  "sprout-society": "Sprout Society",
  becoming: "Becoming",
};
const TYPES: Event["type"][] = ["distribution", "workshop", "community", "volunteer"];

function fmtDateTime(iso: string) {
  return new Date(iso).toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" });
}

function EventsPage() {
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const [tab, setTab] = useState<"upcoming" | "past">("upcoming");
  const [typeFilter, setTypeFilter] = useState<Event["type"] | "all">("all");
  const [programFilter, setProgramFilter] = useState<ProgramSlug | "all">("all");

  const [createOpen, setCreateOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<Event | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Event | null>(null);

  const load = () => {
    setLoading(true);
    setError(false);
    eventService
      .list()
      .then(setEvents)
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const now = useMemo(() => Date.now(), []);

  const filtered = useMemo(
    () =>
      events.filter((e) => {
        const isUpcoming = new Date(e.startsAt).getTime() >= now;
        if (tab === "upcoming" && !isUpcoming) return false;
        if (tab === "past" && isUpcoming) return false;
        if (typeFilter !== "all" && e.type !== typeFilter) return false;
        if (programFilter !== "all" && e.programId !== programFilter) return false;
        return true;
      }),
    [events, tab, typeFilter, programFilter, now],
  );

  const kpis = useMemo(() => {
    const upcomingCount = events.filter((e) => new Date(e.startsAt).getTime() >= now).length;
    const totalRsvps = events.reduce((sum, e) => sum + e.rsvpCount, 0);
    const withCapacity = events.filter((e) => e.capacity > 0);
    const fill = withCapacity.length
      ? Math.round((withCapacity.reduce((sum, e) => sum + e.rsvpCount / e.capacity, 0) / withCapacity.length) * 100)
      : 0;
    return { upcomingCount, totalRsvps, fill };
  }, [events, now]);

  const columns: Column<Event>[] = useMemo(
    () => [
      { key: "title", header: "Event", sortValue: (e) => e.title },
      {
        key: "type",
        header: "Type",
        sortValue: (e) => e.type,
        render: (e) => <Badge variant="outline" className="capitalize">{e.type}</Badge>,
      },
      {
        key: "program",
        header: "Program",
        sortValue: (e) => e.programId ?? "",
        render: (e) => (e.programId ? PROGRAM_LABEL[e.programId] : "Org-wide"),
        hideOnMobile: true,
      },
      { key: "date", header: "Date", sortValue: (e) => e.startsAt, render: (e) => fmtDateTime(e.startsAt) },
      { key: "location", header: "Location", sortValue: (e) => e.location, hideOnMobile: true },
      {
        key: "rsvp",
        header: "RSVP / Capacity",
        sortValue: (e) => e.rsvpCount / Math.max(1, e.capacity),
        render: (e) => {
          const pct = e.capacity ? Math.min(100, Math.round((e.rsvpCount / e.capacity) * 100)) : 0;
          return (
            <div className="w-32">
              <div className="mb-1 flex justify-between text-xs text-muted-foreground">
                <span>{e.rsvpCount}/{e.capacity}</span>
                <span>{pct}%</span>
              </div>
              <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
                <div className="h-full rounded-full bg-primary" style={{ width: `${pct}%` }} />
              </div>
            </div>
          );
        },
      },
      {
        key: "actions",
        header: "Actions",
        render: (e) => (
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={(ev) => { ev.stopPropagation(); setEditTarget(e); }}>
              Edit
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="text-terracotta hover:text-terracotta"
              onClick={(ev) => { ev.stopPropagation(); setDeleteTarget(e); }}
            >
              <Trash2 className="size-3.5" />
            </Button>
          </div>
        ),
      },
    ],
    [],
  );

  return (
    <PageShell>
      <PageHeader
        title="Events"
        description="Community events, distributions, and volunteer gatherings across every program."
        actions={<Button onClick={() => setCreateOpen(true)}>New event</Button>}
      />

      {loading ? (
        <PageSkeleton />
      ) : error ? (
        <ErrorState onRetry={load} />
      ) : (
        <div className="space-y-6">
          <StatGrid className="sm:grid-cols-3">
            <StatCard label="Upcoming events" value={kpis.upcomingCount} icon={Calendar} />
            <StatCard label="Total RSVPs" value={kpis.totalRsvps} icon={Users} />
            <StatCard label="Avg capacity fill" value={`${kpis.fill}%`} icon={CheckCircle2} />
          </StatGrid>

          <div>
            <SectionHeading title="All events" description="Browse upcoming and past events, filter by type or program." />
            <Tabs value={tab} onValueChange={(v) => setTab(v as "upcoming" | "past")} className="mb-4">
              <TabsList>
                <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                <TabsTrigger value="past">Past</TabsTrigger>
              </TabsList>
            </Tabs>
            <div className="mb-4 flex flex-wrap items-center gap-2">
              <Select value={typeFilter} onValueChange={(v) => setTypeFilter(v as Event["type"] | "all")}>
                <SelectTrigger className="w-44"><SelectValue placeholder="Type" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All types</SelectItem>
                  {TYPES.map((t) => (
                    <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={programFilter} onValueChange={(v) => setProgramFilter(v as ProgramSlug | "all")}>
                <SelectTrigger className="w-48"><SelectValue placeholder="Program" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All programs</SelectItem>
                  {PROGRAMS.map((p) => (
                    <SelectItem key={p} value={p}>{PROGRAM_LABEL[p]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <DataTable
              rows={filtered}
              columns={columns}
              searchKeys={(e) => `${e.title} ${e.location} ${e.address}`}
              onRowClick={(e) => setEditTarget(e)}
              exportName="occ-events"
              emptyTitle="No events match these filters"
              emptyDescription="Try widening your filters or create a new event."
            />
          </div>
        </div>
      )}

      <EventFormDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        onSaved={(e) => {
          setEvents((prev) => [...prev, e]);
          toast.success("Event created");
        }}
      />

      {editTarget && (
        <EventFormDialog
          open={!!editTarget}
          onOpenChange={(v) => !v && setEditTarget(null)}
          event={editTarget}
          onSaved={(e) => {
            setEvents((prev) => prev.map((x) => (x.id === e.id ? e : x)));
            setEditTarget(null);
            toast.success("Event updated");
          }}
        />
      )}

      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete "{deleteTarget?.title}"?</AlertDialogTitle>
            <AlertDialogDescription>This will permanently remove the event and cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={async () => {
                if (!deleteTarget) return;
                await eventService.remove(deleteTarget.id);
                setEvents((prev) => prev.filter((e) => e.id !== deleteTarget.id));
                toast.success("Event deleted");
                setDeleteTarget(null);
              }}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </PageShell>
  );
}

function EventFormDialog({
  open,
  onOpenChange,
  event,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  event?: Event;
  onSaved: (e: Event) => void;
}) {
  const isEdit = !!event;
  const [title, setTitle] = useState(event?.title ?? "");
  const [type, setType] = useState<Event["type"]>(event?.type ?? "community");
  const [programId, setProgramId] = useState<ProgramSlug | "none">(event?.programId ?? "none");
  const [startsAt, setStartsAt] = useState(event ? event.startsAt.slice(0, 16) : "");
  const [endsAt, setEndsAt] = useState(event ? event.endsAt.slice(0, 16) : "");
  const [location, setLocation] = useState(event?.location ?? "");
  const [address, setAddress] = useState(event?.address ?? "");
  const [description, setDescription] = useState(event?.description ?? "");
  const [capacity, setCapacity] = useState(event?.capacity ?? 50);
  const [isPublic, setIsPublic] = useState(event?.isPublic ?? true);
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!title || !startsAt || !endsAt || !location) {
      toast.error("Please fill in all required fields");
      return;
    }
    setSaving(true);
    try {
      const payload = {
        title,
        type,
        programId: programId === "none" ? undefined : programId,
        startsAt: new Date(startsAt).toISOString(),
        endsAt: new Date(endsAt).toISOString(),
        location,
        address,
        description,
        capacity,
        isPublic,
      };
      if (isEdit && event) {
        const updated = await eventService.update(event.id, payload);
        onSaved(updated);
      } else {
        const created = await eventService.create(payload);
        onSaved(created);
      }
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] max-w-lg overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit event" : "New event"}</DialogTitle>
          <DialogDescription>{isEdit ? "Update this event's details." : "Create a new community event, distribution, or gathering."}</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <Label className="mb-1.5 block">Title</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Fall Food Distribution" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="mb-1.5 block">Type</Label>
              <Select value={type} onValueChange={(v) => setType(v as Event["type"])}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TYPES.map((t) => (
                    <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="mb-1.5 block">Program</Label>
              <Select value={programId} onValueChange={(v) => setProgramId(v as ProgramSlug | "none")}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Org-wide</SelectItem>
                  {PROGRAMS.map((p) => (
                    <SelectItem key={p} value={p}>{PROGRAM_LABEL[p]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="mb-1.5 block">Starts</Label>
              <Input type="datetime-local" value={startsAt} onChange={(e) => setStartsAt(e.target.value)} />
            </div>
            <div>
              <Label className="mb-1.5 block">Ends</Label>
              <Input type="datetime-local" value={endsAt} onChange={(e) => setEndsAt(e.target.value)} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="mb-1.5 block">Location name</Label>
              <Input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="OCC Community Hall" />
            </div>
            <div>
              <Label className="mb-1.5 block">Address</Label>
              <Input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="123 Main St" />
            </div>
          </div>
          <div>
            <Label className="mb-1.5 block">Description</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />
          </div>
          <div className="grid grid-cols-2 items-end gap-3">
            <div>
              <Label className="mb-1.5 block">Capacity</Label>
              <Input type="number" min={1} value={capacity} onChange={(e) => setCapacity(Number(e.target.value))} />
            </div>
            <label className="flex items-center gap-2 pb-2 text-sm">
              <Checkbox checked={isPublic} onCheckedChange={(v) => setIsPublic(Boolean(v))} />
              Public event
            </label>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button disabled={saving} onClick={save}>{saving ? "Saving…" : isEdit ? "Save changes" : "Create event"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
