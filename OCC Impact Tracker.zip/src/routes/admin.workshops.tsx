import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Calendar, CheckCircle2, ClipboardList, Star } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { DataTable, type Column } from "@/components/kit/DataTable";
import { ErrorState, PageSkeleton } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { userService } from "@/services/userService";
import { workshopService } from "@/services/workshopService";
import type { Audience, ProgramSlug, User, Workshop, WorkshopEnrollment } from "@/types";

export const Route = createFileRoute("/admin/workshops")({
  head: () => ({
    meta: [
      { title: "Workshops — OCC Impact Report Tracker" },
      { name: "description", content: "Manage workshops across all programs — schedules, rosters, attendance, and feedback." },
      { property: "og:title", content: "Workshops — OCC Impact Report Tracker" },
      { property: "og:description", content: "Manage workshops across all programs — schedules, rosters, attendance, and feedback." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["admin"]}>
      <WorkshopsPage />
    </ProtectedRoute>
  ),
});

const PROGRAMS: ProgramSlug[] = ["fresh-table", "sprout-society", "becoming"];
const PROGRAM_LABEL: Record<ProgramSlug, string> = {
  "fresh-table": "The Fresh Table",
  "sprout-society": "Sprout Society",
  becoming: "Becoming",
};
const AUDIENCES: Audience[] = ["child", "teen", "adult"];
const STATUSES: Workshop["status"][] = ["upcoming", "completed", "cancelled"];

function fmtDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

function WorkshopsPage() {
  const [workshops, setWorkshops] = useState<Workshop[]>([]);
  const [enrollments, setEnrollments] = useState<WorkshopEnrollment[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const [programFilter, setProgramFilter] = useState<ProgramSlug | "all">("all");
  const [statusFilter, setStatusFilter] = useState<Workshop["status"] | "all">("all");

  const [createOpen, setCreateOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<Workshop | null>(null);
  const [rosterTarget, setRosterTarget] = useState<Workshop | null>(null);

  const load = () => {
    setLoading(true);
    setError(false);
    Promise.all([workshopService.list(), workshopService.allEnrollments(), userService.list({})])
      .then(([w, e, u]) => {
        setWorkshops(w);
        setEnrollments(e);
        setUsers(u);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const usersById = useMemo(() => new Map(users.map((u) => [u.id, u])), [users]);

  const filtered = useMemo(
    () =>
      workshops.filter(
        (w) => (programFilter === "all" || w.programId === programFilter) && (statusFilter === "all" || w.status === statusFilter),
      ),
    [workshops, programFilter, statusFilter],
  );

  const kpis = useMemo(() => {
    const total = workshops.length;
    const upcoming = workshops.filter((w) => w.status === "upcoming").length;
    const fillRates = workshops.filter((w) => w.capacity > 0).map((w) => w.enrolledCount / w.capacity);
    const avgFill = fillRates.length ? Math.round((fillRates.reduce((a, b) => a + b, 0) / fillRates.length) * 100) : 0;
    const rated = enrollments.filter((e) => typeof e.feedbackRating === "number");
    const avgFeedback = rated.length ? (rated.reduce((a, e) => a + (e.feedbackRating ?? 0), 0) / rated.length).toFixed(1) : "—";
    return { total, upcoming, avgFill, avgFeedback };
  }, [workshops, enrollments]);

  const columns: Column<Workshop>[] = useMemo(
    () => [
      { key: "title", header: "Workshop", sortValue: (w) => w.title },
      {
        key: "program",
        header: "Program",
        sortValue: (w) => w.programId,
        render: (w) => <Badge variant="outline">{PROGRAM_LABEL[w.programId]}</Badge>,
        hideOnMobile: true,
      },
      { key: "audience", header: "Audience", sortValue: (w) => w.audience, render: (w) => <span className="capitalize">{w.audience}</span>, hideOnMobile: true },
      { key: "facilitator", header: "Facilitator", sortValue: (w) => w.facilitator, hideOnMobile: true },
      { key: "date", header: "Date", sortValue: (w) => w.startsAt, render: (w) => fmtDate(w.startsAt) },
      {
        key: "enrolled",
        header: "Enrolled / Capacity",
        sortValue: (w) => w.enrolledCount / Math.max(1, w.capacity),
        render: (w) => {
          const pct = w.capacity ? Math.min(100, Math.round((w.enrolledCount / w.capacity) * 100)) : 0;
          return (
            <div className="w-32">
              <div className="mb-1 flex justify-between text-xs text-muted-foreground">
                <span>{w.enrolledCount}/{w.capacity}</span>
                <span>{pct}%</span>
              </div>
              <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
                <div className="h-full rounded-full bg-primary" style={{ width: `${pct}%` }} />
              </div>
            </div>
          );
        },
      },
      {
        key: "status",
        header: "Status",
        sortValue: (w) => w.status,
        render: (w) => (
          <Badge
            variant="outline"
            className={
              w.status === "upcoming"
                ? "border-primary/30 bg-accent text-accent-foreground"
                : w.status === "completed"
                  ? "border-sage/50 bg-secondary text-secondary-foreground"
                  : "border-terracotta/35 bg-terracotta/12 text-terracotta"
            }
          >
            {w.status}
          </Badge>
        ),
      },
      {
        key: "actions",
        header: "Actions",
        render: (w) => (
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={(e) => { e.stopPropagation(); setRosterTarget(w); }}>
              Roster
            </Button>
            <Button size="sm" variant="outline" onClick={(e) => { e.stopPropagation(); setEditTarget(w); }}>
              Edit
            </Button>
          </div>
        ),
      },
    ],
    [],
  );

  return (
    <PageShell>
      <PageHeader title="Workshops" description="All workshops across every program — schedule, capacity, roster, and feedback." actions={<Button onClick={() => setCreateOpen(true)}>New workshop</Button>} />

      {loading ? (
        <PageSkeleton />
      ) : error ? (
        <ErrorState onRetry={load} />
      ) : (
        <div className="space-y-6">
          <StatGrid>
            <StatCard label="Total workshops" value={kpis.total} icon={ClipboardList} />
            <StatCard label="Upcoming" value={kpis.upcoming} icon={Calendar} />
            <StatCard label="Avg fill rate" value={`${kpis.avgFill}%`} icon={CheckCircle2} />
            <StatCard label="Avg feedback rating" value={kpis.avgFeedback} icon={Star} />
          </StatGrid>

          <div>
            <SectionHeading title="All workshops" description="Filter by program or status, click a row for details." />
            <div className="mb-4 flex flex-wrap items-center gap-2">
              <Select value={programFilter} onValueChange={(v) => setProgramFilter(v as ProgramSlug | "all")}>
                <SelectTrigger className="w-48"><SelectValue placeholder="Program" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All programs</SelectItem>
                  {PROGRAMS.map((p) => (
                    <SelectItem key={p} value={p}>{PROGRAM_LABEL[p]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as Workshop["status"] | "all")}>
                <SelectTrigger className="w-40"><SelectValue placeholder="Status" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  {STATUSES.map((s) => (
                    <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <DataTable
              rows={filtered}
              columns={columns}
              searchKeys={(w) => `${w.title} ${w.facilitator} ${w.location}`}
              onRowClick={(w) => setRosterTarget(w)}
              exportName="occ-workshops"
              emptyTitle="No workshops match these filters"
              emptyDescription="Try widening your filters or create a new workshop."
            />
          </div>
        </div>
      )}

      <WorkshopFormDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        onSaved={(w) => {
          setWorkshops((prev) => [w, ...prev]);
          toast.success("Workshop created");
        }}
      />

      {editTarget && (
        <WorkshopFormDialog
          open={!!editTarget}
          onOpenChange={(v) => !v && setEditTarget(null)}
          workshop={editTarget}
          onSaved={(w) => {
            setWorkshops((prev) => prev.map((x) => (x.id === w.id ? w : x)));
            setEditTarget(null);
            toast.success("Workshop updated");
          }}
        />
      )}

      {rosterTarget && (
        <RosterDialog
          workshop={rosterTarget}
          open={!!rosterTarget}
          onOpenChange={(v) => !v && setRosterTarget(null)}
          usersById={usersById}
          onUpdated={() => {
            workshopService.allEnrollments().then(setEnrollments);
            workshopService.list().then(setWorkshops);
          }}
        />
      )}
    </PageShell>
  );
}

function WorkshopFormDialog({
  open,
  onOpenChange,
  workshop,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  workshop?: Workshop;
  onSaved: (w: Workshop) => void;
}) {
  const isEdit = !!workshop;
  const [title, setTitle] = useState(workshop?.title ?? "");
  const [programId, setProgramId] = useState<ProgramSlug>(workshop?.programId ?? "fresh-table");
  const [audience, setAudience] = useState<Audience>(workshop?.audience ?? "adult");
  const [description, setDescription] = useState(workshop?.description ?? "");
  const [facilitator, setFacilitator] = useState(workshop?.facilitator ?? "");
  const [startsAt, setStartsAt] = useState(workshop ? workshop.startsAt.slice(0, 16) : "");
  const [durationMinutes, setDurationMinutes] = useState(workshop?.durationMinutes ?? 60);
  const [location, setLocation] = useState(workshop?.location ?? "");
  const [capacity, setCapacity] = useState(workshop?.capacity ?? 20);
  const [status, setStatus] = useState<Workshop["status"]>(workshop?.status ?? "upcoming");
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!title || !facilitator || !startsAt || !location) {
      toast.error("Please fill in all required fields");
      return;
    }
    setSaving(true);
    try {
      const startsAtIso = new Date(startsAt).toISOString();
      if (isEdit && workshop) {
        const updated = await workshopService.update(workshop.id, {
          title,
          programId,
          audience,
          description,
          facilitator,
          startsAt: startsAtIso,
          durationMinutes,
          location,
          capacity,
          status,
        });
        onSaved(updated);
      } else {
        const created = await workshopService.create({
          title,
          programId,
          audience,
          description,
          facilitator,
          startsAt: startsAtIso,
          durationMinutes,
          location,
          capacity,
          status,
          tags: [],
        });
        onSaved(created);
      }
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] max-w-lg overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit workshop" : "New workshop"}</DialogTitle>
          <DialogDescription>{isEdit ? "Update workshop details." : "Schedule a new workshop for a program."}</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <Label className="mb-1.5 block">Title</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Knife Skills 101" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="mb-1.5 block">Program</Label>
              <Select value={programId} onValueChange={(v) => setProgramId(v as ProgramSlug)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PROGRAMS.map((p) => (
                    <SelectItem key={p} value={p}>{PROGRAM_LABEL[p]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="mb-1.5 block">Audience</Label>
              <Select value={audience} onValueChange={(v) => setAudience(v as Audience)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {AUDIENCES.map((a) => (
                    <SelectItem key={a} value={a} className="capitalize">{a}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label className="mb-1.5 block">Description</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />
          </div>
          <div>
            <Label className="mb-1.5 block">Facilitator</Label>
            <Input value={facilitator} onChange={(e) => setFacilitator(e.target.value)} placeholder="Jordan Reyes" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="mb-1.5 block">Date & time</Label>
              <Input type="datetime-local" value={startsAt} onChange={(e) => setStartsAt(e.target.value)} />
            </div>
            <div>
              <Label className="mb-1.5 block">Duration (min)</Label>
              <Input type="number" min={15} value={durationMinutes} onChange={(e) => setDurationMinutes(Number(e.target.value))} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="mb-1.5 block">Location</Label>
              <Input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Community Kitchen" />
            </div>
            <div>
              <Label className="mb-1.5 block">Capacity</Label>
              <Input type="number" min={1} value={capacity} onChange={(e) => setCapacity(Number(e.target.value))} />
            </div>
          </div>
          {isEdit && (
            <div>
              <Label className="mb-1.5 block">Status</Label>
              <Select value={status} onValueChange={(v) => setStatus(v as Workshop["status"])}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {STATUSES.map((s) => (
                    <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button disabled={saving} onClick={save}>{saving ? "Saving…" : isEdit ? "Save changes" : "Create workshop"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function RosterDialog({
  workshop,
  open,
  onOpenChange,
  usersById,
  onUpdated,
}: {
  workshop: Workshop;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  usersById: Map<string, User>;
  onUpdated: () => void;
}) {
  const [roster, setRoster] = useState<WorkshopEnrollment[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);

  const load = () => {
    setLoading(true);
    workshopService
      .roster(workshop.id)
      .then(setRoster)
      .finally(() => setLoading(false));
  };

  useEffect(load, [workshop.id]);

  const toggle = (userId: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(userId)) next.delete(userId);
      else next.add(userId);
      return next;
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Roster — {workshop.title}</DialogTitle>
          <DialogDescription>{fmtDate(workshop.startsAt)} · {workshop.facilitator} · {workshop.enrolledCount}/{workshop.capacity} enrolled</DialogDescription>
        </DialogHeader>

        {loading ? (
          <p className="text-sm text-muted-foreground">Loading roster…</p>
        ) : roster.length === 0 ? (
          <p className="text-sm text-muted-foreground">No one has registered for this workshop yet.</p>
        ) : (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="stat-label">Enrollees ({roster.length})</p>
              <Button
                size="sm"
                disabled={selected.size === 0 || busy}
                onClick={async () => {
                  setBusy(true);
                  try {
                    const n = await workshopService.bulkMarkAttendance(workshop.id, [...selected]);
                    toast.success(`Marked ${n} attendee(s) as attended`);
                    setSelected(new Set());
                    load();
                    onUpdated();
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                Mark selected attended
              </Button>
            </div>
            <div className="divide-y divide-border rounded-lg border border-border">
              {roster.map((e) => {
                const u = usersById.get(e.userId);
                return (
                  <div key={e.id} className="flex flex-wrap items-center justify-between gap-2 px-3 py-2">
                    <label className="flex min-w-40 items-center gap-2">
                      <Checkbox checked={selected.has(e.userId)} onCheckedChange={() => toggle(e.userId)} />
                      <span className="text-sm">{u?.fullName ?? e.userId}</span>
                    </label>
                    <div className="flex items-center gap-2">
                      <Badge
                        variant="outline"
                        className={
                          e.status === "attended"
                            ? "border-primary/30 bg-accent text-accent-foreground"
                            : e.status === "no-show"
                              ? "border-terracotta/35 bg-terracotta/12 text-terracotta"
                              : "border-sage/50 bg-secondary text-secondary-foreground"
                        }
                      >
                        {e.status}
                      </Badge>
                      {typeof e.feedbackRating === "number" && (
                        <span className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Star className="size-3 text-gold" /> {e.feedbackRating}
                        </span>
                      )}
                      <Select
                        value={e.status}
                        onValueChange={async (v) => {
                          await workshopService.markAttendance(e.id, v as WorkshopEnrollment["status"]);
                          toast.success("Attendance updated");
                          load();
                          onUpdated();
                        }}
                      >
                        <SelectTrigger className="h-8 w-32"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="registered">Registered</SelectItem>
                          <SelectItem value="attended">Attended</SelectItem>
                          <SelectItem value="no-show">No-show</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
