import { createFileRoute, Link } from "@tanstack/react-router";
import { AlertTriangle, Boxes, CalendarClock, ClipboardList, HandHeart, PackageCheck, Users } from "lucide-react";
import { useEffect, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { ChartCard, CHART_COLORS, CHART_SERIES, axisProps, tooltipStyle } from "@/components/kit/ChartCard";
import { ErrorState, PageSkeleton } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/context/AuthContext";
import { analyticsService } from "@/services/analyticsService";
import { programBySlug } from "@/data/programs";

export const Route = createFileRoute("/admin/")({
  head: () => ({
    meta: [
      { title: "Admin overview — OCC Impact Report Tracker" },
      { name: "description", content: "Organization-wide KPIs, growth trends, and alerts for OCC administrators." },
      { property: "og:title", content: "Admin overview — OCC Impact Report Tracker" },
      { property: "og:description", content: "Organization-wide KPIs, growth trends, and alerts for OCC administrators." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["admin"]}>
      <Dashboard />
    </ProtectedRoute>
  ),
});

type Overview = Awaited<ReturnType<typeof analyticsService.organizationOverview>>;

const PROGRAM_LABEL: Record<string, string> = {
  "fresh-table": "The Fresh Table",
  "sprout-society": "Sprout Society",
  becoming: "Becoming",
};

function Dashboard() {
  const { user } = useAuth();
  const [data, setData] = useState<Overview | null>(null);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    setError(false);
    analyticsService
      .organizationOverview()
      .then(setData)
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  return (
    <PageShell>
      <PageHeader
        title={`Welcome, ${user?.fullName ?? "friend"}`}
        description="A full organization view across every program — enrollment, outcomes, inventory, and what needs your attention today."
      />

      {loading ? (
        <PageSkeleton />
      ) : error || !data ? (
        <ErrorState onRetry={load} />
      ) : (
        <div className="space-y-8">
          <StatGrid className="lg:grid-cols-3 xl:grid-cols-6">
            <StatCard label="Total participants" value={data.kpis.totalParticipants} icon={Users} />
            <StatCard label="Active this month" value={data.kpis.activeThisMonth} icon={Users} />
            <StatCard label="Assessments completed" value={data.kpis.assessmentsCompleted} icon={ClipboardList} />
            <StatCard label="Households served" value={data.kpis.householdsServed.toLocaleString()} icon={HandHeart} />
            <StatCard label="Pounds distributed" value={data.kpis.poundsDistributed.toLocaleString()} icon={PackageCheck} />
            <StatCard label="Volunteer hours" value={Math.round(data.kpis.volunteerHours).toLocaleString()} icon={CalendarClock} />
          </StatGrid>

          <div>
            <SectionHeading title="Program trends" description="Growth, participation, and outcomes across all three programs." />
            <div className="grid gap-4 lg:grid-cols-2">
              <ChartCard
                title="Enrollment growth by program"
                description="Cumulative participants enrolled each month."
                data={data.enrollmentGrowth.map((p) => ({
                  Month: p.label,
                  "Fresh Table": p["fresh-table"],
                  "Sprout Society": p["sprout-society"],
                  Becoming: p.becoming,
                }))}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data.enrollmentGrowth}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="label" {...axisProps} />
                    <YAxis {...axisProps} allowDecimals={false} />
                    <Tooltip {...tooltipStyle} />
                    <Legend wrapperStyle={{ fontSize: 12 }} />
                    <Line type="monotone" dataKey="fresh-table" name="Fresh Table" stroke={CHART_COLORS.hunter} strokeWidth={2} dot={false} />
                    <Line type="monotone" dataKey="sprout-society" name="Sprout Society" stroke={CHART_COLORS.sage} strokeWidth={2} dot={false} />
                    <Line type="monotone" dataKey="becoming" name="Becoming" stroke={CHART_COLORS.terracotta} strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </ChartCard>

              <ChartCard
                title="Participants by program"
                description="Current active participant mix."
                data={data.participantsByProgram.map((p) => ({ Program: PROGRAM_LABEL[p.name] ?? p.name, Participants: p.value }))}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Tooltip {...tooltipStyle} />
                    <Legend wrapperStyle={{ fontSize: 12 }} />
                    <Pie
                      data={data.participantsByProgram.map((p) => ({ name: PROGRAM_LABEL[p.name] ?? p.name, value: p.value }))}
                      dataKey="value"
                      nameKey="name"
                      outerRadius={90}
                      label
                    >
                      {data.participantsByProgram.map((p, i) => (
                        <Cell key={p.name} fill={CHART_SERIES[i % CHART_SERIES.length]} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </ChartCard>

              <ChartCard
                title="Average score by program"
                description="Normalized average assessment score per program (0–100)."
                data={data.avgScoreByProgram.map((p) => ({ Program: PROGRAM_LABEL[p.program] ?? p.program, "Average score": p.average, Attempts: p.attempts }))}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.avgScoreByProgram.map((p) => ({ ...p, label: PROGRAM_LABEL[p.program] ?? p.program }))}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="label" {...axisProps} />
                    <YAxis {...axisProps} domain={[0, 100]} />
                    <Tooltip {...tooltipStyle} />
                    <Bar dataKey="average" name="Average score" fill={CHART_COLORS.hunter} radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartCard>

              <ChartCard
                title="Attendance rate"
                description="Percentage of scheduled sessions attended, by month."
                data={data.attendanceByMonth.map((p) => ({ Month: p.label, "Attendance rate": `${p.rate}%`, Sessions: p.sessions }))}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data.attendanceByMonth}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="label" {...axisProps} />
                    <YAxis {...axisProps} domain={[0, 100]} unit="%" />
                    <Tooltip {...tooltipStyle} formatter={(v: number) => [`${v}%`, "Attendance"]} />
                    <Line type="monotone" dataKey="rate" name="Attendance rate" stroke={CHART_COLORS.gold} strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </ChartCard>

              <ChartCard
                title="Assessments completed"
                description="Completed assessments by month across all programs."
                className="lg:col-span-2"
                data={data.assessmentsByMonth.map((p) => ({ Month: p.label, Completed: p.completed }))}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.assessmentsByMonth}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="label" {...axisProps} />
                    <YAxis {...axisProps} allowDecimals={false} />
                    <Tooltip {...tooltipStyle} />
                    <Bar dataKey="completed" name="Completed" fill={CHART_COLORS.hunterSoft} radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartCard>
            </div>
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <div className="surface-card p-5">
              <SectionHeading
                title="Needs attention"
                description="Items across the organization that may need a follow-up."
              />
              <StatGrid className="mb-4 sm:grid-cols-2 lg:grid-cols-4">
                <StatCard label="Flagged assessments" value={data.needsAttention.flagged} icon={AlertTriangle} size="sm" />
                <StatCard label="Low stock items" value={data.needsAttention.lowStock} icon={Boxes} size="sm" />
                <StatCard label="Overdue tasks" value={data.needsAttention.overdueTasks} icon={ClipboardList} size="sm" />
                <StatCard label="Under-capacity workshops" value={data.needsAttention.underCapacity} icon={Users} size="sm" />
              </StatGrid>

              <div className="space-y-4">
                {data.needsAttention.flaggedAttempts.length > 0 && (
                  <div>
                    <p className="stat-label mb-2">Flagged assessments awaiting review</p>
                    <ul className="space-y-1.5 text-sm">
                      {data.needsAttention.flaggedAttempts.map((a) => (
                        <li key={a.id} className="flex items-center justify-between gap-2 rounded-lg border border-terracotta/30 bg-terracotta/5 px-3 py-2">
                          <span>{a.assessmentId} — band: {a.band || "n/a"}</span>
                          <Badge variant="outline" className="border-terracotta/40 text-terracotta">Flagged</Badge>
                        </li>
                      ))}
                    </ul>
                    <Link to="/admin/assessments" className="mt-2 inline-block text-xs text-primary underline underline-offset-2">
                      Review in Assessments →
                    </Link>
                  </div>
                )}
                {data.needsAttention.lowStockItems.length > 0 && (
                  <div>
                    <p className="stat-label mb-2">Low stock items</p>
                    <ul className="space-y-1.5 text-sm">
                      {data.needsAttention.lowStockItems.map((i) => (
                        <li key={i.id} className="flex items-center justify-between gap-2 rounded-lg border border-border bg-secondary/40 px-3 py-2">
                          <span>{i.name}</span>
                          <span className="text-xs text-muted-foreground">{i.quantityOnHand} / {i.parLevel} {i.unitLabel}</span>
                        </li>
                      ))}
                    </ul>
                    <Link to="/admin/inventory" className="mt-2 inline-block text-xs text-primary underline underline-offset-2">
                      Manage inventory →
                    </Link>
                  </div>
                )}
                {data.needsAttention.overdueTaskList.length > 0 && (
                  <div>
                    <p className="stat-label mb-2">Overdue tasks</p>
                    <ul className="space-y-1.5 text-sm">
                      {data.needsAttention.overdueTaskList.map((t) => (
                        <li key={t.id} className="flex items-center justify-between gap-2 rounded-lg border border-border bg-secondary/40 px-3 py-2">
                          <span>{t.title}</span>
                          <span className="text-xs text-muted-foreground">Due {new Date(t.dueDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
                        </li>
                      ))}
                    </ul>
                    <Link to="/admin/tasks" className="mt-2 inline-block text-xs text-primary underline underline-offset-2">
                      View tasks →
                    </Link>
                  </div>
                )}
                {data.needsAttention.flagged + data.needsAttention.lowStock + data.needsAttention.overdueTasks + data.needsAttention.underCapacity === 0 && (
                  <p className="text-sm text-muted-foreground">Nothing needs attention right now. Great work!</p>
                )}
              </div>
            </div>

            <div className="surface-card p-5">
              <SectionHeading title="Recent activity" description="The latest happenings across the organization." />
              <ul className="space-y-3">
                {data.recentActivity.map((a) => (
                  <li key={a.id} className="flex items-start gap-3 border-b border-border/60 pb-3 last:border-0 last:pb-0">
                    <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-sage" />
                    <div>
                      <p className="text-sm">{a.text}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(a.when).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                      </p>
                    </div>
                  </li>
                ))}
                {data.recentActivity.length === 0 && <p className="text-sm text-muted-foreground">No recent activity yet.</p>}
              </ul>
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            {(["fresh-table", "sprout-society", "becoming"] as const).map((slug) => {
              const program = programBySlug(slug);
              return (
                <Link key={slug} to="/admin/programs" className="surface-card block p-5 transition-colors hover:border-primary/40">
                  <p className="text-sm text-muted-foreground">{program?.tagline}</p>
                  <h3 className="mt-1 text-lg">{program?.name}</h3>
                  <p className="mt-2 text-xs text-primary underline underline-offset-2">Open program dashboard →</p>
                </Link>
              );
            })}
          </div>
        </div>
      )}
    </PageShell>
  );
}
