import { createFileRoute } from "@tanstack/react-router";
import { CheckCircle2, Clock, ListTodo, MessageSquare } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { PageSkeleton, EmptyState } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/context/AuthContext";
import { userService } from "@/services/userService";
import { isOverdue, taskService } from "@/services/taskService";
import type { Task, User } from "@/types";

export const Route = createFileRoute("/staff/tasks")({
  head: () => ({
    meta: [
      { title: "My tasks — OCC Impact Report Tracker" },
      { name: "description", content: "Track and complete tasks assigned to you by your admin." },
      { property: "og:title", content: "My tasks — OCC Impact Report Tracker" },
      { property: "og:description", content: "Staff task board with statuses, comments, and completion notes." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["staff"]}>
      <TasksPage />
    </ProtectedRoute>
  ),
});

const statusTone: Record<Task["status"], string> = {
  todo: "bg-secondary text-secondary-foreground border-sage/50",
  "in-progress": "bg-accent text-accent-foreground border-primary/25",
  blocked: "bg-terracotta/16 text-terracotta border-terracotta/40",
  done: "bg-accent text-accent-foreground border-primary/25",
};

const priorityTone: Record<Task["priority"], string> = {
  low: "bg-secondary text-secondary-foreground border-sage/50",
  medium: "bg-accent text-accent-foreground border-primary/25",
  high: "bg-terracotta/16 text-terracotta border-terracotta/40",
};

function TasksPage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [statusFilter, setStatusFilter] = useState<Task["status"] | "all">("all");
  const [priorityFilter, setPriorityFilter] = useState<Task["priority"] | "all">("all");
  const [detail, setDetail] = useState<Task | null>(null);
  const [comment, setComment] = useState("");
  const [completionNote, setCompletionNote] = useState("");

  const load = async () => {
    if (!user) return;
    const [t, u] = await Promise.all([taskService.listForUser(user.id), userService.list()]);
    setTasks(t);
    setUsers(u);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, [user]);

  const filtered = useMemo(() => {
    return tasks.filter((t) => {
      if (statusFilter !== "all" && t.status !== statusFilter) return false;
      if (priorityFilter !== "all" && t.priority !== priorityFilter) return false;
      return true;
    });
  }, [tasks, statusFilter, priorityFilter]);

  if (loading || !user) {
    return (
      <PageShell>
        <PageHeader title="My tasks" description="Loading your tasks…" />
        <PageSkeleton />
      </PageShell>
    );
  }

  const userName = (id: string) => users.find((u) => u.id === id)?.fullName ?? "Admin";
  const openTasks = tasks.filter((t) => t.status !== "done");
  const overdue = tasks.filter(isOverdue);
  const done = tasks.filter((t) => t.status === "done");

  const changeStatus = async (task: Task, status: Task["status"]) => {
    if (status === "done") {
      setDetail(task);
      setCompletionNote("");
      return;
    }
    try {
      await taskService.updateStatus(task.id, status);
      toast.success("Task updated");
      await load();
      if (detail?.id === task.id) {
        const fresh = await taskService.get(task.id);
        setDetail(fresh);
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not update task");
    }
  };

  const completeTask = async () => {
    if (!detail) return;
    try {
      await taskService.updateStatus(detail.id, "done", completionNote);
      toast.success("Task marked complete");
      const fresh = await taskService.get(detail.id);
      setDetail(fresh);
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not complete task");
    }
  };

  const addComment = async () => {
    if (!detail || !comment.trim() || !user) return;
    try {
      await taskService.addComment(detail.id, user.id, comment.trim());
      setComment("");
      const fresh = await taskService.get(detail.id);
      setDetail(fresh);
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not add comment");
    }
  };

  return (
    <PageShell>
      <PageHeader title="My tasks" description="Tasks assigned to you by your admin." />

      <StatGrid>
        <StatCard label="Open tasks" value={openTasks.length} icon={ListTodo} />
        <StatCard label="Overdue" value={overdue.length} icon={Clock} />
        <StatCard label="Completed" value={done.length} icon={CheckCircle2} />
        <StatCard label="Total assigned" value={tasks.length} icon={ListTodo} />
      </StatGrid>

      <div className="mt-6 mb-4 flex flex-wrap gap-2">
        <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as Task["status"] | "all")}>
          <SelectTrigger className="w-44">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="todo">To do</SelectItem>
            <SelectItem value="in-progress">In progress</SelectItem>
            <SelectItem value="blocked">Blocked</SelectItem>
            <SelectItem value="done">Done</SelectItem>
          </SelectContent>
        </Select>
        <Select value={priorityFilter} onValueChange={(v) => setPriorityFilter(v as Task["priority"] | "all")}>
          <SelectTrigger className="w-44">
            <SelectValue placeholder="Priority" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All priorities</SelectItem>
            <SelectItem value="low">Low</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="high">High</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {filtered.length === 0 ? (
        <EmptyState title="No tasks match" description="Adjust your filters or check back later for new tasks." />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((task) => (
            <div key={task.id} className="surface-card space-y-3 p-5">
              <div className="flex items-start justify-between gap-2">
                <h3 className="text-base font-medium text-foreground">{task.title}</h3>
                <Badge variant="outline" className={priorityTone[task.priority]}>
                  {task.priority}
                </Badge>
              </div>
              <p className="line-clamp-2 text-sm text-muted-foreground">{task.description}</p>
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>Assigned by {userName(task.assignedBy)}</span>
                <span className={isOverdue(task) ? "text-terracotta" : ""}>
                  Due {new Date(task.dueDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="outline" className={statusTone[task.status]}>
                  {task.status}
                </Badge>
                <Select value={task.status} onValueChange={(v) => changeStatus(task, v as Task["status"])}>
                  <SelectTrigger className="ml-auto h-8 w-36 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todo">To do</SelectItem>
                    <SelectItem value="in-progress">In progress</SelectItem>
                    <SelectItem value="blocked">Blocked</SelectItem>
                    <SelectItem value="done">Done</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button
                size="sm"
                variant="outline"
                className="w-full"
                onClick={() => {
                  setDetail(task);
                  setCompletionNote(task.completionNote ?? "");
                }}
              >
                <MessageSquare className="mr-1.5 size-4" aria-hidden /> View details ({task.comments.length})
              </Button>
            </div>
          ))}
        </div>
      )}

      <Dialog open={!!detail} onOpenChange={(open) => !open && setDetail(null)}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>{detail?.title}</DialogTitle>
          </DialogHeader>
          {detail && (
            <div className="max-h-[60vh] space-y-4 overflow-y-auto pr-1">
              <p className="text-sm text-muted-foreground">{detail.description}</p>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className={statusTone[detail.status]}>
                  {detail.status}
                </Badge>
                <Badge variant="outline" className={priorityTone[detail.priority]}>
                  {detail.priority} priority
                </Badge>
                <Badge variant="outline">Due {new Date(detail.dueDate).toLocaleDateString("en-US")}</Badge>
              </div>
              {detail.status !== "done" && (
                <div className="space-y-2 rounded-lg border border-border p-3">
                  <p className="text-sm font-medium text-foreground">Mark complete</p>
                  <Textarea
                    placeholder="Completion notes (optional)"
                    value={completionNote}
                    onChange={(e) => setCompletionNote(e.target.value)}
                  />
                  <Button size="sm" onClick={completeTask}>
                    <CheckCircle2 className="mr-1.5 size-4" aria-hidden /> Mark done
                  </Button>
                </div>
              )}
              {detail.completionNote && (
                <div className="rounded-lg bg-accent/40 p-3 text-sm">
                  <p className="text-xs font-medium uppercase text-muted-foreground">Completion note</p>
                  <p className="mt-1">{detail.completionNote}</p>
                </div>
              )}
              <div>
                <p className="mb-2 text-sm font-medium text-foreground">Comments</p>
                <div className="space-y-2">
                  {detail.comments.length === 0 && <p className="text-xs text-muted-foreground">No comments yet.</p>}
                  {detail.comments.map((c) => (
                    <div key={c.id} className="rounded-lg border border-border p-2.5 text-sm">
                      <p className="text-xs font-medium text-foreground">{userName(c.authorId)}</p>
                      <p className="mt-0.5 text-muted-foreground">{c.body}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-3 flex gap-2">
                  <Textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Add a comment…" />
                </div>
                <Button size="sm" variant="outline" className="mt-2" onClick={addComment} disabled={!comment.trim()}>
                  Add comment
                </Button>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDetail(null)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageShell>
  );
}
