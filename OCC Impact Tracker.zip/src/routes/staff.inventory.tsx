import { createFileRoute } from "@tanstack/react-router";
import { Minus, Package, Plus, Trash2, Truck } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { DataTable, type Column } from "@/components/kit/DataTable";
import { PageSkeleton } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/context/AuthContext";
import { inventoryService, stockHealth, type StockHealth } from "@/services/inventoryService";
import { inventoryCategories } from "@/data/inventory-catalog";
import type { InventoryItem, InventoryTransaction } from "@/types";

export const Route = createFileRoute("/staff/inventory")({
  head: () => ({
    meta: [
      { title: "Pantry inventory — OCC Impact Report Tracker" },
      { name: "description", content: "Restock, adjust, and distribute pantry inventory for OCC programs." },
      { property: "og:title", content: "Pantry inventory — OCC Impact Report Tracker" },
      { property: "og:description", content: "Manage stock levels, restocks, and distributions for the food pantry." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["staff"]}>
      <InventoryPage />
    </ProtectedRoute>
  ),
});

const healthTone: Record<StockHealth, string> = {
  healthy: "bg-accent text-accent-foreground border-primary/25",
  watch: "bg-secondary text-secondary-foreground border-sage/50",
  low: "bg-terracotta/16 text-terracotta border-terracotta/40",
};

interface RestockRow {
  itemId: string;
  quantity: string;
  source: string;
  notes: string;
  date: string;
}

interface DistLine {
  itemId: string;
  quantity: string;
}

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

function InventoryPage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [transactions, setTransactions] = useState<InventoryTransaction[]>([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");

  const [restockOpen, setRestockOpen] = useState(false);
  const [restockRows, setRestockRows] = useState<RestockRow[]>([
    { itemId: "", quantity: "", source: "", notes: "", date: todayIso() },
  ]);
  const [savingRestock, setSavingRestock] = useState(false);

  const [adjustOpen, setAdjustOpen] = useState(false);
  const [adjustItem, setAdjustItem] = useState<InventoryItem | null>(null);
  const [adjustType, setAdjustType] = useState<"adjustment" | "spoilage">("adjustment");
  const [adjustQty, setAdjustQty] = useState("");
  const [adjustNotes, setAdjustNotes] = useState("");
  const [savingAdjust, setSavingAdjust] = useState(false);

  const [distOpen, setDistOpen] = useState(false);
  const [distLines, setDistLines] = useState<DistLine[]>([{ itemId: "", quantity: "" }]);
  const [distHouseholds, setDistHouseholds] = useState("");
  const [distIndividuals, setDistIndividuals] = useState("");
  const [distVolunteers, setDistVolunteers] = useState("");
  const [distZip, setDistZip] = useState("");
  const [distNotes, setDistNotes] = useState("");
  const [distDate, setDistDate] = useState(todayIso());
  const [savingDist, setSavingDist] = useState(false);

  const load = async () => {
    const [inv, txns] = await Promise.all([inventoryService.list(), inventoryService.transactions()]);
    setItems(inv);
    setTransactions(txns);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    return items.filter((i) => {
      if (category !== "all" && i.category !== category) return false;
      if (search && !i.name.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [items, search, category]);

  if (loading || !user) {
    return (
      <PageShell>
        <PageHeader title="Pantry inventory" description="Loading inventory…" />
        <PageSkeleton />
      </PageShell>
    );
  }

  const totalItems = items.length;
  const lowStock = items.filter((i) => stockHealth(i) === "low").length;
  const poundsOnHand = Math.round(items.reduce((s, i) => s + i.quantityOnHand * i.lbsPerUnit, 0));
  const restocksThisMonth = transactions.filter(
    (t) => t.type === "restock" && new Date(t.occurredAt).getMonth() === new Date().getMonth(),
  ).length;

  const itemColumns: Column<InventoryItem>[] = [
    { key: "name", header: "Item", sortValue: (r) => r.name },
    { key: "category", header: "Category", sortValue: (r) => r.category },
    {
      key: "onHand",
      header: "On hand",
      sortValue: (r) => r.quantityOnHand,
      render: (r) => `${r.quantityOnHand} ${r.unitLabel}`,
    },
    { key: "par", header: "Par level", sortValue: (r) => r.parLevel },
    {
      key: "health",
      header: "Health",
      sortValue: (r) => stockHealth(r),
      render: (r) => (
        <Badge variant="outline" className={healthTone[stockHealth(r)]}>
          {stockHealth(r)}
        </Badge>
      ),
    },
    {
      key: "actions",
      header: "Actions",
      render: (r) => (
        <Button
          size="sm"
          variant="outline"
          onClick={() => {
            setAdjustItem(r);
            setAdjustType("adjustment");
            setAdjustQty("");
            setAdjustNotes("");
            setAdjustOpen(true);
          }}
        >
          Adjust
        </Button>
      ),
    },
  ];

  const txnColumns: Column<InventoryTransaction>[] = [
    {
      key: "date",
      header: "Date",
      sortValue: (r) => r.occurredAt,
      render: (r) => new Date(r.occurredAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
    },
    {
      key: "item",
      header: "Item",
      sortValue: (r) => items.find((i) => i.id === r.itemId)?.name ?? "—",
      render: (r) => items.find((i) => i.id === r.itemId)?.name ?? "Unknown item",
    },
    { key: "type", header: "Type", sortValue: (r) => r.type, render: (r) => <Badge variant="outline">{r.type}</Badge> },
    {
      key: "quantity",
      header: "Quantity",
      sortValue: (r) => r.quantity,
      render: (r) => `${r.type === "distribution" || r.type === "spoilage" ? "-" : "+"}${r.quantity} ${r.unit}`,
    },
    { key: "notes", header: "Notes", sortValue: (r) => r.notes, hideOnMobile: true },
  ];

  const addRestockRow = () =>
    setRestockRows((rows) => [...rows, { itemId: "", quantity: "", source: "", notes: "", date: todayIso() }]);
  const removeRestockRow = (idx: number) => setRestockRows((rows) => rows.filter((_, i) => i !== idx));
  const updateRestockRow = (idx: number, patch: Partial<RestockRow>) =>
    setRestockRows((rows) => rows.map((r, i) => (i === idx ? { ...r, ...patch } : r)));

  const submitRestock = async () => {
    const valid = restockRows.filter((r) => r.itemId && Number(r.quantity) > 0);
    if (valid.length === 0) {
      toast.error("Add at least one valid line with an item and quantity.");
      return;
    }
    setSavingRestock(true);
    try {
      await inventoryService.submitRestockBatch(
        valid.map((r) => ({
          itemId: r.itemId,
          quantity: Number(r.quantity),
          source: r.source,
          notes: r.notes,
          occurredAt: new Date(r.date).toISOString(),
        })),
        user.id,
      );
      toast.success(`Recorded ${valid.length} restock line${valid.length === 1 ? "" : "s"}`);
      setRestockOpen(false);
      setRestockRows([{ itemId: "", quantity: "", source: "", notes: "", date: todayIso() }]);
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not submit restock");
    } finally {
      setSavingRestock(false);
    }
  };

  const submitAdjust = async () => {
    if (!adjustItem || !Number(adjustQty)) {
      toast.error("Enter a quantity to adjust.");
      return;
    }
    setSavingAdjust(true);
    try {
      await inventoryService.adjust(adjustItem.id, Number(adjustQty), adjustType, user.id, adjustNotes || adjustType);
      toast.success("Inventory adjusted");
      setAdjustOpen(false);
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not adjust item");
    } finally {
      setSavingAdjust(false);
    }
  };

  const addDistLine = () => setDistLines((rows) => [...rows, { itemId: "", quantity: "" }]);
  const removeDistLine = (idx: number) => setDistLines((rows) => rows.filter((_, i) => i !== idx));
  const updateDistLine = (idx: number, patch: Partial<DistLine>) =>
    setDistLines((rows) => rows.map((r, i) => (i === idx ? { ...r, ...patch } : r)));

  const submitDistribution = async () => {
    const valid = distLines.filter((l) => l.itemId && Number(l.quantity) > 0);
    if (valid.length === 0) {
      toast.error("Add at least one item line.");
      return;
    }
    setSavingDist(true);
    try {
      await inventoryService.recordDistribution({
        lines: valid.map((l) => ({ itemId: l.itemId, quantity: Number(l.quantity) })),
        staffId: user.id,
        eventId: "manual",
        householdsServed: Number(distHouseholds) || 0,
        individualsServed: Number(distIndividuals) || 0,
        volunteersPresent: Number(distVolunteers) || 0,
        zip: distZip,
        notes: distNotes,
        occurredAt: new Date(distDate).toISOString(),
      });
      toast.success("Distribution recorded");
      setDistOpen(false);
      setDistLines([{ itemId: "", quantity: "" }]);
      setDistHouseholds("");
      setDistIndividuals("");
      setDistVolunteers("");
      setDistZip("");
      setDistNotes("");
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not record distribution");
    } finally {
      setSavingDist(false);
    }
  };

  return (
    <PageShell>
      <PageHeader
        title="Pantry inventory"
        description="Restock, adjust, and record distributions for the food pantry."
        actions={
          <>
            <Dialog open={restockOpen} onOpenChange={setRestockOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-1.5 size-4" aria-hidden /> Restock batch
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Record a restock batch</DialogTitle>
                </DialogHeader>
                <div className="max-h-[60vh] space-y-4 overflow-y-auto pr-1">
                  {restockRows.map((row, idx) => (
                    <div key={idx} className="grid gap-2 rounded-lg border border-border p-3 sm:grid-cols-6">
                      <div className="sm:col-span-2">
                        <Label className="text-xs">Item</Label>
                        <Select value={row.itemId} onValueChange={(v) => updateRestockRow(idx, { itemId: v })}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select item" />
                          </SelectTrigger>
                          <SelectContent>
                            {items.map((i) => (
                              <SelectItem key={i.id} value={i.id}>
                                {i.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-xs">
                          Qty {row.itemId ? `(${items.find((i) => i.id === row.itemId)?.unitLabel})` : ""}
                        </Label>
                        <Input
                          type="number"
                          min="0"
                          value={row.quantity}
                          onChange={(e) => updateRestockRow(idx, { quantity: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Source</Label>
                        <Input value={row.source} onChange={(e) => updateRestockRow(idx, { source: e.target.value })} />
                      </div>
                      <div>
                        <Label className="text-xs">Date</Label>
                        <Input type="date" value={row.date} onChange={(e) => updateRestockRow(idx, { date: e.target.value })} />
                      </div>
                      <div className="sm:col-span-5">
                        <Label className="text-xs">Notes</Label>
                        <Input value={row.notes} onChange={(e) => updateRestockRow(idx, { notes: e.target.value })} />
                      </div>
                      <div className="flex items-end justify-end">
                        <Button variant="ghost" size="icon" onClick={() => removeRestockRow(idx)} disabled={restockRows.length === 1}>
                          <Trash2 className="size-4" aria-hidden />
                        </Button>
                      </div>
                    </div>
                  ))}
                  <Button variant="outline" size="sm" onClick={addRestockRow}>
                    <Plus className="mr-1.5 size-4" aria-hidden /> Add line
                  </Button>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setRestockOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={submitRestock} disabled={savingRestock}>
                    {savingRestock ? "Saving…" : "Submit batch"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Dialog open={distOpen} onOpenChange={setDistOpen}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Truck className="mr-1.5 size-4" aria-hidden /> Record distribution
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Record a distribution</DialogTitle>
                </DialogHeader>
                <div className="max-h-[60vh] space-y-4 overflow-y-auto pr-1">
                  {distLines.map((line, idx) => (
                    <div key={idx} className="grid gap-2 rounded-lg border border-border p-3 sm:grid-cols-5">
                      <div className="sm:col-span-3">
                        <Label className="text-xs">Item</Label>
                        <Select value={line.itemId} onValueChange={(v) => updateDistLine(idx, { itemId: v })}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select item" />
                          </SelectTrigger>
                          <SelectContent>
                            {items.map((i) => (
                              <SelectItem key={i.id} value={i.id}>
                                {i.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-xs">
                          Qty {line.itemId ? `(${items.find((i) => i.id === line.itemId)?.unitLabel})` : ""}
                        </Label>
                        <Input
                          type="number"
                          min="0"
                          value={line.quantity}
                          onChange={(e) => updateDistLine(idx, { quantity: e.target.value })}
                        />
                      </div>
                      <div className="flex items-end justify-end">
                        <Button variant="ghost" size="icon" onClick={() => removeDistLine(idx)} disabled={distLines.length === 1}>
                          <Trash2 className="size-4" aria-hidden />
                        </Button>
                      </div>
                    </div>
                  ))}
                  <Button variant="outline" size="sm" onClick={addDistLine}>
                    <Plus className="mr-1.5 size-4" aria-hidden /> Add line
                  </Button>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div>
                      <Label className="text-xs">Households served</Label>
                      <Input type="number" min="0" value={distHouseholds} onChange={(e) => setDistHouseholds(e.target.value)} />
                    </div>
                    <div>
                      <Label className="text-xs">Individuals served</Label>
                      <Input type="number" min="0" value={distIndividuals} onChange={(e) => setDistIndividuals(e.target.value)} />
                    </div>
                    <div>
                      <Label className="text-xs">Volunteers present</Label>
                      <Input type="number" min="0" value={distVolunteers} onChange={(e) => setDistVolunteers(e.target.value)} />
                    </div>
                    <div>
                      <Label className="text-xs">ZIP code</Label>
                      <Input value={distZip} onChange={(e) => setDistZip(e.target.value)} />
                    </div>
                    <div>
                      <Label className="text-xs">Date</Label>
                      <Input type="date" value={distDate} onChange={(e) => setDistDate(e.target.value)} />
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs">Notes</Label>
                    <Textarea value={distNotes} onChange={(e) => setDistNotes(e.target.value)} />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setDistOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={submitDistribution} disabled={savingDist}>
                    {savingDist ? "Saving…" : "Record distribution"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </>
        }
      />

      <StatGrid>
        <StatCard label="Total items" value={totalItems} icon={Package} />
        <StatCard label="Low stock" value={lowStock} icon={Minus} />
        <StatCard label="Pounds on hand" value={poundsOnHand.toLocaleString()} icon={Package} />
        <StatCard label="Restocks this month" value={restocksThisMonth} icon={Plus} />
      </StatGrid>

      <SectionHeading title="Items" description="Search and filter your pantry catalog" />
      <div className="mb-4 flex flex-wrap gap-2">
        <Input placeholder="Search items…" value={search} onChange={(e) => setSearch(e.target.value)} className="max-w-xs" />
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All categories</SelectItem>
            {inventoryCategories.map((c) => (
              <SelectItem key={c} value={c}>
                {c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <DataTable rows={filtered} columns={itemColumns} searchKeys={(r) => r.name} exportName="inventory-items" pageSize={10} />

      <div className="mt-10">
        <SectionHeading title="Recent transactions" description="Restocks, adjustments, spoilage, and distributions" />
      </div>
      <DataTable
        rows={transactions}
        columns={txnColumns}
        searchKeys={(r) => `${items.find((i) => i.id === r.itemId)?.name ?? ""} ${r.notes}`}
        exportName="inventory-transactions"
        pageSize={10}
      />

      <Dialog open={adjustOpen} onOpenChange={setAdjustOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Adjust {adjustItem?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-xs">Type</Label>
              <Select value={adjustType} onValueChange={(v) => setAdjustType(v as "adjustment" | "spoilage")}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="adjustment">Adjustment (add/correct)</SelectItem>
                  <SelectItem value="spoilage">Spoilage (remove)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Quantity ({adjustItem?.unitLabel})</Label>
              <Input type="number" min="0" value={adjustQty} onChange={(e) => setAdjustQty(e.target.value)} />
            </div>
            <div>
              <Label className="text-xs">Notes</Label>
              <Textarea value={adjustNotes} onChange={(e) => setAdjustNotes(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAdjustOpen(false)}>
              Cancel
            </Button>
            <Button onClick={submitAdjust} disabled={savingAdjust}>
              {savingAdjust ? "Saving…" : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageShell>
  );
}
