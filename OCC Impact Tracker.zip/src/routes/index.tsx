import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Sparkles, Sprout, Utensils } from "lucide-react";
import { PageShell } from "@/components/layout/PageShell";
import { Button } from "@/components/ui/button";
import { MISSION, VALUES, VISION, programs } from "@/data/programs";

const ICONS = { utensils: Utensils, sprout: Sprout, sparkles: Sparkles };

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "OCC Impact Report Tracker — Ollivier Community Circle" },
      {
        name: "description",
        content:
          "Track food security, mental health education, and youth empowerment outcomes across Ollivier Community Circle's three Virginia programs.",
      },
      { property: "og:title", content: "OCC Impact Report Tracker" },
      {
        property: "og:description",
        content:
          "Health equity in Virginia, measured. Households served, pounds distributed, and participant growth across three programs.",
      },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <>
      <section className="bg-hunter px-4 pb-16 pt-28 text-cream sm:px-6">
        <div className="mx-auto max-w-4xl">
          <p className="stat-label text-cream/70">Ollivier Community Circle · Virginia</p>
          <h1 className="mt-4 text-4xl leading-tight sm:text-5xl">
            Health equity, measured — so every family can thrive.
          </h1>
          <p className="mt-5 max-w-2xl text-sm leading-relaxed text-cream/85 sm:text-base">{MISSION}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild variant="secondary" size="lg">
              <Link to="/signin">
                Sign in <ArrowRight className="ml-1.5 size-4" aria-hidden />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-cream/40 bg-transparent text-cream hover:bg-cream/10"
            >
              <Link to="/signup">Join a program</Link>
            </Button>
          </div>
        </div>
      </section>

      <PageShell className="pt-12">
        <h2 className="text-2xl">Our three programs</h2>
        <div className="mt-6 grid gap-5 lg:grid-cols-3">
          {programs.map((program) => {
            const Icon = ICONS[program.icon];
            return (
              <article key={program.slug} className="surface-card flex flex-col gap-3 p-6">
                <span className="flex size-10 items-center justify-center rounded-full bg-secondary">
                  <Icon className="size-5 text-primary" aria-hidden />
                </span>
                <h3 className="text-xl">{program.name}</h3>
                <p className="text-sm text-muted-foreground">{program.tagline}</p>
                <p className="text-sm leading-relaxed">{program.description}</p>
                <p className="stat-label mt-auto pt-3">Who we serve</p>
                <p className="text-sm text-muted-foreground">{program.whoWeServe.join(" · ")}</p>
              </article>
            );
          })}
        </div>

        <section className="surface-card mt-10 p-6">
          <h2 className="text-2xl">Our vision</h2>
          <p className="mt-3 max-w-3xl text-sm leading-relaxed">{VISION}</p>
          <ul className="mt-6 flex flex-wrap gap-2">
            {VALUES.map((value) => (
              <li key={value} className="rounded-full border border-sage/50 px-3 py-1 text-xs">
                {value}
              </li>
            ))}
          </ul>
        </section>
      </PageShell>
    </>
  );
}
