import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import { DataTable, type Column } from "@/components/kit/DataTable";
import { ErrorState, PageSkeleton } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/context/AuthContext";
import { userService, type UserFilters } from "@/services/userService";
import { taskService } from "@/services/taskService";
import { reportService } from "@/services/reportService";
import { assessmentService } from "@/services/assessmentService";
import type { ProgramSlug, Role, User } from "@/types";

export const Route = createFileRoute("/admin/users")({
  head: () => ({
    meta: [
      { title: "Manage users — OCC Impact Report Tracker" },
      { name: "description", content: "View, filter, and manage every user in the OCC impact tracker." },
      { property: "og:title", content: "Manage users — OCC Impact Report Tracker" },
      { property: "og:description", content: "View, filter, and manage every user in the OCC impact tracker." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["admin"]}>
      <UsersPage />
    </ProtectedRoute>
  ),
});

const ROLES: Role[] = ["admin", "staff", "volunteer", "parent", "student"];
const PROGRAMS: ProgramSlug[] = ["fresh-table", "sprout-society", "becoming"];
const PROGRAM_LABEL: Record<ProgramSlug, string> = {
  "fresh-table": "The Fresh Table",
  "sprout-society": "Sprout Society",
  becoming: "Becoming",
};

function UsersPage() {
  const { user: me } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const [role, setRole] = useState<UserFilters["role"]>("all");
  const [program, setProgram] = useState<UserFilters["program"]>("all");
  const [status, setStatus] = useState<UserFilters["status"]>("all");
  const [ageBand, setAgeBand] = useState<UserFilters["ageBand"]>("all");
  const [flaggedOnly, setFlaggedOnly] = useState(false);

  const [selected, setSelected] = useState<User | null>(null);
  const [editOpen, setEditOpen] = useState(false);
  const [taskOpen, setTaskOpen] = useState(false);

  const load = () => {
    setLoading(true);
    setError(false);
    userService
      .list({ role, program, status, ageBand, flaggedOnly })
      .then(setUsers)
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(load, [role, program, status, ageBand, flaggedOnly]);

  const columns: Column<User>[] = useMemo(
    () => [
      { key: "fullName", header: "Name", sortValue: (u) => u.fullName },
      { key: "email", header: "Email", sortValue: (u) => u.email, hideOnMobile: true },
      { key: "age", header: "Age", sortValue: (u) => u.age },
      {
        key: "role",
        header: "Role",
        sortValue: (u) => u.role,
        render: (u) => <Badge variant="outline" className="capitalize">{u.role}</Badge>,
      },
      {
        key: "programs",
        header: "Program",
        sortValue: (u) => u.programs.join(", "),
        render: (u) => (u.programs.length ? u.programs.map((p) => PROGRAM_LABEL[p]).join(", ") : "—"),
      },
      {
        key: "status",
        header: "Status",
        sortValue: (u) => u.status,
        render: (u) => (
          <Badge
            variant="outline"
            className={
              u.status === "active"
                ? "border-primary/30 bg-accent text-accent-foreground"
                : u.status === "pending"
                  ? "border-sage/50 bg-secondary text-secondary-foreground"
                  : "border-terracotta/35 bg-terracotta/12 text-terracotta"
            }
          >
            {u.status}
          </Badge>
        ),
      },
      {
        key: "joinedAt",
        header: "Joined",
        sortValue: (u) => u.joinedAt,
        render: (u) => new Date(u.joinedAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
        hideOnMobile: true,
      },
    ],
    [],
  );

  return (
    <PageShell>
      <PageHeader title="Users" description="Every user in the system — filter, review, and take action on any account." />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <Select value={role} onValueChange={(v) => setRole(v as UserFilters["role"])}>
          <SelectTrigger className="w-40"><SelectValue placeholder="Role" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All roles</SelectItem>
            {ROLES.map((r) => (
              <SelectItem key={r} value={r} className="capitalize">{r}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={program} onValueChange={(v) => setProgram(v as UserFilters["program"])}>
          <SelectTrigger className="w-48"><SelectValue placeholder="Program" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All programs</SelectItem>
            {PROGRAMS.map((p) => (
              <SelectItem key={p} value={p}>{PROGRAM_LABEL[p]}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={status} onValueChange={(v) => setStatus(v as UserFilters["status"])}>
          <SelectTrigger className="w-36"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="inactive">Inactive</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
          </SelectContent>
        </Select>
        <Select value={ageBand} onValueChange={(v) => setAgeBand(v as UserFilters["ageBand"])}>
          <SelectTrigger className="w-40"><SelectValue placeholder="Age band" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All ages</SelectItem>
            <SelectItem value="under12">Under 12</SelectItem>
            <SelectItem value="12to18">12–18</SelectItem>
            <SelectItem value="adult">Adult (18+)</SelectItem>
          </SelectContent>
        </Select>
        <label className="flex items-center gap-2 rounded-lg border border-input px-3 py-2 text-sm">
          <Checkbox checked={flaggedOnly} onCheckedChange={(v) => setFlaggedOnly(Boolean(v))} />
          Flagged only
        </label>
      </div>

      {loading ? (
        <PageSkeleton />
      ) : error ? (
        <ErrorState onRetry={load} />
      ) : (
        <DataTable
          rows={users}
          columns={columns}
          searchKeys={(u) => `${u.fullName} ${u.email} ${u.zip}`}
          onRowClick={(u) => setSelected(u)}
          exportName="occ-users"
          emptyTitle="No users match these filters"
          emptyDescription="Try widening your filters or clearing the search."
        />
      )}

      {selected && (
        <Dialog open={!!selected} onOpenChange={(v) => !v && setSelected(null)}>
          <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{selected.fullName}</DialogTitle>
              <DialogDescription>{selected.email}</DialogDescription>
            </DialogHeader>

            <Tabs defaultValue="profile">
              <TabsList>
                <TabsTrigger value="profile">Profile</TabsTrigger>
                <TabsTrigger value="edit">Edit</TabsTrigger>
                <TabsTrigger value="actions">Actions</TabsTrigger>
              </TabsList>
              <TabsContent value="profile" className="space-y-3 pt-3 text-sm">
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Role" value={selected.role} />
                  <Field label="Status" value={selected.status} />
                  <Field label="Age" value={String(selected.age)} />
                  <Field label="Phone" value={selected.phone || "—"} />
                  <Field label="Zip" value={selected.zip || "—"} />
                  <Field label="Preferred language" value={selected.preferredLanguage} />
                  <Field label="Joined" value={new Date(selected.joinedAt).toLocaleDateString("en-US")} />
                  <Field label="Last active" value={new Date(selected.lastActiveAt).toLocaleDateString("en-US")} />
                </div>
                <Separator />
                <div>
                  <p className="stat-label mb-1">Programs</p>
                  <div className="flex flex-wrap gap-1.5">
                    {selected.programs.length ? (
                      selected.programs.map((p) => <Badge key={p} variant="outline">{PROGRAM_LABEL[p]}</Badge>)
                    ) : (
                      <span className="text-muted-foreground">No programs assigned</span>
                    )}
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="edit" className="pt-3">
                <EditUserForm
                  user={selected}
                  onSaved={(updated) => {
                    setUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
                    setSelected(updated);
                    toast.success("User updated");
                  }}
                />
              </TabsContent>
              <TabsContent value="actions" className="space-y-3 pt-3">
                <Button className="w-full justify-start" variant="outline" onClick={() => setTaskOpen(true)}>
                  Assign a task to {selected.fullName.split(" ")[0]}
                </Button>
                <Button
                  className="w-full justify-start"
                  variant="outline"
                  onClick={async () => {
                    const attempts = await assessmentService.attemptsForUser(selected.id);
                    await reportService.exportPdf({
                      title: `Participant report — ${selected.fullName}`,
                      subtitle: "Individual participant report",
                      generatedFor: selected.fullName,
                      dateRange: "All time",
                      sections: [
                        {
                          heading: "Profile",
                          kpis: [
                            { label: "Role", value: selected.role },
                            { label: "Status", value: selected.status },
                            { label: "Age", value: String(selected.age) },
                            { label: "Assessments completed", value: String(attempts.filter((a) => a.status === "completed").length) },
                          ],
                        },
                        {
                          heading: "Assessment history",
                          table: {
                            columns: ["Assessment", "Status", "Band", "Score", "Date"],
                            rows: attempts.map((a) => [
                              a.assessmentId,
                              a.status,
                              a.band || "—",
                              String(a.normalizedScore),
                              new Date(a.completedAt ?? a.startedAt).toLocaleDateString("en-US"),
                            ]),
                          },
                        },
                      ],
                    });
                    await reportService.record({
                      title: `Participant report — ${selected.fullName}`,
                      type: "individual-participant",
                      scope: selected.id,
                      filters: {},
                      generatedBy: me?.id ?? "admin",
                      format: "pdf",
                    });
                    toast.success("Report generated");
                  }}
                >
                  Generate user report (PDF)
                </Button>
                <Button
                  className="w-full justify-start"
                  variant="outline"
                  onClick={async () => {
                    await userService.resetPassword(selected.id);
                    toast.success(`Password reset email sent to ${selected.email}`);
                  }}
                >
                  Reset password
                </Button>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}

      {selected && (
        <AssignTaskDialog
          open={taskOpen}
          onOpenChange={setTaskOpen}
          user={selected}
          assignedBy={me?.id ?? "admin"}
          onAssigned={() => toast.success(`Task assigned to ${selected.fullName}`)}
        />
      )}
    </PageShell>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="stat-label">{label}</p>
      <p className="capitalize">{value}</p>
    </div>
  );
}

function EditUserForm({ user, onSaved }: { user: User; onSaved: (u: User) => void }) {
  const [role, setRole] = useState<Role>(user.role);
  const [status, setStatus] = useState<User["status"]>(user.status);
  const [programs, setPrograms] = useState<ProgramSlug[]>(user.programs);
  const [saving, setSaving] = useState(false);

  const toggleProgram = (p: ProgramSlug) => {
    setPrograms((prev) => (prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p]));
  };

  return (
    <div className="space-y-4">
      <div>
        <Label className="mb-1.5 block">Role</Label>
        <Select value={role} onValueChange={(v) => setRole(v as Role)}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {ROLES.map((r) => (
              <SelectItem key={r} value={r} className="capitalize">{r}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label className="mb-1.5 block">Status</Label>
        <Select value={status} onValueChange={(v) => setStatus(v as User["status"])}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="inactive">Inactive</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label className="mb-1.5 block">Programs</Label>
        <div className="flex flex-wrap gap-3">
          {PROGRAMS.map((p) => (
            <label key={p} className="flex items-center gap-2 text-sm">
              <Checkbox checked={programs.includes(p)} onCheckedChange={() => toggleProgram(p)} />
              {PROGRAM_LABEL[p]}
            </label>
          ))}
        </div>
      </div>
      <Button
        disabled={saving}
        onClick={async () => {
          setSaving(true);
          try {
            const updated = await userService.update(user.id, { role, status, programs });
            onSaved(updated);
          } finally {
            setSaving(false);
          }
        }}
      >
        {saving ? "Saving…" : "Save changes"}
      </Button>
    </div>
  );
}

function AssignTaskDialog({
  open,
  onOpenChange,
  user,
  assignedBy,
  onAssigned,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  user: User;
  assignedBy: string;
  onAssigned: () => void;
}) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState<"low" | "medium" | "high">("medium");
  const [dueDate, setDueDate] = useState("");
  const [saving, setSaving] = useState(false);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Assign a task to {user.fullName}</DialogTitle>
          <DialogDescription>This will notify the user and add it to their task list.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <Label className="mb-1.5 block">Title</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Follow up on assessment" />
          </div>
          <div>
            <Label className="mb-1.5 block">Description</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="mb-1.5 block">Priority</Label>
              <Select value={priority} onValueChange={(v) => setPriority(v as typeof priority)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="mb-1.5 block">Due date</Label>
              <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button
            disabled={!title || !dueDate || saving}
            onClick={async () => {
              setSaving(true);
              try {
                await taskService.create({
                  title,
                  description,
                  assignedTo: user.id,
                  assignedBy,
                  priority,
                  dueDate: new Date(dueDate).toISOString(),
                  status: "todo",
                });
                onOpenChange(false);
                setTitle("");
                setDescription("");
                setDueDate("");
                onAssigned();
              } finally {
                setSaving(false);
              }
            }}
          >
            {saving ? "Assigning…" : "Assign task"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
