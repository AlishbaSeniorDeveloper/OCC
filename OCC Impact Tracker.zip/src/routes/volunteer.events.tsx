import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { CalendarDays, MapPin, Users, Clock3 } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import { EmptyState, PageSkeleton } from "@/components/kit/States";
import { useAuth } from "@/context/AuthContext";
import { eventService } from "@/services/eventService";
import type { Event } from "@/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export const Route = createFileRoute("/volunteer/events")({
  head: () => ({
    meta: [
      { title: "Volunteer events — OCC Impact Report Tracker" },
      { name: "description", content: "Browse and RSVP to upcoming OCC volunteer opportunities and log your hours." },
      { property: "og:title", content: "Volunteer events — OCC Impact Report Tracker" },
      { property: "og:description", content: "Sign up for events and log hours as an OCC volunteer." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["volunteer"]}>
      <EventsPage />
    </ProtectedRoute>
  ),
});

const TYPES: Event["type"][] = ["volunteer", "distribution", "workshop", "community"];

function EventsPage() {
  const { user } = useAuth();
  const [events, setEvents] = useState<Event[] | null>(null);
  const [rsvps, setRsvps] = useState<string[]>([]);
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [error, setError] = useState(false);
  const [hoursTarget, setHoursTarget] = useState<Event | null>(null);
  const [hoursValue, setHoursValue] = useState("2");
  const [activityValue, setActivityValue] = useState("");
  const [dateValue, setDateValue] = useState(() => new Date().toISOString().slice(0, 10));

  const load = async () => {
    setError(false);
    try {
      const [rows, mine] = await Promise.all([eventService.list(), eventService.myRsvps()]);
      setEvents(rows);
      setRsvps(mine);
    } catch {
      setError(true);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    if (!events) return [];
    return events.filter((e) => typeFilter === "all" || e.type === typeFilter);
  }, [events, typeFilter]);

  const toggleRsvp = async (event: Event) => {
    const isIn = rsvps.includes(event.id);
    try {
      if (isIn) {
        await eventService.cancelRsvp(event.id);
        toast.success("RSVP canceled");
      } else {
        await eventService.rsvp(event.id);
        toast.success("You're signed up!");
      }
      await load();
    } catch {
      toast.error("Something went wrong");
    }
  };

  const openHoursDialog = (event: Event) => {
    setHoursTarget(event);
    setActivityValue(event.title);
    setHoursValue("2");
    setDateValue(new Date().toISOString().slice(0, 10));
  };

  const submitHours = async () => {
    if (!user || !hoursTarget) return;
    const hours = Number(hoursValue);
    if (!hours || hours <= 0) {
      toast.error("Enter a valid number of hours");
      return;
    }
    try {
      await eventService.logHours({
        userId: user.id,
        eventId: hoursTarget.id,
        hours,
        activity: activityValue || hoursTarget.title,
        date: dateValue,
      });
      toast.success("Hours logged — thank you!");
      setHoursTarget(null);
    } catch {
      toast.error("Couldn't log hours");
    }
  };

  if (events === null && !error) {
    return (
      <PageShell>
        <PageSkeleton />
      </PageShell>
    );
  }

  return (
    <PageShell>
      <PageHeader title="Volunteer events" description="RSVP for upcoming opportunities and log hours after you help out." />

      <div className="mb-6 flex flex-wrap gap-3">
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-48"><SelectValue placeholder="Event type" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All event types</SelectItem>
            {TYPES.map((t) => (
              <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {error ? (
        <EmptyState title="Couldn't load events" description="Please try again shortly." />
      ) : filtered.length === 0 ? (
        <EmptyState title="No events found" description="Check back soon for new volunteer opportunities." />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((event) => {
            const isIn = rsvps.includes(event.id);
            const isPast = new Date(event.endsAt).getTime() < Date.now();
            return (
              <div key={event.id} className="surface-card flex flex-col gap-3 p-5">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-lg">{event.title}</h3>
                  <Badge variant="outline" className="shrink-0 capitalize">{event.type}</Badge>
                </div>
                <p className="line-clamp-3 text-sm text-muted-foreground">{event.description}</p>
                <div className="space-y-1.5 text-xs text-muted-foreground">
                  <p className="flex items-center gap-1.5"><CalendarDays className="size-3.5" aria-hidden />
                    {new Date(event.startsAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                  </p>
                  <p className="flex items-center gap-1.5"><MapPin className="size-3.5" aria-hidden /> {event.location}</p>
                  <p className="flex items-center gap-1.5"><Users className="size-3.5" aria-hidden /> {event.rsvpCount}/{event.capacity} signed up</p>
                </div>
                <div className="mt-auto flex flex-wrap gap-2 pt-2">
                  <Button
                    size="sm"
                    variant={isIn ? "outline" : "default"}
                    onClick={() => toggleRsvp(event)}
                  >
                    {isIn ? "Cancel RSVP" : "RSVP"}
                  </Button>
                  <Button size="sm" variant="secondary" onClick={() => openHoursDialog(event)} disabled={!isPast && !isIn}>
                    <Clock3 className="mr-1.5 size-3.5" aria-hidden /> Log hours
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={!!hoursTarget} onOpenChange={(open) => !open && setHoursTarget(null)}>
        <DialogContent>
          {hoursTarget && (
            <>
              <DialogHeader>
                <DialogTitle>Log hours for {hoursTarget.title}</DialogTitle>
                <DialogDescription>Record the time you contributed to this event.</DialogDescription>
              </DialogHeader>
              <div className="space-y-3">
                <div className="space-y-1.5">
                  <Label htmlFor="log-date">Date</Label>
                  <Input id="log-date" type="date" value={dateValue} onChange={(e) => setDateValue(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="log-hours">Hours</Label>
                  <Input id="log-hours" type="number" min="0.5" step="0.5" value={hoursValue} onChange={(e) => setHoursValue(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="log-activity">Activity</Label>
                  <Input id="log-activity" value={activityValue} onChange={(e) => setActivityValue(e.target.value)} />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setHoursTarget(null)}>Cancel</Button>
                <Button onClick={submitHours}>Save hours</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </PageShell>
  );
}
