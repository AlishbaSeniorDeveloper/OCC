import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { CalendarDays, CheckCircle2, Clock3, ListTodo, ArrowUpRight } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { ChartCard, CHART_COLORS, axisProps, tooltipStyle } from "@/components/kit/ChartCard";
import { PageSkeleton } from "@/components/kit/States";
import { useAuth } from "@/context/AuthContext";
import { taskService, isOverdue } from "@/services/taskService";
import { eventService } from "@/services/eventService";
import type { Event, Task, VolunteerHourLog } from "@/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/volunteer/")({
  head: () => ({
    meta: [
      { title: "Volunteer dashboard — OCC Impact Report Tracker" },
      { name: "description", content: "Your volunteer dashboard for the Ollivier Community Circle impact tracker." },
      { property: "og:title", content: "Volunteer dashboard — OCC Impact Report Tracker" },
      { property: "og:description", content: "Tasks, upcoming events, and hours logged for OCC volunteers." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["volunteer"]}>
      <Dashboard />
    </ProtectedRoute>
  ),
});

const PRIORITY_TONE: Record<Task["priority"], string> = {
  low: "bg-secondary text-foreground",
  medium: "bg-gold/20 text-foreground",
  high: "bg-terracotta/20 text-terracotta",
};

const STATUS_LABEL: Record<Task["status"], string> = {
  todo: "To do",
  "in-progress": "In progress",
  blocked: "Blocked",
  done: "Done",
};

function monthKey(date: string) {
  return new Date(date).toLocaleDateString("en-US", { month: "short", year: "2-digit" });
}

function Dashboard() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[] | null>(null);
  const [hours, setHours] = useState<VolunteerHourLog[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [rsvps, setRsvps] = useState<string[]>([]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const [t, h, ev, mine] = await Promise.all([
        taskService.listForUser(user.id),
        eventService.hoursForUser(user.id),
        eventService.list({ upcomingOnly: true }),
        eventService.myRsvps(),
      ]);
      setTasks(t);
      setHours(h);
      setEvents(ev);
      setRsvps(mine);
    })();
  }, [user?.id]);

  const openTasks = useMemo(() => (tasks ?? []).filter((t) => t.status !== "done").length, [tasks]);
  const overdueTasks = useMemo(() => (tasks ?? []).filter((t) => isOverdue(t)).length, [tasks]);
  const completedThisMonth = useMemo(() => {
    const now = new Date();
    return (tasks ?? []).filter(
      (t) => t.status === "done" && t.completedAt && new Date(t.completedAt).getMonth() === now.getMonth() && new Date(t.completedAt).getFullYear() === now.getFullYear(),
    ).length;
  }, [tasks]);
  const totalHours = useMemo(() => hours.reduce((sum, l) => sum + l.hours, 0), [hours]);

  const chartData = useMemo(() => {
    const map = new Map<string, number>();
    for (const l of hours) map.set(monthKey(l.date), (map.get(monthKey(l.date)) ?? 0) + l.hours);
    return [...map.entries()].map(([month, value]) => ({ month, hours: Number(value.toFixed(1)) }));
  }, [hours]);

  const nextEvent = useMemo(
    () => events.filter((e) => rsvps.includes(e.id)).sort((a, b) => a.startsAt.localeCompare(b.startsAt))[0] ?? events[0],
    [events, rsvps],
  );

  const previewTasks = useMemo(() => (tasks ?? []).slice(0, 6), [tasks]);

  const recentActivity = useMemo(() => {
    const taskEvents = (tasks ?? [])
      .filter((t) => t.completedAt)
      .map((t) => ({ id: `t-${t.id}`, label: `Completed "${t.title}"`, date: t.completedAt! }));
    const hourEvents = hours.slice(0, 5).map((h) => ({ id: `h-${h.id}`, label: `Logged ${h.hours}h for ${h.activity}`, date: h.date }));
    return [...taskEvents, ...hourEvents].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6);
  }, [tasks, hours]);

  if (tasks === null) {
    return (
      <PageShell>
        <PageSkeleton />
      </PageShell>
    );
  }

  return (
    <PageShell>
      <PageHeader
        title={`Welcome, ${user?.fullName?.split(" ")[0] ?? "friend"}`}
        description="Here's a snapshot of your volunteer activity with OCC."
        actions={
          <Button asChild variant="outline">
            <Link to="/volunteer/tasks">
              View all tasks <ArrowUpRight className="ml-1.5 size-4" aria-hidden />
            </Link>
          </Button>
        }
      />

      <StatGrid className="mb-8">
        <StatCard label="Open tasks" value={openTasks} icon={ListTodo} />
        <StatCard label="Overdue tasks" value={overdueTasks} icon={Clock3} hint={overdueTasks > 0 ? "Needs attention" : "All caught up"} />
        <StatCard label="Completed this month" value={completedThisMonth} icon={CheckCircle2} />
        <StatCard label="Total hours logged" value={totalHours.toFixed(1)} icon={Clock3} />
      </StatGrid>

      <div className="mb-8 grid gap-4 lg:grid-cols-3">
        <div className="surface-card space-y-3 p-5 lg:col-span-1">
          <SectionHeading title="Next event" />
          {nextEvent ? (
            <div className="space-y-2">
              <p className="text-base font-medium">{nextEvent.title}</p>
              <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <CalendarDays className="size-3.5" aria-hidden />
                {new Date(nextEvent.startsAt).toLocaleString("en-US", { month: "long", day: "numeric", hour: "numeric", minute: "2-digit" })}
              </p>
              <p className="text-xs text-muted-foreground">{nextEvent.location}</p>
              <Badge variant={rsvps.includes(nextEvent.id) ? "default" : "outline"}>
                {rsvps.includes(nextEvent.id) ? "You're signed up" : "Not yet RSVP'd"}
              </Badge>
              <Button asChild size="sm" variant="outline" className="mt-2 w-full">
                <Link to="/volunteer/events">Manage RSVPs</Link>
              </Button>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">No upcoming events right now.</p>
          )}
        </div>

        <div className="lg:col-span-2">
          <ChartCard
            title="Hours logged by month"
            description="Your monthly volunteer hour totals."
            data={chartData}
            columns={[{ key: "month", label: "Month" }, { key: "hours", label: "Hours" }]}
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis dataKey="month" {...axisProps} />
                <YAxis {...axisProps} allowDecimals={false} />
                <Tooltip {...tooltipStyle} />
                <Bar dataKey="hours" fill={CHART_COLORS.hunter} radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>
      </div>

      <SectionHeading
        title="Task board preview"
        description="Your most recent assigned tasks."
        actions={
          <Button asChild variant="ghost" size="sm">
            <Link to="/volunteer/tasks">See all →</Link>
          </Button>
        }
      />
      {previewTasks.length === 0 ? (
        <p className="surface-card mb-8 p-6 text-sm text-muted-foreground">No tasks assigned yet.</p>
      ) : (
        <div className="mb-8 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {previewTasks.map((task) => (
            <div key={task.id} className="surface-card space-y-2 p-4">
              <div className="flex items-start justify-between gap-2">
                <p className="text-sm font-medium">{task.title}</p>
                {isOverdue(task) && <Badge className="bg-terracotta/20 text-terracotta">Overdue</Badge>}
              </div>
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <Badge className={PRIORITY_TONE[task.priority]}>{task.priority}</Badge>
                <Badge variant="outline">{STATUS_LABEL[task.status]}</Badge>
                <span className="text-muted-foreground">
                  Due {new Date(task.dueDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      <SectionHeading title="Recent activity" description="Your latest task completions and hour logs." />
      {recentActivity.length === 0 ? (
        <p className="surface-card p-6 text-sm text-muted-foreground">No activity yet — get started with a task or event!</p>
      ) : (
        <ul className="surface-card divide-y divide-border">
          {recentActivity.map((item) => (
            <li key={item.id} className="flex items-center justify-between gap-3 px-5 py-3 text-sm">
              <span>{item.label}</span>
              <span className="text-xs text-muted-foreground">
                {new Date(item.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
              </span>
            </li>
          ))}
        </ul>
      )}
    </PageShell>
  );
}
