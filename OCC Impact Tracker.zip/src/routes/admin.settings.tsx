import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { ProgressMeter } from "@/components/kit/StatCard";
import { ErrorState, PageSkeleton } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FRESH_TABLE_GOALS, MISSION, VALUES, VISION } from "@/data/programs";
import { CRISIS_RESOURCES } from "@/lib/scoring";
import { analyticsService } from "@/services/analyticsService";
import { assessmentService } from "@/services/assessmentService";
import { inventoryService } from "@/services/inventoryService";
import { reportService } from "@/services/reportService";
import { taskService } from "@/services/taskService";
import { userService } from "@/services/userService";
import type { Role } from "@/types";

export const Route = createFileRoute("/admin/settings")({
  head: () => ({
    meta: [
      { title: "Organization settings — OCC Impact Report Tracker" },
      { name: "description", content: "Organization profile, program goals, safety policy, roles, and full data export." },
      { property: "og:title", content: "Organization settings — OCC Impact Report Tracker" },
      { property: "og:description", content: "Organization profile, program goals, safety policy, roles, and full data export." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["admin"]}>
      <SettingsPage />
    </ProtectedRoute>
  ),
});

const ROLE_PERMISSIONS: { role: Role; description: string; permissions: string[] }[] = [
  {
    role: "admin",
    description: "Full organizational access.",
    permissions: ["Manage all users", "Assign tasks to anyone", "Generate all reports", "Manage inventory", "Review flagged assessments", "Edit settings"],
  },
  {
    role: "staff",
    description: "Program delivery and participant support.",
    permissions: ["Manage assigned participants", "Log attendance & distributions", "Review assessments for their program", "Complete assigned tasks"],
  },
  {
    role: "volunteer",
    description: "Event and distribution support.",
    permissions: ["RSVP to events", "Log volunteer hours", "View assigned tasks", "Support distributions"],
  },
  {
    role: "parent",
    description: "Guardian access to a child's programs.",
    permissions: ["View child's attendance & progress", "RSVP to family events", "Complete caregiver feedback"],
  },
  {
    role: "student",
    description: "Program participant.",
    permissions: ["Take assigned assessments", "View own progress", "Register for workshops", "View own tasks"],
  },
];

function SettingsPage() {
  const [goals, setGoals] = useState<{ households: number; pounds: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [exporting, setExporting] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    setError(false);
    analyticsService
      .freshTableDashboard()
      .then((d) => setGoals({ households: d.households, pounds: d.pounds }))
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const exportDataset = async (name: string, fetcher: () => Promise<Record<string, string | number>[]>) => {
    setExporting(name);
    try {
      const rows = await fetcher();
      await reportService.exportCsv(`occ-${name}`, rows);
      toast.success(`${name} exported as CSV`);
    } catch {
      toast.error("Could not export data");
    } finally {
      setExporting(null);
    }
  };

  return (
    <PageShell>
      <PageHeader title="Settings" description="Organization profile, program goals, safety policy, roles, and data export." />

      <div className="space-y-8">
        <div className="surface-card space-y-4 p-5">
          <SectionHeading title="Organization profile" description="Read-only — reflects the current mission, vision, and values." />
          <div>
            <p className="stat-label mb-1">Mission</p>
            <p className="text-sm text-muted-foreground">{MISSION}</p>
          </div>
          <div>
            <p className="stat-label mb-1">Vision</p>
            <p className="text-sm text-muted-foreground">{VISION}</p>
          </div>
          <div>
            <p className="stat-label mb-2">Values</p>
            <div className="flex flex-wrap gap-1.5">
              {VALUES.map((v) => (
                <Badge key={v} variant="outline">{v}</Badge>
              ))}
            </div>
          </div>
        </div>

        <div>
          <SectionHeading title="Program goal targets" description="The Fresh Table's annual targets, tracked against current progress." />
          {loading ? (
            <PageSkeleton />
          ) : error || !goals ? (
            <ErrorState onRetry={load} />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              <ProgressMeter label="Households served" value={goals.households} max={FRESH_TABLE_GOALS.households} />
              <ProgressMeter label="Pounds distributed" value={goals.pounds} max={FRESH_TABLE_GOALS.pounds} unit=" lbs" />
            </div>
          )}
        </div>

        <div className="surface-card space-y-4 p-5">
          <SectionHeading title="Safety & flagging policy" description="How assessment responses are screened and escalated." />
          <p className="text-sm text-muted-foreground">
            Any assessment response that endorses thoughts of self-harm, or that scores in a "severe" band, is automatically
            flagged for staff review. Flagged attempts appear on the admin dashboard's "Needs attention" panel and in the
            Assessments review queue until a staff member reviews and clears them. Staff and admins are notified so a
            timely, compassionate follow-up can happen.
          </p>
          <div>
            <p className="stat-label mb-2">Crisis resources shown to participants</p>
            <ul className="space-y-2">
              {CRISIS_RESOURCES.map((r) => (
                <li key={r.name} className="rounded-lg border border-terracotta/25 bg-terracotta/5 px-3 py-2 text-sm">
                  <p className="font-medium">{r.name}</p>
                  <p className="text-xs text-muted-foreground">{r.detail}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div>
          <SectionHeading title="Roles & permissions" description="What each role can see and do within the system." />
          <div className="overflow-hidden rounded-xl border border-border bg-card">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Role</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Permissions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {ROLE_PERMISSIONS.map((r) => (
                  <TableRow key={r.role}>
                    <TableCell><Badge variant="outline" className="capitalize">{r.role}</Badge></TableCell>
                    <TableCell className="text-sm text-muted-foreground">{r.description}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1.5">
                        {r.permissions.map((p) => (
                          <Badge key={p} variant="outline" className="text-xs font-normal">{p}</Badge>
                        ))}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>

        <div className="surface-card space-y-4 p-5">
          <SectionHeading title="Download all data" description="Export raw datasets as CSV for backup or offline analysis." />
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Button
              variant="outline"
              disabled={exporting === "users"}
              onClick={() =>
                exportDataset("users", async () => {
                  const users = await userService.list();
                  return users.map((u) => ({
                    Name: u.fullName,
                    Email: u.email,
                    Role: u.role,
                    Programs: u.programs.join("; "),
                    Status: u.status,
                    Joined: u.joinedAt,
                  }));
                })
              }
            >
              {exporting === "users" ? "Exporting…" : "Users CSV"}
            </Button>
            <Button
              variant="outline"
              disabled={exporting === "attempts"}
              onClick={() =>
                exportDataset("attempts", async () => {
                  const attempts = await assessmentService.allAttempts();
                  return attempts.map((a) => ({
                    Id: a.id,
                    Assessment: a.assessmentId,
                    User: a.userId,
                    Status: a.status,
                    Band: a.band,
                    Score: a.normalizedScore,
                    Flagged: a.flagged ? "Yes" : "No",
                  }));
                })
              }
            >
              {exporting === "attempts" ? "Exporting…" : "Attempts CSV"}
            </Button>
            <Button
              variant="outline"
              disabled={exporting === "tasks"}
              onClick={() =>
                exportDataset("tasks", async () => {
                  const tasks = await taskService.listAll();
                  return tasks.map((t) => ({
                    Title: t.title,
                    AssignedTo: t.assignedTo,
                    Priority: t.priority,
                    Status: t.status,
                    DueDate: t.dueDate,
                  }));
                })
              }
            >
              {exporting === "tasks" ? "Exporting…" : "Tasks CSV"}
            </Button>
            <Button
              variant="outline"
              disabled={exporting === "inventory"}
              onClick={() =>
                exportDataset("inventory", async () => {
                  const items = await inventoryService.list();
                  return items.map((i) => ({
                    Name: i.name,
                    Category: i.category,
                    OnHand: i.quantityOnHand,
                    ParLevel: i.parLevel,
                    ReorderPoint: i.reorderPoint,
                  }));
                })
              }
            >
              {exporting === "inventory" ? "Exporting…" : "Inventory CSV"}
            </Button>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
