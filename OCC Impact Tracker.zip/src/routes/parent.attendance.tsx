import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CartesianGrid, Line, LineChart, XAxis, YAxis } from "recharts";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { ChartCard, CHART_COLORS, axisProps, tooltipStyle } from "@/components/kit/ChartCard";
import { DataTable, type Column } from "@/components/kit/DataTable";
import { PageSkeleton, EmptyState, ErrorState } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/context/AuthContext";
import { attendanceService, type AttendanceSummary } from "@/services/attendanceService";
import { workshopService } from "@/services/workshopService";
import type { AttendanceSlot, Workshop, WorkshopEnrollment } from "@/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/parent/attendance")({
  head: () => ({
    meta: [
      { title: "Attendance history — OCC Impact Report Tracker" },
      { name: "description", content: "Review your attendance history and monthly attendance rate for OCC sessions and workshops." },
      { property: "og:title", content: "Attendance history — OCC Impact Report Tracker" },
      { property: "og:description", content: "Your sessions, workshops, and attendance trends in one place." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["parent"]}>
      <AttendancePage />
    </ProtectedRoute>
  ),
});

interface Row {
  id: string;
  title: string;
  date: string;
  type: string;
  status: string;
  location: string;
}

function AttendancePage() {
  const { user } = useAuth();
  const [slots, setSlots] = useState<AttendanceSlot[]>([]);
  const [summary, setSummary] = useState<AttendanceSummary | null>(null);
  const [workshops, setWorkshops] = useState<Workshop[]>([]);
  const [enrollments, setEnrollments] = useState<WorkshopEnrollment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const load = () => {
    if (!user) return;
    setLoading(true);
    setError(false);
    Promise.all([
      attendanceService.listForUser(user.id),
      attendanceService.summaryForUser(user.id),
      workshopService.list(),
      workshopService.enrollmentsForUser(user.id),
    ])
      .then(([s, sum, w, e]) => {
        setSlots(s);
        setSummary(sum);
        setWorkshops(w);
        setEnrollments(e);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(load, [user]);

  if (loading || !summary) {
    return (
      <PageShell>
        <PageSkeleton />
      </PageShell>
    );
  }
  if (error) {
    return (
      <PageShell>
        <ErrorState onRetry={load} />
      </PageShell>
    );
  }

  const workshopById = new Map(workshops.map((w) => [w.id, w]));

  const slotRows: Row[] = slots.map((s) => ({
    id: s.id,
    title: s.title,
    date: s.scheduledAt,
    type: s.type,
    status: s.status,
    location: s.location,
  }));

  const enrollmentRows: Row[] = enrollments.flatMap((e) => {
    const w = workshopById.get(e.workshopId);
    if (!w) return [];
    return [
      {
        id: e.id,
        title: w.title,
        date: w.startsAt,
        type: "workshop",
        status: e.status,
        location: w.location,
      } as Row,
    ];
  });

  const allRows = [...slotRows, ...enrollmentRows].sort((a, b) => b.date.localeCompare(a.date));

  const monthly = new Map<string, { attended: number; total: number }>();
  for (const r of allRows) {
    if (r.status === "upcoming" || r.status === "registered") continue;
    const key = new Date(r.date).toLocaleDateString("en-US", { month: "short", year: "2-digit" });
    const entry = monthly.get(key) ?? { attended: 0, total: 0 };
    entry.total += 1;
    if (r.status === "attended") entry.attended += 1;
    monthly.set(key, entry);
  }
  const chartData = [...monthly.entries()]
    .sort((a, b) => new Date(`1 ${a[0]}`).getTime() - new Date(`1 ${b[0]}`).getTime())
    .map(([month, v]) => ({ month, rate: v.total === 0 ? 0 : Math.round((v.attended / v.total) * 100) }));

  const statusTone = (status: string) =>
    status === "attended"
      ? "bg-accent text-accent-foreground"
      : status === "missed" || status === "no-show"
        ? "bg-terracotta/12 text-terracotta"
        : status === "excused"
          ? "bg-secondary text-secondary-foreground"
          : "border border-border";

  const columns: Column<Row>[] = [
    { key: "title", header: "Session / Workshop", sortValue: (r) => r.title },
    {
      key: "date",
      header: "Date",
      sortValue: (r) => r.date,
      render: (r) => new Date(r.date).toLocaleDateString("en-US", { dateStyle: "medium" }),
    },
    { key: "type", header: "Type", sortValue: (r) => r.type },
    { key: "location", header: "Location", sortValue: (r) => r.location, hideOnMobile: true },
    {
      key: "status",
      header: "Status",
      sortValue: (r) => r.status,
      render: (r) => <Badge className={cn("capitalize", statusTone(r.status))}>{r.status}</Badge>,
    },
  ];

  return (
    <PageShell>
      <PageHeader title="Attendance history" description="Your sessions and workshops, and how consistently you've attended." />

      <StatGrid>
        <StatCard label="Sessions scheduled" value={summary.scheduled} />
        <StatCard label="Attended" value={summary.attended} />
        <StatCard label="Attendance rate" value={`${summary.rate}%`} />
        <StatCard label="Current streak" value={summary.streak} hint="Consecutive attended" />
      </StatGrid>

      <div className="mt-6">
        <ChartCard
          title="Monthly attendance rate"
          description="Percentage attended each month across sessions and workshops"
          data={chartData.map((c) => ({ Month: c.month, "Attendance rate": `${c.rate}%` }))}
        >
          {chartData.length === 0 ? (
            <EmptyState title="No history yet" description="Attend a session or workshop to build your history." />
          ) : (
            <LineChart data={chartData} margin={{ left: -20, right: 10, top: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="month" {...axisProps} />
              <YAxis {...axisProps} domain={[0, 100]} />
              <Line type="monotone" dataKey="rate" name="Attendance %" stroke={CHART_COLORS.hunter} strokeWidth={2} dot={{ r: 3 }} {...tooltipStyle} />
            </LineChart>
          )}
        </ChartCard>
      </div>

      <div className="mt-6">
        <DataTable
          rows={allRows}
          columns={columns}
          searchKeys={(r) => `${r.title} ${r.type} ${r.status}`}
          exportName="attendance-history"
          emptyTitle="No attendance records"
          emptyDescription="Your attendance history will appear once you attend sessions or workshops."
        />
      </div>
    </PageShell>
  );
}
