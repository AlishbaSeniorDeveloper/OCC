import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { CalendarDays, MapPin, Star, Users } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import { PageSkeleton, EmptyState, ErrorState } from "@/components/kit/States";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/context/AuthContext";
import { workshopService } from "@/services/workshopService";
import type { Workshop, WorkshopEnrollment } from "@/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/parent/workshops")({
  head: () => ({
    meta: [
      { title: "Adult mental health workshops — OCC Impact Report Tracker" },
      { name: "description", content: "Browse, register for, and give feedback on adult mental health workshops." },
      { property: "og:title", content: "Adult mental health workshops — OCC Impact Report Tracker" },
      { property: "og:description", content: "Register, track, and reflect on your OCC mental health workshops." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["parent"]}>
      <WorkshopsPage />
    </ProtectedRoute>
  ),
});

function WorkshopsPage() {
  const { user } = useAuth();
  const [workshops, setWorkshops] = useState<Workshop[]>([]);
  const [enrollments, setEnrollments] = useState<WorkshopEnrollment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [feedbackTarget, setFeedbackTarget] = useState<WorkshopEnrollment | null>(null);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const load = () => {
    if (!user) return;
    setLoading(true);
    setError(false);
    Promise.all([workshopService.list({ audience: "adult" }), workshopService.enrollmentsForUser(user.id)])
      .then(([w, e]) => {
        setWorkshops(w);
        setEnrollments(e);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(load, [user]);

  if (loading) {
    return (
      <PageShell>
        <PageSkeleton />
      </PageShell>
    );
  }
  if (error) {
    return (
      <PageShell>
        <ErrorState onRetry={load} />
      </PageShell>
    );
  }

  const enrollmentByWorkshop = new Map(enrollments.map((e) => [e.workshopId, e]));
  const now = Date.now();

  const available = workshops.filter(
    (w) => w.status === "upcoming" && new Date(w.startsAt).getTime() >= now && !enrollmentByWorkshop.has(w.id),
  );
  const upcoming = workshops.filter((w) => {
    const e = enrollmentByWorkshop.get(w.id);
    return e && e.status === "registered" && new Date(w.startsAt).getTime() >= now;
  });
  const history = workshops.filter((w) => {
    const e = enrollmentByWorkshop.get(w.id);
    return e && (e.status !== "registered" || new Date(w.startsAt).getTime() < now);
  });

  const register = async (workshopId: string) => {
    if (!user) return;
    setBusyId(workshopId);
    try {
      await workshopService.register(workshopId, user.id);
      toast.success("Registered for workshop");
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not register");
    } finally {
      setBusyId(null);
    }
  };

  const cancel = async (workshopId: string) => {
    const e = enrollmentByWorkshop.get(workshopId);
    if (!e) return;
    setBusyId(workshopId);
    try {
      await workshopService.cancel(e.id);
      toast.success("Registration cancelled");
      load();
    } catch {
      toast.error("Could not cancel registration");
    } finally {
      setBusyId(null);
    }
  };

  const openFeedback = (e: WorkshopEnrollment) => {
    setFeedbackTarget(e);
    setRating(e.feedbackRating ?? 5);
    setComment(e.feedbackComment ?? "");
  };

  const submitFeedback = async () => {
    if (!feedbackTarget) return;
    setSubmitting(true);
    try {
      await workshopService.submitFeedback(feedbackTarget.id, rating, comment);
      toast.success("Feedback submitted — thank you!");
      setFeedbackTarget(null);
      load();
    } catch {
      toast.error("Could not submit feedback");
    } finally {
      setSubmitting(false);
    }
  };

  const renderWorkshopCard = (w: Workshop, kind: "available" | "upcoming" | "history") => {
    const enrollment = enrollmentByWorkshop.get(w.id);
    const spotsLeft = w.capacity - w.enrolledCount;
    return (
      <div key={w.id} className="surface-card flex flex-col gap-3 p-5">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <h3 className="text-lg">{w.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{w.description}</p>
          </div>
          {enrollment?.status && (
            <Badge
              variant="secondary"
              className={cn(
                enrollment.status === "attended" && "bg-accent text-accent-foreground",
                enrollment.status === "no-show" && "bg-terracotta/12 text-terracotta",
              )}
            >
              {enrollment.status}
            </Badge>
          )}
        </div>
        <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
          <span className="inline-flex items-center gap-1.5">
            <CalendarDays className="size-4 text-sage" aria-hidden />
            {new Date(w.startsAt).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" })}
          </span>
          <span className="inline-flex items-center gap-1.5">
            <MapPin className="size-4 text-sage" aria-hidden />
            {w.location}
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Users className="size-4 text-sage" aria-hidden />
            {w.enrolledCount}/{w.capacity} enrolled · {Math.max(0, spotsLeft)} spots left
          </span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {w.tags.map((t) => (
            <Badge key={t} variant="outline" className="text-xs">
              {t}
            </Badge>
          ))}
        </div>
        <p className="text-xs text-muted-foreground">Facilitator: {w.facilitator}</p>

        <div className="mt-1 flex flex-wrap items-center gap-2">
          {kind === "available" && (
            <Button size="sm" disabled={spotsLeft <= 0 || busyId === w.id} onClick={() => register(w.id)}>
              {spotsLeft <= 0 ? "Full" : busyId === w.id ? "Registering…" : "Register"}
            </Button>
          )}
          {kind === "upcoming" && (
            <Button size="sm" variant="outline" disabled={busyId === w.id} onClick={() => cancel(w.id)}>
              {busyId === w.id ? "Cancelling…" : "Cancel registration"}
            </Button>
          )}
          {kind === "history" && enrollment?.status === "attended" && (
            <Button size="sm" variant="outline" onClick={() => openFeedback(enrollment)}>
              <Star className="mr-1.5 size-4" aria-hidden />
              {enrollment.feedbackRating ? "Update feedback" : "Leave feedback"}
            </Button>
          )}
          {kind === "history" && enrollment?.feedbackRating && (
            <span className="text-xs text-muted-foreground">Rated {enrollment.feedbackRating}/5</span>
          )}
        </div>
      </div>
    );
  };

  return (
    <PageShell>
      <PageHeader
        title="Adult mental health workshops"
        description="Register for workshops, keep track of what's next, and share feedback after each session."
      />

      <Tabs defaultValue="available">
        <TabsList>
          <TabsTrigger value="available">Available ({available.length})</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming ({upcoming.length})</TabsTrigger>
          <TabsTrigger value="history">History ({history.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="available" className="mt-4 space-y-4">
          {available.length === 0 ? (
            <EmptyState title="No open workshops" description="Check back soon — new workshops are added regularly." />
          ) : (
            available.map((w) => renderWorkshopCard(w, "available"))
          )}
        </TabsContent>

        <TabsContent value="upcoming" className="mt-4 space-y-4">
          {upcoming.length === 0 ? (
            <EmptyState title="Nothing registered" description="Register for an available workshop to see it here." />
          ) : (
            upcoming.map((w) => renderWorkshopCard(w, "upcoming"))
          )}
        </TabsContent>

        <TabsContent value="history" className="mt-4 space-y-4">
          {history.length === 0 ? (
            <EmptyState title="No workshop history yet" description="Attended and past workshops will show up here." />
          ) : (
            history.map((w) => renderWorkshopCard(w, "history"))
          )}
        </TabsContent>
      </Tabs>

      <Dialog open={!!feedbackTarget} onOpenChange={(open) => !open && setFeedbackTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Workshop feedback</DialogTitle>
            <DialogDescription>Let us know how the workshop went for you.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="mb-2 block">Rating</Label>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => setRating(n)}
                    aria-label={`Rate ${n} out of 5`}
                    className="p-1"
                  >
                    <Star className={cn("size-6", n <= rating ? "fill-gold text-gold" : "text-muted-foreground")} aria-hidden />
                  </button>
                ))}
              </div>
            </div>
            <div>
              <Label htmlFor="feedback-comment" className="mb-2 block">
                Comments
              </Label>
              <Textarea
                id="feedback-comment"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="What worked well? What could be better?"
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFeedbackTarget(null)}>
              Cancel
            </Button>
            <Button onClick={submitFeedback} disabled={submitting}>
              {submitting ? "Submitting…" : "Submit feedback"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageShell>
  );
}
