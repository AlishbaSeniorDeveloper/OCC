import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CalendarCheck, Flame, GraduationCap, ListChecks, Target, Trophy } from "lucide-react";
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { ChartCard, CHART_COLORS, axisProps, tooltipStyle } from "@/components/kit/ChartCard";
import { PageSkeleton, EmptyState, ErrorState } from "@/components/kit/States";
import { useAuth } from "@/context/AuthContext";
import { analyticsService } from "@/services/analyticsService";
import { attendanceService } from "@/services/attendanceService";
import { workshopService } from "@/services/workshopService";
import type { AttendanceSlot, Workshop } from "@/types";

export const Route = createFileRoute("/student/")({
  head: () => ({
    meta: [
      { title: "Student dashboard — OCC Impact Report Tracker" },
      { name: "description", content: "Your progress snapshot: assessments, attendance, workshops, and streaks." },
      { property: "og:title", content: "Student dashboard — OCC Impact Report Tracker" },
      { property: "og:description", content: "Programs, assessments, and impact data for OCC students." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["student"]}>
      <Dashboard />
    </ProtectedRoute>
  ),
});

interface Summary {
  assessmentsTaken: number;
  totalScore: number;
  averageScore: number;
  highestScore: number;
  attendance: { rate: number; streak: number; upcoming: number };
  workshopsCompleted: number;
  scoreOverTime: { label: string; score: number }[];
}

function Dashboard() {
  const { user } = useAuth();
  const [summary, setSummary] = useState<Summary | null>(null);
  const [nextSlot, setNextSlot] = useState<AttendanceSlot | null>(null);
  const [nextWorkshop, setNextWorkshop] = useState<Workshop | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const load = () => {
    if (!user) return;
    setLoading(true);
    setError(false);
    Promise.all([
      analyticsService.studentSummary(user.id),
      attendanceService.listForUser(user.id),
      workshopService.enrollmentsForUser(user.id),
      workshopService.list(),
    ])
      .then(([s, slots, enrollments, workshops]) => {
        setSummary(s);
        const upcomingSlots = slots
          .filter((sl) => sl.status === "upcoming")
          .sort((a, b) => a.scheduledAt.localeCompare(b.scheduledAt));
        setNextSlot(upcomingSlots[0] ?? null);

        const registeredIds = new Set(enrollments.filter((e) => e.status === "registered").map((e) => e.workshopId));
        const upcomingWorkshops = workshops
          .filter((w) => registeredIds.has(w.id) && w.status === "upcoming")
          .sort((a, b) => a.startsAt.localeCompare(b.startsAt));
        setNextWorkshop(upcomingWorkshops[0] ?? null);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  if (loading) {
    return (
      <PageShell>
        <PageSkeleton />
      </PageShell>
    );
  }

  if (error || !summary) {
    return (
      <PageShell>
        <ErrorState onRetry={load} />
      </PageShell>
    );
  }

  return (
    <PageShell>
      <PageHeader
        title={`Welcome back, ${user?.fullName?.split(" ")[0] ?? "friend"}`}
        description="Here's a snapshot of your assessments, attendance, and workshops."
      />

      <StatGrid>
        <StatCard label="Assessments taken" value={summary.assessmentsTaken} icon={ListChecks} />
        <StatCard label="Attendance rate" value={`${summary.attendance.rate}%`} icon={CalendarCheck} hint={`${summary.attendance.streak} session streak`} />
        <StatCard label="Workshops completed" value={summary.workshopsCompleted} icon={GraduationCap} />
        <StatCard label="Average score" value={summary.averageScore} icon={Target} />
        <StatCard label="Total score" value={summary.totalScore} icon={Trophy} />
        <StatCard label="Streak" value={summary.attendance.streak} icon={Flame} hint="Consecutive attended sessions" />
      </StatGrid>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <ChartCard
            title="Score over time"
            description="Normalized score (0–100) for each completed assessment attempt."
            data={summary.scoreOverTime.map((p) => ({ date: p.label, score: p.score }))}
            columns={[{ key: "date", label: "Date" }, { key: "score", label: "Score" }]}
          >
            {summary.scoreOverTime.length === 0 ? (
              <EmptyState title="No assessments yet" description="Complete an assessment to see your score trend here." />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={summary.scoreOverTime}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="label" {...axisProps} />
                  <YAxis {...axisProps} domain={[0, 100]} />
                  <Tooltip {...tooltipStyle} />
                  <Line type="monotone" dataKey="score" stroke={CHART_COLORS.hunter} strokeWidth={2} dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            )}
          </ChartCard>
        </div>

        <div className="space-y-4">
          <div className="surface-card p-5">
            <p className="stat-label">Next session</p>
            {nextSlot ? (
              <div className="mt-3 space-y-1">
                <p className="text-lg">{nextSlot.title}</p>
                <p className="text-sm text-muted-foreground">
                  {new Date(nextSlot.scheduledAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                </p>
                <p className="text-xs text-muted-foreground">{nextSlot.location}</p>
                <Link to="/student/attendance" className="mt-2 inline-block text-sm text-primary hover:underline">
                  View attendance →
                </Link>
              </div>
            ) : (
              <p className="mt-3 text-sm text-muted-foreground">No upcoming sessions scheduled.</p>
            )}
          </div>

          <div className="surface-card p-5">
            <p className="stat-label">Next workshop</p>
            {nextWorkshop ? (
              <div className="mt-3 space-y-1">
                <p className="text-lg">{nextWorkshop.title}</p>
                <p className="text-sm text-muted-foreground">
                  {new Date(nextWorkshop.startsAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                </p>
                <p className="text-xs text-muted-foreground">{nextWorkshop.location}</p>
                <Link to="/student/workshops" className="mt-2 inline-block text-sm text-primary hover:underline">
                  View workshops →
                </Link>
              </div>
            ) : (
              <p className="mt-3 text-sm text-muted-foreground">You aren't registered for any upcoming workshops.</p>
            )}
          </div>
        </div>
      </div>

      <div className="mt-8">
        <SectionHeading title="Quick links" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Link to="/student/assessments" className="surface-card block p-5 transition-colors hover:bg-secondary">
            <ListChecks className="mb-2 size-5 text-sage" aria-hidden />
            <p className="text-sm">Take an assessment</p>
          </Link>
          <Link to="/student/attendance" className="surface-card block p-5 transition-colors hover:bg-secondary">
            <CalendarCheck className="mb-2 size-5 text-sage" aria-hidden />
            <p className="text-sm">Check in to a session</p>
          </Link>
          <Link to="/student/workshops" className="surface-card block p-5 transition-colors hover:bg-secondary">
            <GraduationCap className="mb-2 size-5 text-sage" aria-hidden />
            <p className="text-sm">Browse workshops</p>
          </Link>
          <Link to="/student/reports" className="surface-card block p-5 transition-colors hover:bg-secondary">
            <Trophy className="mb-2 size-5 text-sage" aria-hidden />
            <p className="text-sm">Export a progress report</p>
          </Link>
        </div>
      </div>
    </PageShell>
  );
}
