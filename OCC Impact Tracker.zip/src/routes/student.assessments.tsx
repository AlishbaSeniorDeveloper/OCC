import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { BarChart, Bar, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { ArrowRight } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { ChartCard, CHART_COLORS, axisProps, tooltipStyle } from "@/components/kit/ChartCard";
import { DataTable, type Column } from "@/components/kit/DataTable";
import { PageSkeleton, ErrorState, EmptyState } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/context/AuthContext";
import { assessmentService } from "@/services/assessmentService";
import { assessmentById } from "@/data/assessments";
import { bandToneClass } from "@/lib/scoring";
import type { Assessment, AssessmentAttempt } from "@/types";

export const Route = createFileRoute("/student/assessments")({
  head: () => ({
    meta: [
      { title: "Assessments — OCC Impact Report Tracker" },
      { name: "description", content: "Your assessment history, scores, and available assessments to take." },
      { property: "og:title", content: "Assessments — OCC Impact Report Tracker" },
      { property: "og:description", content: "Track your assessment scores and take new assessments." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["student"]}>
      <AssessmentsPage />
    </ProtectedRoute>
  ),
});

function AssessmentsPage() {
  const { user } = useAuth();
  const [attempts, setAttempts] = useState<AssessmentAttempt[]>([]);
  const [available, setAvailable] = useState<Assessment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const load = () => {
    if (!user) return;
    setLoading(true);
    setError(false);
    Promise.all([assessmentService.attemptsForUser(user.id), assessmentService.availableFor(user.id)])
      .then(([a, av]) => {
        setAttempts(a);
        setAvailable(av);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const completed = attempts.filter((a) => a.status === "completed");

  const kpis = useMemo(() => {
    const total = completed.length;
    const avg = total ? Math.round(completed.reduce((s, a) => s + a.normalizedScore, 0) / total) : 0;
    const totalScore = completed.reduce((s, a) => s + a.rawScore, 0);
    const highest = completed.reduce((m, a) => Math.max(m, a.normalizedScore), 0);
    return { total, avg, totalScore, highest };
  }, [completed]);

  const avgByType = useMemo(() => {
    const map = new Map<string, { total: number; count: number }>();
    for (const a of completed) {
      const cur = map.get(a.assessmentId) ?? { total: 0, count: 0 };
      cur.total += a.normalizedScore;
      cur.count += 1;
      map.set(a.assessmentId, cur);
    }
    return [...map.entries()].map(([id, v]) => ({
      type: assessmentById(id)?.title ?? id,
      average: Math.round(v.total / v.count),
    }));
  }, [completed]);

  const columns: Column<AssessmentAttempt>[] = [
    {
      key: "title",
      header: "Assessment",
      sortValue: (a) => assessmentById(a.assessmentId)?.title ?? a.assessmentId,
    },
    {
      key: "date",
      header: "Date",
      sortValue: (a) => a.completedAt ?? a.startedAt,
      render: (a) => new Date(a.completedAt ?? a.startedAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
    },
    { key: "raw", header: "Raw score", sortValue: (a) => a.rawScore },
    { key: "normalized", header: "Normalized", sortValue: (a) => a.normalizedScore },
    {
      key: "band",
      header: "Band",
      sortValue: (a) => a.band,
      render: (a) => {
        const instrument = assessmentById(a.assessmentId);
        const tone = instrument?.bands.find((b) => b.label === a.band)?.tone ?? "good";
        return (
          <Badge variant="outline" className={bandToneClass(tone)}>
            {a.band}
          </Badge>
        );
      },
    },
  ];

  if (loading) {
    return (
      <PageShell>
        <PageSkeleton />
      </PageShell>
    );
  }

  if (error) {
    return (
      <PageShell>
        <ErrorState onRetry={load} />
      </PageShell>
    );
  }

  return (
    <PageShell>
      <PageHeader title="Assessments" description="Your assessment history and what's available to take next." />

      <StatGrid className="mb-8">
        <StatCard label="Assessments taken" value={kpis.total} />
        <StatCard label="Average score" value={kpis.avg} />
        <StatCard label="Total score" value={kpis.totalScore} />
        <StatCard label="Highest score" value={kpis.highest} />
      </StatGrid>

      <div className="mb-8">
        <SectionHeading title="Available assessments" description="Assessments you can take now." />
        {available.length === 0 ? (
          <EmptyState title="Nothing available" description="Check back later for new assessments." />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {available.map((a) => (
              <div key={a.id} className="surface-card flex flex-col gap-2 p-5">
                <p className="text-lg">{a.title}</p>
                <p className="text-sm text-muted-foreground">{a.description}</p>
                <p className="text-xs text-muted-foreground">~{a.estimatedMinutes} min · {a.questions.length} questions</p>
                <Button asChild size="sm" className="mt-2 self-start">
                  <Link to="/student/assessments/$assessmentId" params={{ assessmentId: a.id }}>
                    Start <ArrowRight className="ml-1.5 size-4" aria-hidden />
                  </Link>
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>

      {avgByType.length > 0 && (
        <div className="mb-8">
          <ChartCard
            title="Average score by assessment type"
            data={avgByType.map((d) => ({ type: d.type, average: d.average }))}
            columns={[{ key: "type", label: "Assessment" }, { key: "average", label: "Average" }]}
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={avgByType}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="type" {...axisProps} interval={0} angle={-15} textAnchor="end" height={60} />
                <YAxis {...axisProps} domain={[0, 100]} />
                <Tooltip {...tooltipStyle} />
                <Bar dataKey="average" fill={CHART_COLORS.hunter} radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>
      )}

      <div>
        <SectionHeading title="Attempt history" />
        <DataTable
          rows={completed}
          columns={columns}
          searchKeys={(a) => assessmentById(a.assessmentId)?.title ?? a.assessmentId}
          exportName="assessment-attempts"
          emptyTitle="No attempts yet"
          emptyDescription="Complete an assessment to see your history here."
        />
      </div>
    </PageShell>
  );
}
