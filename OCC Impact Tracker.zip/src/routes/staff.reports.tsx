import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { FileDown, FileSpreadsheet, FileText } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { DataTable, type Column } from "@/components/kit/DataTable";
import { PageSkeleton } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/context/AuthContext";
import { programs, programBySlug } from "@/data/programs";
import { assessmentById } from "@/data/assessments";
import { userService } from "@/services/userService";
import { assessmentService } from "@/services/assessmentService";
import { attendanceService, summarize } from "@/services/attendanceService";
import { inventoryService } from "@/services/inventoryService";
import { reportService, type ReportDocument } from "@/services/reportService";
import type { AssessmentAttempt, AttendanceSlot, Distribution, InventoryItem, ProgramSlug, Report, User } from "@/types";

export const Route = createFileRoute("/staff/reports")({
  head: () => ({
    meta: [
      { title: "Reports — OCC Impact Report Tracker" },
      { name: "description", content: "Generate branded PDF and CSV reports for your programs." },
      { property: "og:title", content: "Reports — OCC Impact Report Tracker" },
      { property: "og:description", content: "Build inventory, assessment, attendance, and roster reports for OCC." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["staff"]}>
      <ReportsPage />
    </ProtectedRoute>
  ),
});

type ReportType = "inventory" | "assessment" | "attendance" | "roster";

const REPORT_TYPES: { value: ReportType; label: string; description: string }[] = [
  { value: "inventory", label: "Inventory & distribution", description: "Stock levels, restocks, and distributions." },
  { value: "assessment", label: "Mental health assessment summary", description: "Attempts, bands, and flags." },
  { value: "attendance", label: "Workshop attendance", description: "Session attendance rates by program." },
  { value: "roster", label: "Participant roster", description: "Active participants and program enrollment." },
];

function ReportsPage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<User[]>([]);
  const [attempts, setAttempts] = useState<AssessmentAttempt[]>([]);
  const [slots, setSlots] = useState<AttendanceSlot[]>([]);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [distributions, setDistributions] = useState<Distribution[]>([]);
  const [saved, setSaved] = useState<Report[]>([]);

  const [reportType, setReportType] = useState<ReportType>("inventory");
  const [program, setProgram] = useState<ProgramSlug | "all">("all");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [generating, setGenerating] = useState(false);

  const load = async () => {
    const [u, a, s, inv, dist, rep] = await Promise.all([
      userService.list(),
      assessmentService.allAttempts(),
      attendanceService.listAll(),
      inventoryService.list(),
      inventoryService.distributions(),
      reportService.saved(),
    ]);
    setUsers(u);
    setAttempts(a);
    setSlots(s);
    setItems(inv);
    setDistributions(dist);
    setSaved(rep);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const withinRange = (iso: string) => {
    if (startDate && iso < startDate) return false;
    if (endDate && iso > `${endDate}T23:59:59`) return false;
    return true;
  };

  const filteredUsers = useMemo(
    () => users.filter((u) => (program === "all" ? true : u.programs.includes(program))),
    [users, program],
  );

  const dateRangeLabel = startDate || endDate ? `${startDate || "…"} to ${endDate || "…"}` : "All time";
  const programLabel = program === "all" ? "All programs" : programBySlug(program)?.name ?? program;

  const buildDocument = (): { doc: ReportDocument; csvRows: Record<string, string | number>[]; title: string } | null => {
    const generatedFor = programLabel;
    const dateRange = dateRangeLabel;

    if (reportType === "inventory") {
      const dist = distributions.filter((d) => withinRange(d.date));
      const totalLbs = Math.round(dist.reduce((s, d) => s + d.poundsDistributed, 0));
      const households = dist.reduce((s, d) => s + d.householdsServed, 0);
      const individuals = dist.reduce((s, d) => s + d.individualsServed, 0);
      const doc: ReportDocument = {
        title: "Inventory & Distribution Report",
        subtitle: "Pantry stock and distribution activity",
        generatedFor,
        dateRange,
        sections: [
          {
            heading: "Summary",
            kpis: [
              { label: "Pounds distributed", value: totalLbs.toLocaleString() },
              { label: "Households served", value: households.toLocaleString() },
              { label: "Individuals served", value: individuals.toLocaleString() },
              { label: "Tracked SKUs", value: String(items.length) },
            ],
          },
          {
            heading: "Distributions",
            table: {
              columns: ["Date", "Households", "Individuals", "Pounds", "Volunteers", "Zip"],
              rows: dist.map((d) => [
                new Date(d.date).toLocaleDateString("en-US"),
                d.householdsServed,
                d.individualsServed,
                Math.round(d.poundsDistributed),
                d.volunteersPresent,
                d.zip,
              ]),
            },
          },
        ],
      };
      const csvRows = dist.map((d) => ({
        Date: new Date(d.date).toLocaleDateString("en-US"),
        Households: d.householdsServed,
        Individuals: d.individualsServed,
        Pounds: Math.round(d.poundsDistributed),
        Volunteers: d.volunteersPresent,
        Zip: d.zip,
      }));
      return { doc, csvRows, title: "inventory-distribution-report" };
    }

    if (reportType === "assessment") {
      const rows = attempts.filter(
        (a) => a.status === "completed" && a.completedAt && withinRange(a.completedAt) &&
          (program === "all" || users.find((u) => u.id === a.userId)?.programs.includes(program)),
      );
      const flagged = rows.filter((a) => a.flagged).length;
      const doc: ReportDocument = {
        title: "Mental Health Assessment Summary",
        subtitle: "Completed screener attempts and outcomes",
        generatedFor,
        dateRange,
        sections: [
          {
            heading: "Summary",
            kpis: [
              { label: "Completed attempts", value: String(rows.length) },
              { label: "Flagged for review", value: String(flagged) },
              { label: "Participants assessed", value: String(new Set(rows.map((r) => r.userId)).size) },
            ],
          },
          {
            heading: "Attempts",
            table: {
              columns: ["Participant", "Assessment", "Band", "Flagged", "Completed"],
              rows: rows.map((a) => [
                users.find((u) => u.id === a.userId)?.fullName ?? "Unknown",
                assessmentById(a.assessmentId)?.title ?? a.assessmentId,
                a.band,
                a.flagged ? "Yes" : "No",
                a.completedAt ? new Date(a.completedAt).toLocaleDateString("en-US") : "",
              ]),
            },
          },
        ],
      };
      const csvRows = rows.map((a) => ({
        Participant: users.find((u) => u.id === a.userId)?.fullName ?? "Unknown",
        Assessment: assessmentById(a.assessmentId)?.title ?? a.assessmentId,
        Band: a.band,
        Flagged: a.flagged ? "Yes" : "No",
        Completed: a.completedAt ? new Date(a.completedAt).toLocaleDateString("en-US") : "",
      }));
      return { doc, csvRows, title: "mental-health-assessment-summary" };
    }

    if (reportType === "attendance") {
      const rows = slots.filter(
        (s) => withinRange(s.scheduledAt) && (program === "all" || s.programId === program) && s.status !== "upcoming",
      );
      const summary = summarize(rows);
      const doc: ReportDocument = {
        title: "Workshop Attendance Report",
        subtitle: "Session attendance across programs",
        generatedFor,
        dateRange,
        sections: [
          {
            heading: "Summary",
            kpis: [
              { label: "Sessions", value: String(summary.scheduled) },
              { label: "Attended", value: String(summary.attended) },
              { label: "Missed", value: String(summary.missed) },
              { label: "Attendance rate", value: `${summary.rate}%` },
            ],
          },
          {
            heading: "Sessions",
            table: {
              columns: ["Title", "Program", "Date", "Status"],
              rows: rows.map((s) => [s.title, programBySlug(s.programId)?.name ?? s.programId, new Date(s.scheduledAt).toLocaleDateString("en-US"), s.status]),
            },
          },
        ],
      };
      const csvRows = rows.map((s) => ({
        Title: s.title,
        Program: programBySlug(s.programId)?.name ?? s.programId,
        Date: new Date(s.scheduledAt).toLocaleDateString("en-US"),
        Status: s.status,
      }));
      return { doc, csvRows, title: "workshop-attendance-report" };
    }

    const rows = filteredUsers.filter((u) => u.role === "student" || u.role === "parent");
    const doc: ReportDocument = {
      title: "Participant Roster",
      subtitle: "Active and pending participants",
      generatedFor,
      dateRange,
      sections: [
        {
          heading: "Summary",
          kpis: [
            { label: "Total participants", value: String(rows.length) },
            { label: "Active", value: String(rows.filter((r) => r.status === "active").length) },
          ],
        },
        {
          heading: "Roster",
          table: {
            columns: ["Name", "Age", "Role", "Programs", "Status"],
            rows: rows.map((r) => [r.fullName, r.age, r.role, r.programs.map((p) => programBySlug(p)?.name ?? p).join(", "), r.status]),
          },
        },
      ],
    };
    const csvRows = rows.map((r) => ({
      Name: r.fullName,
      Age: r.age,
      Role: r.role,
      Programs: r.programs.map((p) => programBySlug(p)?.name ?? p).join(", "),
      Status: r.status,
    }));
    return { doc, csvRows, title: "participant-roster" };
  };

  const generate = async (format: "pdf" | "csv") => {
    if (!user) return;
    const built = buildDocument();
    if (!built) return;
    setGenerating(true);
    try {
      if (format === "pdf") await reportService.exportPdf(built.doc);
      else await reportService.exportCsv(built.title, built.csvRows);
      await reportService.record({
        title: built.doc.title,
        type: reportType,
        scope: programLabel,
        filters: { program: programLabel, dateRange: dateRangeLabel },
        generatedBy: user.id,
        format,
      });
      toast.success(`${format.toUpperCase()} report generated`);
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not generate report");
    } finally {
      setGenerating(false);
    }
  };

  if (loading || !user) {
    return (
      <PageShell>
        <PageHeader title="Reports" description="Loading report tools…" />
        <PageSkeleton />
      </PageShell>
    );
  }

  const columns: Column<Report>[] = [
    { key: "title", header: "Title", sortValue: (r) => r.title },
    { key: "type", header: "Type", render: (r) => <Badge variant="outline" className="capitalize">{r.type}</Badge> },
    { key: "scope", header: "Scope", sortValue: (r) => r.scope, hideOnMobile: true },
    {
      key: "format",
      header: "Format",
      render: (r) => (
        <Badge variant="outline" className="uppercase">
          {r.format}
        </Badge>
      ),
    },
    {
      key: "generatedAt",
      header: "Generated",
      sortValue: (r) => r.generatedAt,
      render: (r) => new Date(r.generatedAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }),
    },
  ];

  return (
    <PageShell>
      <PageHeader title="Reports" description="Build and export branded reports for your programs." />

      <div className="surface-card space-y-5 p-5">
        <SectionHeading title="Report builder" description="Pick a type, scope, and date range" />

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {REPORT_TYPES.map((rt) => (
            <button
              key={rt.value}
              type="button"
              onClick={() => setReportType(rt.value)}
              className={`rounded-xl border p-4 text-left transition-colors ${
                reportType === rt.value ? "border-primary bg-accent/50" : "border-border bg-card hover:bg-accent/20"
              }`}
            >
              <p className="text-sm font-medium text-foreground">{rt.label}</p>
              <p className="mt-1 text-xs text-muted-foreground">{rt.description}</p>
            </button>
          ))}
        </div>

        <div className="grid gap-4 sm:grid-cols-3">
          <div className="space-y-1.5">
            <Label>Program filter</Label>
            <Select value={program} onValueChange={(v) => setProgram(v as ProgramSlug | "all")}>
              <SelectTrigger>
                <SelectValue placeholder="Program" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All programs</SelectItem>
                {programs.map((p) => (
                  <SelectItem key={p.slug} value={p.slug}>
                    {p.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Start date</Label>
            <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>End date</Label>
            <Input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button onClick={() => generate("pdf")} disabled={generating}>
            <FileText className="mr-1.5 size-4" aria-hidden /> Export PDF
          </Button>
          <Button variant="outline" onClick={() => generate("csv")} disabled={generating}>
            <FileSpreadsheet className="mr-1.5 size-4" aria-hidden /> Export CSV
          </Button>
        </div>
      </div>

      <div className="mt-8">
        <SectionHeading title="Saved reports" description="Reports generated by you and your team" />
      </div>
      <DataTable
        rows={saved}
        columns={columns}
        searchKeys={(r) => `${r.title} ${r.type} ${r.scope}`}
        exportName="saved-reports"
        emptyTitle="No reports yet"
        emptyDescription="Generate your first report above and it will be recorded here."
        emptyAction={<FileDown className="size-6 text-sage" aria-hidden />}
      />
    </PageShell>
  );
}
