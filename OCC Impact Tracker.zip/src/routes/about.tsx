import { createFileRoute, Link } from "@tanstack/react-router";
import { GraduationCap, HeartHandshake, Shield, Sparkles, Users, Wrench } from "lucide-react";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MISSION, VISION, VALUES } from "@/data/programs";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About OCC — Ollivier Community Circle" },
      { name: "description", content: "Our mission, vision, and values, plus how the OCC Impact Report Tracker works for every role." },
      { property: "og:title", content: "About OCC — Ollivier Community Circle" },
      { property: "og:description", content: "Health equity through food security and mental health education in Hampton Roads." },
    ],
  }),
  component: AboutPage,
});

const IMPACT = [
  { label: "Households served annually", value: "600+" },
  { label: "Pounds of food distributed", value: "6,800+ lbs" },
  { label: "Children in Sprout Society", value: "150+" },
  { label: "Teens in Becoming", value: "90+" },
];

const ROLES = [
  {
    role: "Students",
    icon: GraduationCap,
    blurb: "Check in for sessions, complete age-appropriate self-check assessments, register for workshops, and see events built for them.",
  },
  {
    role: "Parents & adults",
    icon: HeartHandshake,
    blurb: "Track your own workshops and attendance, and see a high-level snapshot of your child's programs and progress.",
  },
  {
    role: "Volunteers",
    icon: Users,
    blurb: "Manage tasks, sign up for events, log service hours, and export reports of your contributions.",
  },
  {
    role: "Staff",
    icon: Wrench,
    blurb: "Run inventory, workshops, and participant caseloads, and review flagged assessments that need follow-up.",
  },
  {
    role: "Administrators",
    icon: Shield,
    blurb: "See organization-wide dashboards across all three programs, manage users, and generate funder-ready reports.",
  },
];

function AboutPage() {
  return (
    <PageShell>
      <PageHeader title="About Ollivier Community Circle" description="Health equity, delivered with dignity, measured with rigor." />

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="surface-card p-8">
          <span className="stat-label">Mission</span>
          <p className="mt-3 text-lg leading-relaxed text-foreground">{MISSION}</p>
        </div>
        <div className="surface-card border-primary/25 bg-secondary/40 p-8">
          <span className="stat-label">Vision</span>
          <p className="mt-3 text-lg leading-relaxed text-foreground">{VISION}</p>
        </div>
      </div>

      <div className="mt-10">
        <SectionHeading title="What we value" />
        <div className="flex flex-wrap gap-2">
          {VALUES.map((v) => (
            <Badge key={v} variant="secondary" className="px-3 py-1.5 text-sm">
              <Sparkles className="mr-1.5 size-3.5 text-primary" aria-hidden />
              {v}
            </Badge>
          ))}
        </div>
      </div>

      <div className="mt-10">
        <SectionHeading title="Impact highlights" description="A snapshot of what our community has accomplished together" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {IMPACT.map((i) => (
            <div key={i.label} className="surface-card p-5">
              <p className="stat-figure text-4xl">{i.value}</p>
              <p className="stat-label mt-2">{i.label}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-10">
        <SectionHeading title="How the tracker works" description="One platform, tailored to every role at OCC" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {ROLES.map((r) => {
            const Icon = r.icon;
            return (
              <div key={r.role} className="surface-card p-5">
                <span className="flex size-10 items-center justify-center rounded-full bg-secondary">
                  <Icon className="size-5 text-primary" aria-hidden />
                </span>
                <h3 className="mt-3 text-lg">{r.role}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{r.blurb}</p>
              </div>
            );
          })}
        </div>
      </div>

      <div className="mt-10 surface-card flex flex-wrap items-center justify-between gap-4 border-primary/25 bg-secondary/40 p-8">
        <div>
          <h2 className="text-xl">Ready to join the circle?</h2>
          <p className="mt-1 text-sm text-muted-foreground">Create an account to get started with any of our programs.</p>
        </div>
        <Button asChild>
          <Link to="/signup">Sign up</Link>
        </Button>
      </div>
    </PageShell>
  );
}
