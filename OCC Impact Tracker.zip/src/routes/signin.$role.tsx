import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { AuthCard } from "@/components/auth/AuthCard";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import type { Role } from "@/types";

const ROLES: Record<string, { label: string; blurb: string }> = {
  student: { label: "Student", blurb: "Children and teens in Sprout Society or Becoming." },
  parent: { label: "Parent or adult", blurb: "Caregivers and adults in workshops or Fresh Table." },
  volunteer: { label: "Volunteer", blurb: "Track shifts, tasks, and service hours." },
  staff: { label: "Staff", blurb: "Manage inventory, participants, and programs." },
  admin: { label: "Administrator", blurb: "Organization-wide oversight and reporting." },
};

export const Route = createFileRoute("/signin/$role")({
  beforeLoad: ({ params }) => {
    if (!ROLES[params.role]) throw notFound();
  },
  head: ({ params }) => {
    const label = ROLES[params.role]?.label ?? "Sign in";
    return {
      meta: [
        { title: `${label} sign in — OCC Impact Report Tracker` },
        { name: "description", content: `Sign in or create a ${label.toLowerCase()} account for the Ollivier Community Circle impact tracker.` },
        { property: "og:title", content: `${label} sign in — OCC Impact Report Tracker` },
        { property: "og:description", content: `Continue with Google or email to reach your ${label.toLowerCase()} dashboard.` },
      ],
    };
  },
  component: RoleSignIn,
});

function RoleSignIn() {
  const { role } = Route.useParams();
  const meta = ROLES[role]!;

  return (
    <PageShell>
      <PageHeader
        title="Welcome back"
        description="Sign in with Google or your email, or create a new account."
        breadcrumbs={[{ label: "Sign in", to: "/signin" }, { label: meta.label }]}
      />
      <AuthCard role={role as Role} roleLabel={meta.label} blurb={meta.blurb} />
      <p className="mt-8 text-center text-sm text-muted-foreground">
        Wrong role?{" "}
        <Link to="/signin" className="text-primary underline-offset-2 hover:underline">
          Choose a different sign-in
        </Link>
      </p>
    </PageShell>
  );
}
