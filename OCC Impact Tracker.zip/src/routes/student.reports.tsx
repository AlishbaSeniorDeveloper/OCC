import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { FileDown, FileSpreadsheet } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { PageSkeleton, ErrorState, EmptyState } from "@/components/kit/States";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/context/AuthContext";
import { analyticsService } from "@/services/analyticsService";
import { assessmentService } from "@/services/assessmentService";
import { attendanceService } from "@/services/attendanceService";
import { workshopService } from "@/services/workshopService";
import { reportService } from "@/services/reportService";
import { assessmentById } from "@/data/assessments";
import type { Report } from "@/types";

export const Route = createFileRoute("/student/reports")({
  head: () => ({
    meta: [
      { title: "Reports — OCC Impact Report Tracker" },
      { name: "description", content: "Build and export a personal progress report as PDF or CSV." },
      { property: "og:title", content: "Reports — OCC Impact Report Tracker" },
      { property: "og:description", content: "Generate a branded progress report covering your OCC journey." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["student"]}>
      <ReportsPage />
    </ProtectedRoute>
  ),
});

const SECTIONS = [
  { key: "progress", label: "Progress summary" },
  { key: "assessments", label: "Assessment history" },
  { key: "attendance", label: "Attendance" },
  { key: "workshops", label: "Workshops" },
] as const;

type SectionKey = (typeof SECTIONS)[number]["key"];

function ReportsPage() {
  const { user } = useAuth();
  const [selected, setSelected] = useState<Record<SectionKey, boolean>>({
    progress: true,
    assessments: true,
    attendance: true,
    workshops: true,
  });
  const [start, setStart] = useState("2026-01-01");
  const [end, setEnd] = useState(() => new Date().toISOString().slice(0, 10));
  const [saved, setSaved] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [busy, setBusy] = useState<"pdf" | "csv" | null>(null);

  const load = () => {
    setLoading(true);
    setError(false);
    reportService
      .saved()
      .then(setSaved)
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const inRange = (iso: string) => iso >= start && iso <= `${end}T23:59:59.999Z`;

  const buildData = async () => {
    if (!user) throw new Error("Not signed in");
    const [summary, attempts, slots, enrollments, workshops] = await Promise.all([
      analyticsService.studentSummary(user.id),
      assessmentService.attemptsForUser(user.id),
      attendanceService.listForUser(user.id),
      workshopService.enrollmentsForUser(user.id),
      workshopService.list(),
    ]);
    const completed = attempts.filter((a) => a.status === "completed" && inRange(a.completedAt ?? a.startedAt));
    const rangedSlots = slots.filter((s) => inRange(s.scheduledAt));
    const workshopById = new Map(workshops.map((w) => [w.id, w]));
    return { summary, completed, rangedSlots, enrollments, workshopById };
  };

  const dateRangeLabel = `${new Date(start).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })} – ${new Date(end).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}`;

  const exportPdf = async () => {
    if (!user) return;
    setBusy("pdf");
    try {
      const { summary, completed, rangedSlots, enrollments, workshopById } = await buildData();
      const sections = [];
      if (selected.progress) {
        sections.push({
          heading: "Progress summary",
          kpis: [
            { label: "Assessments taken", value: String(summary.assessmentsTaken) },
            { label: "Attendance rate", value: `${summary.attendance.rate}%` },
            { label: "Workshops completed", value: String(summary.workshopsCompleted) },
            { label: "Average score", value: String(summary.averageScore) },
          ],
          paragraphs: [`This report summarizes ${user.fullName}'s progress across OCC programs for the selected date range.`],
        });
      }
      if (selected.assessments) {
        sections.push({
          heading: "Assessment history",
          table: {
            columns: ["Assessment", "Date", "Raw score", "Normalized", "Band"],
            rows: completed.map((a) => [
              assessmentById(a.assessmentId)?.title ?? a.assessmentId,
              new Date(a.completedAt ?? a.startedAt).toLocaleDateString("en-US"),
              a.rawScore,
              a.normalizedScore,
              a.band,
            ]),
          },
        });
      }
      if (selected.attendance) {
        sections.push({
          heading: "Attendance",
          table: {
            columns: ["Session", "Date", "Status", "Location"],
            rows: rangedSlots.map((s) => [s.title, new Date(s.scheduledAt).toLocaleDateString("en-US"), s.status, s.location]),
          },
        });
      }
      if (selected.workshops) {
        sections.push({
          heading: "Workshops",
          table: {
            columns: ["Workshop", "Status", "Feedback rating"],
            rows: enrollments.map((e) => [
              workshopById.get(e.workshopId)?.title ?? e.workshopId,
              e.status,
              e.feedbackRating ? `${e.feedbackRating}/5` : "—",
            ]),
          },
        });
      }
      await reportService.exportPdf({
        title: "Student Progress Report",
        subtitle: "Ollivier Community Circle",
        generatedFor: user.fullName,
        dateRange: dateRangeLabel,
        sections,
      });
      await reportService.record({
        title: "Student Progress Report",
        type: "student-progress",
        scope: user.id,
        filters: { start, end },
        generatedBy: user.id,
        format: "pdf",
      });
      toast.success("PDF report downloaded");
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't generate report");
    } finally {
      setBusy(null);
    }
  };

  const exportCsv = async () => {
    if (!user) return;
    setBusy("csv");
    try {
      const { completed } = await buildData();
      await reportService.exportCsv(
        "student-assessment-history",
        completed.map((a) => ({
          assessment: assessmentById(a.assessmentId)?.title ?? a.assessmentId,
          date: new Date(a.completedAt ?? a.startedAt).toLocaleDateString("en-US"),
          rawScore: a.rawScore,
          normalizedScore: a.normalizedScore,
          band: a.band,
        })),
      );
      await reportService.record({
        title: "Student Assessment History",
        type: "student-progress",
        scope: user.id,
        filters: { start, end },
        generatedBy: user.id,
        format: "csv",
      });
      toast.success("CSV downloaded");
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't export CSV");
    } finally {
      setBusy(null);
    }
  };

  return (
    <PageShell>
      <PageHeader title="Reports" description="Build a personalized progress report and export it as PDF or CSV." />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="surface-card space-y-4 p-6 lg:col-span-2">
          <SectionHeading title="Sections" />
          <div className="grid gap-3 sm:grid-cols-2">
            {SECTIONS.map((s) => (
              <label key={s.key} className="flex items-center gap-2 rounded-lg border border-border p-3 text-sm">
                <Checkbox
                  checked={selected[s.key]}
                  onCheckedChange={(v) => setSelected((prev) => ({ ...prev, [s.key]: Boolean(v) }))}
                />
                {s.label}
              </label>
            ))}
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="start-date">Start date</Label>
              <Input id="start-date" type="date" value={start} onChange={(e) => setStart(e.target.value)} className="mt-1" />
            </div>
            <div>
              <Label htmlFor="end-date">End date</Label>
              <Input id="end-date" type="date" value={end} onChange={(e) => setEnd(e.target.value)} className="mt-1" />
            </div>
          </div>

          <div className="flex flex-wrap gap-2 pt-2">
            <Button onClick={exportPdf} disabled={busy !== null}>
              <FileDown className="mr-1.5 size-4" aria-hidden /> {busy === "pdf" ? "Generating…" : "Export PDF"}
            </Button>
            <Button variant="outline" onClick={exportCsv} disabled={busy !== null}>
              <FileSpreadsheet className="mr-1.5 size-4" aria-hidden /> {busy === "csv" ? "Exporting…" : "Export CSV"}
            </Button>
          </div>
        </div>

        <div className="surface-card p-6">
          <p className="stat-label">About this report</p>
          <p className="mt-2 text-sm text-muted-foreground">
            Reports are branded with the OCC identity and include your assessment scores, attendance, and workshop
            history for the date range you choose.
          </p>
        </div>
      </div>

      <div className="mt-8">
        <SectionHeading title="Previously generated reports" />
        {loading ? (
          <PageSkeleton />
        ) : error ? (
          <ErrorState onRetry={load} />
        ) : saved.filter((r) => r.generatedBy === user?.id).length === 0 ? (
          <EmptyState title="No reports yet" description="Reports you generate will be listed here." />
        ) : (
          <div className="space-y-2">
            {saved
              .filter((r) => r.generatedBy === user?.id)
              .map((r) => (
                <div key={r.id} className="surface-card flex items-center justify-between gap-3 p-4">
                  <div>
                    <p className="text-sm">{r.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(r.generatedAt).toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" })}
                    </p>
                  </div>
                  <span className="rounded-full bg-secondary px-2.5 py-1 text-xs uppercase text-secondary-foreground">{r.format}</span>
                </div>
              ))}
          </div>
        )}
      </div>
    </PageShell>
  );
}
