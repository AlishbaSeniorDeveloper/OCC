import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { CheckCircle2, ChevronLeft, ChevronRight, MapPin } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { PageSkeleton, ErrorState, EmptyState } from "@/components/kit/States";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { attendanceService, withinCheckInWindow, type AttendanceSummary } from "@/services/attendanceService";
import type { AttendanceSlot } from "@/types";

export const Route = createFileRoute("/student/attendance")({
  head: () => ({
    meta: [
      { title: "Attendance — OCC Impact Report Tracker" },
      { name: "description", content: "View your monthly attendance calendar and check in to upcoming sessions." },
      { property: "og:title", content: "Attendance — OCC Impact Report Tracker" },
      { property: "og:description", content: "Monthly attendance calendar with session check-in." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["student"]}>
      <AttendancePage />
    </ProtectedRoute>
  ),
});

const STATUS_LABEL: Record<AttendanceSlot["status"], string> = {
  upcoming: "Upcoming",
  attended: "Attended",
  missed: "Missed",
  excused: "Excused",
};

const STATUS_DOT: Record<AttendanceSlot["status"], string> = {
  upcoming: "bg-sage",
  attended: "bg-primary",
  missed: "bg-terracotta",
  excused: "bg-secondary-foreground/40",
};

function AttendancePage() {
  const { user } = useAuth();
  const [slots, setSlots] = useState<AttendanceSlot[]>([]);
  const [summary, setSummary] = useState<AttendanceSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [cursor, setCursor] = useState(() => {
    const d = new Date();
    d.setDate(1);
    return d;
  });
  const [now, setNow] = useState(() => new Date());

  const load = () => {
    if (!user) return;
    setLoading(true);
    setError(false);
    Promise.all([attendanceService.listForUser(user.id), attendanceService.summaryForUser(user.id)])
      .then(([s, sum]) => {
        setSlots(s);
        setSummary(sum);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const handleCheckIn = async (slot: AttendanceSlot) => {
    if (!withinCheckInWindow(slot, now)) {
      toast.error("Check-in isn't open yet", { description: "You can check in starting 30 minutes before the session." });
      return;
    }
    try {
      await attendanceService.checkIn(slot.id);
      toast.success(`Checked in to ${slot.title}`);
      setNow(new Date());
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't check in");
    }
  };

  const monthLabel = cursor.toLocaleDateString("en-US", { month: "long", year: "numeric" });

  const days = useMemo(() => {
    const year = cursor.getFullYear();
    const month = cursor.getMonth();
    const firstDay = new Date(year, month, 1);
    const startWeekday = firstDay.getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const cells: { date: Date | null; slots: AttendanceSlot[] }[] = [];
    for (let i = 0; i < startWeekday; i++) cells.push({ date: null, slots: [] });
    for (let d = 1; d <= daysInMonth; d++) {
      const date = new Date(year, month, d);
      const key = date.toDateString();
      const daySlots = slots.filter((s) => new Date(s.scheduledAt).toDateString() === key);
      cells.push({ date, slots: daySlots });
    }
    return cells;
  }, [cursor, slots]);

  const upcoming = slots.filter((s) => s.status === "upcoming").sort((a, b) => a.scheduledAt.localeCompare(b.scheduledAt));
  const past = slots.filter((s) => s.status !== "upcoming").sort((a, b) => b.scheduledAt.localeCompare(a.scheduledAt));

  if (loading) {
    return (
      <PageShell>
        <PageSkeleton />
      </PageShell>
    );
  }

  if (error) {
    return (
      <PageShell>
        <ErrorState onRetry={load} />
      </PageShell>
    );
  }

  return (
    <PageShell>
      <PageHeader title="Attendance" description="Track your assessment slots and check in when it's time." />

      {summary && (
        <StatGrid className="mb-8">
          <StatCard label="Attendance rate" value={`${summary.rate}%`} />
          <StatCard label="Attended" value={summary.attended} />
          <StatCard label="Missed" value={summary.missed} />
          <StatCard label="Current streak" value={summary.streak} hint="Consecutive attended sessions" />
        </StatGrid>
      )}

      <div className="surface-card p-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl">{monthLabel}</h2>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))} aria-label="Previous month">
              <ChevronLeft className="size-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))} aria-label="Next month">
              <ChevronRight className="size-4" />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-1 text-center text-xs text-muted-foreground">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
            <div key={d} className="py-1">
              {d}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {days.map((cell, i) => (
            <div
              key={i}
              className={cn(
                "min-h-20 rounded-lg border border-border p-1.5 text-xs",
                cell.date && cell.date.toDateString() === new Date().toDateString() && "border-primary/50 bg-accent/30",
                !cell.date && "border-transparent",
              )}
            >
              {cell.date && (
                <>
                  <p className="mb-1 text-right text-[11px] text-muted-foreground">{cell.date.getDate()}</p>
                  <div className="space-y-1">
                    {cell.slots.map((s) => (
                      <div key={s.id} className="flex items-center gap-1 rounded bg-secondary/60 px-1 py-0.5 text-[10px]" title={s.title}>
                        <span className={cn("size-1.5 shrink-0 rounded-full", STATUS_DOT[s.status])} aria-hidden />
                        <span className="truncate">{s.title}</span>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          ))}
        </div>

        <div className="mt-4 flex flex-wrap gap-4 text-xs text-muted-foreground">
          {(Object.keys(STATUS_LABEL) as AttendanceSlot["status"][]).map((s) => (
            <span key={s} className="flex items-center gap-1.5">
              <span className={cn("size-2 rounded-full", STATUS_DOT[s])} aria-hidden />
              {STATUS_LABEL[s]}
            </span>
          ))}
        </div>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <div>
          <SectionHeading title="Upcoming sessions" />
          {upcoming.length === 0 ? (
            <EmptyState title="Nothing scheduled" description="You have no upcoming sessions right now." />
          ) : (
            <div className="space-y-3">
              {upcoming.map((s) => (
                <div key={s.id} className="surface-card flex items-center justify-between gap-3 p-4">
                  <div>
                    <p className="text-sm">{s.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(s.scheduledAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                    </p>
                    <p className="flex items-center gap-1 text-xs text-muted-foreground">
                      <MapPin className="size-3" aria-hidden /> {s.location}
                    </p>
                  </div>
                  <Button size="sm" onClick={() => handleCheckIn(s)} disabled={!withinCheckInWindow(s, now)}>
                    <CheckCircle2 className="mr-1.5 size-4" aria-hidden /> Check in
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div>
          <SectionHeading title="Past sessions" />
          {past.length === 0 ? (
            <EmptyState title="No history yet" description="Past sessions will appear here." />
          ) : (
            <div className="max-h-[420px] space-y-3 overflow-y-auto pr-1">
              {past.map((s) => (
                <div key={s.id} className="surface-card flex items-center justify-between gap-3 p-4">
                  <div>
                    <p className="text-sm">{s.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(s.scheduledAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                    </p>
                  </div>
                  <Badge variant="outline" className={cn(s.status === "attended" && "border-primary/40 text-primary", s.status === "missed" && "border-terracotta/40 text-terracotta")}>
                    {STATUS_LABEL[s.status]}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </PageShell>
  );
}
