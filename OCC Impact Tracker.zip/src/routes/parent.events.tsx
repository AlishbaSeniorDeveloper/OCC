import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { CalendarDays, MapPin, Users } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { PageSkeleton, EmptyState, ErrorState } from "@/components/kit/States";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { eventService } from "@/services/eventService";
import type { Event } from "@/types";

export const Route = createFileRoute("/parent/events")({
  head: () => ({
    meta: [
      { title: "Community events — OCC Impact Report Tracker" },
      { name: "description", content: "Browse and RSVP to upcoming OCC community events." },
      { property: "og:title", content: "Community events — OCC Impact Report Tracker" },
      { property: "og:description", content: "Upcoming distributions, workshops, and community events at OCC." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["parent"]}>
      <EventsPage />
    </ProtectedRoute>
  ),
});

function EventsPage() {
  const [events, setEvents] = useState<Event[]>([]);
  const [rsvps, setRsvps] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    setError(false);
    Promise.all([eventService.list({ upcomingOnly: true }), eventService.myRsvps()])
      .then(([e, r]) => {
        setEvents(e);
        setRsvps(r);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const grouped = useMemo(() => {
    const map = new Map<string, Event[]>();
    for (const e of events) {
      const key = new Date(e.startsAt).toLocaleDateString("en-US", { month: "long", year: "numeric" });
      const list = map.get(key) ?? [];
      list.push(e);
      map.set(key, list);
    }
    return [...map.entries()];
  }, [events]);

  if (loading) {
    return (
      <PageShell>
        <PageSkeleton />
      </PageShell>
    );
  }
  if (error) {
    return (
      <PageShell>
        <ErrorState onRetry={load} />
      </PageShell>
    );
  }

  const rsvpSet = new Set(rsvps);

  const toggleRsvp = async (event: Event) => {
    setBusyId(event.id);
    try {
      if (rsvpSet.has(event.id)) {
        await eventService.cancelRsvp(event.id);
        toast.success("RSVP cancelled");
      } else {
        await eventService.rsvp(event.id);
        toast.success("You're on the list!");
      }
      load();
    } catch {
      toast.error("Something went wrong");
    } finally {
      setBusyId(null);
    }
  };

  return (
    <PageShell>
      <PageHeader title="Community events" description="RSVP for distributions, workshops, and community gatherings." />

      {events.length === 0 ? (
        <EmptyState title="No upcoming events" description="Check back soon for new community events." />
      ) : (
        <div className="space-y-8">
          {grouped.map(([month, list]) => (
            <div key={month}>
              <SectionHeading title={month} />
              <div className="grid gap-4 sm:grid-cols-2">
                {list.map((event) => {
                  const going = rsvpSet.has(event.id);
                  const full = event.rsvpCount >= event.capacity;
                  return (
                    <div key={event.id} className="surface-card flex flex-col gap-3 p-5">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="text-lg">{event.title}</h3>
                        <Badge variant="outline" className="shrink-0 capitalize">
                          {event.type}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{event.description}</p>
                      <div className="space-y-1.5 text-sm text-muted-foreground">
                        <p className="inline-flex items-center gap-1.5">
                          <CalendarDays className="size-4 text-sage" aria-hidden />
                          {new Date(event.startsAt).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" })}
                        </p>
                        <p className="inline-flex items-center gap-1.5">
                          <MapPin className="size-4 text-sage" aria-hidden />
                          {event.location}
                        </p>
                        <p className="inline-flex items-center gap-1.5">
                          <Users className="size-4 text-sage" aria-hidden />
                          {event.rsvpCount}/{event.capacity} RSVP'd
                        </p>
                      </div>
                      <Button
                        size="sm"
                        variant={going ? "outline" : "default"}
                        disabled={busyId === event.id || (!going && full)}
                        onClick={() => toggleRsvp(event)}
                      >
                        {busyId === event.id
                          ? "Please wait…"
                          : going
                            ? "Cancel RSVP"
                            : full
                              ? "Event full"
                              : "RSVP"}
                      </Button>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </PageShell>
  );
}
