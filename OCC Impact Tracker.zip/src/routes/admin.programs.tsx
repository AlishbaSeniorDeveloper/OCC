import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  PolarAngleAxis,
  PolarGrid,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { StatCard, StatGrid, ProgressMeter } from "@/components/kit/StatCard";
import { ChartCard, CHART_COLORS, CHART_SERIES, axisProps, tooltipStyle } from "@/components/kit/ChartCard";
import { DataTable, type Column } from "@/components/kit/DataTable";
import { ErrorState, PageSkeleton } from "@/components/kit/States";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { analyticsService } from "@/services/analyticsService";
import { FRESH_TABLE_GOALS } from "@/data/programs";

export const Route = createFileRoute("/admin/programs")({
  head: () => ({
    meta: [
      { title: "Program dashboards — OCC Impact Report Tracker" },
      { name: "description", content: "Per-program dashboards for The Fresh Table, Sprout Society, and Becoming." },
      { property: "og:title", content: "Program dashboards — OCC Impact Report Tracker" },
      { property: "og:description", content: "Per-program dashboards for The Fresh Table, Sprout Society, and Becoming." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["admin"]}>
      <ProgramsPage />
    </ProtectedRoute>
  ),
});

function ProgramsPage() {
  return (
    <PageShell>
      <PageHeader title="Program dashboards" description="Deep-dive into each program's enrollment, outcomes, and impact." />
      <Tabs defaultValue="fresh-table">
        <TabsList className="mb-6 flex-wrap">
          <TabsTrigger value="fresh-table">The Fresh Table</TabsTrigger>
          <TabsTrigger value="sprout-society">Sprout Society</TabsTrigger>
          <TabsTrigger value="becoming">Becoming</TabsTrigger>
        </TabsList>
        <TabsContent value="fresh-table">
          <FreshTableTab />
        </TabsContent>
        <TabsContent value="sprout-society">
          <SproutTab />
        </TabsContent>
        <TabsContent value="becoming">
          <BecomingTab />
        </TabsContent>
      </Tabs>
    </PageShell>
  );
}

type FreshData = Awaited<ReturnType<typeof analyticsService.freshTableDashboard>>;
type SproutData = Awaited<ReturnType<typeof analyticsService.sproutDashboard>>;
type BecomingData = Awaited<ReturnType<typeof analyticsService.becomingDashboard>>;

function FreshTableTab() {
  const [data, setData] = useState<FreshData | null>(null);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    setError(false);
    analyticsService.freshTableDashboard().then(setData).catch(() => setError(true)).finally(() => setLoading(false));
  };
  useEffect(load, []);

  if (loading) return <PageSkeleton />;
  if (error || !data) return <ErrorState onRetry={load} />;

  const zipColumns: Column<{ id: string; zip: string; households: number; pounds: number }>[] = [
    { key: "zip", header: "Zip code", sortValue: (r) => r.zip },
    { key: "households", header: "Households served", sortValue: (r) => r.households },
    { key: "pounds", header: "Pounds distributed", sortValue: (r) => r.pounds },
  ];

  return (
    <div className="space-y-8">
      <StatGrid className="lg:grid-cols-3 xl:grid-cols-6">
        <StatCard label="Distributions" value={data.distributions} />
        <StatCard label="Individuals served" value={data.individuals.toLocaleString()} />
        <StatCard label="Avg household size" value={data.averageHouseholdSize} />
        <StatCard label="New households" value={data.newHouseholds} />
        <StatCard label="Repeat households" value={data.repeatHouseholds} />
        <StatCard label="Households served" value={data.households.toLocaleString()} />
      </StatGrid>

      <div className="grid gap-4 sm:grid-cols-2">
        <ProgressMeter label="Households served (annual goal)" value={data.households} max={FRESH_TABLE_GOALS.households} />
        <ProgressMeter label="Pounds distributed (annual goal)" value={data.pounds} max={FRESH_TABLE_GOALS.pounds} unit=" lbs" />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <ChartCard
          title="Distribution timeline"
          description="Households served and pounds distributed by event."
          className="lg:col-span-2"
          data={data.timeline.map((t) => ({ Date: t.label, Households: t.households, Pounds: t.pounds }))}
        >
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data.timeline}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="label" {...axisProps} />
              <YAxis {...axisProps} />
              <Tooltip {...tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Line type="monotone" dataKey="households" name="Households" stroke={CHART_COLORS.hunter} strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="pounds" name="Pounds" stroke={CHART_COLORS.gold} strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard
          title="Food-security band distribution"
          description="USDA six-item screener results among served households."
          data={data.securityDistribution.map((s) => ({ Band: s.band, Count: s.count }))}
        >
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Tooltip {...tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Pie data={data.securityDistribution} dataKey="count" nameKey="band" outerRadius={90} label>
                {data.securityDistribution.map((s, i) => (
                  <Cell key={s.band} fill={CHART_SERIES[i % CHART_SERIES.length]} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard
          title="Pounds distributed by category"
          data={data.itemsByCategory.map((c) => ({ Category: c.category, Pounds: c.pounds }))}
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.itemsByCategory}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="category" {...axisProps} interval={0} angle={-20} textAnchor="end" height={60} />
              <YAxis {...axisProps} />
              <Tooltip {...tooltipStyle} />
              <Bar dataKey="pounds" name="Pounds" fill={CHART_COLORS.sage} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div>
        <SectionHeading title="Zip code reach" description="Households and pounds distributed by zip code." />
        <DataTable
          rows={data.zipReach.map((z) => ({ id: z.zip, ...z }))}
          columns={zipColumns}
          searchKeys={(r) => r.zip}
          exportName="fresh-table-zip-reach"
        />
      </div>
    </div>
  );
}

function SproutTab() {
  const [data, setData] = useState<SproutData | null>(null);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    setError(false);
    analyticsService.sproutDashboard().then(setData).catch(() => setError(true)).finally(() => setLoading(false));
  };
  useEffect(load, []);

  if (loading) return <PageSkeleton />;
  if (error || !data) return <ErrorState onRetry={load} />;

  const prePostData = [
    { name: "Emotional regulation", Pre: data.emotionalRegulation.pre, Post: data.emotionalRegulation.post },
    { name: "Coping skills", Pre: data.coping.pre, Post: data.coping.post },
    { name: "Self-esteem", Pre: data.selfEsteem.pre, Post: data.selfEsteem.post },
  ];

  return (
    <div className="space-y-8">
      <StatGrid className="lg:grid-cols-3 xl:grid-cols-6">
        <StatCard label="Children enrolled" value={data.childrenEnrolled} />
        <StatCard label="Attendance rate" value={`${data.attendanceRate}%`} />
        <StatCard label="Retention rate" value={`${data.retentionRate}%`} />
        <StatCard label="Goals set" value={data.goalsSet} />
        <StatCard label="Goals achieved" value={data.goalsAchieved} />
        <StatCard label="Caregiver feedback avg" value={data.caregiverAverage} />
      </StatGrid>

      <ChartCard
        title="Pre/post: emotional regulation, coping, self-esteem"
        description="Average normalized scores before and after program participation."
        data={prePostData.map((d) => ({ Measure: d.name, Pre: d.Pre, Post: d.Post }))}
      >
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={prePostData}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="name" {...axisProps} />
            <YAxis {...axisProps} domain={[0, 100]} />
            <Tooltip {...tooltipStyle} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Bar dataKey="Pre" fill={CHART_COLORS.sage} radius={[6, 6, 0, 0]} />
            <Bar dataKey="Post" fill={CHART_COLORS.hunter} radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard
        title="Topic coverage"
        description="Number of workshop sessions delivered per topic."
        data={data.topicCoverage.map((t) => ({ Topic: t.topic, Sessions: t.sessions }))}
      >
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data.topicCoverage} layout="vertical" margin={{ left: 24 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis type="number" {...axisProps} allowDecimals={false} />
            <YAxis type="category" dataKey="topic" {...axisProps} width={160} />
            <Tooltip {...tooltipStyle} />
            <Bar dataKey="sessions" fill={CHART_COLORS.gold} radius={[0, 6, 6, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  );
}

function BecomingTab() {
  const [data, setData] = useState<BecomingData | null>(null);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    setError(false);
    analyticsService.becomingDashboard().then(setData).catch(() => setError(true)).finally(() => setLoading(false));
  };
  useEffect(load, []);

  if (loading) return <PageSkeleton />;
  if (error || !data) return <ErrorState onRetry={load} />;

  const bandKeys = (rows: BecomingData["phqaBands"]) => {
    const keys = new Set<string>();
    for (const r of rows) for (const k of Object.keys(r)) if (k !== "month" && k !== "label") keys.add(k);
    return [...keys];
  };
  const phqKeys = bandKeys(data.phqaBands);
  const gadKeys = bandKeys(data.gadBands);

  return (
    <div className="space-y-8">
      <StatGrid className="lg:grid-cols-3 xl:grid-cols-6">
        <StatCard label="Teens enrolled" value={data.teensEnrolled} />
        <StatCard label="Self-esteem avg" value={data.selfEsteemAverage} />
        <StatCard label="Resumes completed" value={data.resumesCompleted} />
        <StatCard label="Career sessions attended" value={data.careerSessionsAttended} />
        <StatCard label="Post-secondary goals" value={data.postSecondaryGoals} />
        <StatCard label="Service hours" value={Math.round(data.communityServiceHours)} />
      </StatGrid>
      <StatGrid className="sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Mentorship matches" value={data.mentorshipMatches} size="sm" />
        <StatCard label="Goals set" value={data.goalsSet} size="sm" />
        <StatCard label="Goals achieved" value={data.goalsAchieved} size="sm" />
        <StatCard label="Goal completion rate" value={data.goalsSet ? `${Math.round((data.goalsAchieved / data.goalsSet) * 100)}%` : "0%"} size="sm" />
      </StatGrid>

      <div className="grid gap-4 lg:grid-cols-2">
        <ChartCard
          title="PHQ-A band trend"
          description="Depression screener band distribution over time."
          data={data.phqaBands.map((p) => ({ Month: p.label, ...Object.fromEntries(phqKeys.map((k) => [k, p[k] ?? 0])) }))}
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.phqaBands}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="label" {...axisProps} />
              <YAxis {...axisProps} allowDecimals={false} />
              <Tooltip {...tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 10 }} />
              {phqKeys.map((k, i) => (
                <Bar key={k} dataKey={k} name={k} stackId="a" fill={CHART_SERIES[i % CHART_SERIES.length]} />
              ))}
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard
          title="GAD-7 band trend"
          description="Anxiety screener band distribution over time."
          data={data.gadBands.map((p) => ({ Month: p.label, ...Object.fromEntries(gadKeys.map((k) => [k, p[k] ?? 0])) }))}
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.gadBands}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="label" {...axisProps} />
              <YAxis {...axisProps} allowDecimals={false} />
              <Tooltip {...tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 10 }} />
              {gadKeys.map((k, i) => (
                <Bar key={k} dataKey={k} name={k} stackId="a" fill={CHART_SERIES[i % CHART_SERIES.length]} />
              ))}
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard
          title="Workforce readiness"
          description="Average domain scores (0–100) across enrolled teens."
          className="lg:col-span-2"
          data={data.workforceRadar.map((d) => ({ Domain: d.domain, Score: d.score }))}
        >
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={data.workforceRadar} outerRadius={100}>
              <PolarGrid stroke="var(--border)" />
              <PolarAngleAxis dataKey="domain" tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} />
              <Tooltip {...tooltipStyle} />
              <Radar dataKey="score" stroke={CHART_COLORS.terracotta} fill={CHART_COLORS.terracotta} fillOpacity={0.35} />
            </RadarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
}
