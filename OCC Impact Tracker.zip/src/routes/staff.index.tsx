import { createFileRoute, Link } from "@tanstack/react-router";
import { AlertTriangle, Box, ClipboardList, PackageCheck, Scale, Weight } from "lucide-react";
import { useEffect, useState } from "react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { ChartCard, axisProps, tooltipStyle } from "@/components/kit/ChartCard";
import { PageSkeleton, EmptyState } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/context/AuthContext";
import { inventoryService, stockHealth, type StockHealth } from "@/services/inventoryService";
import { assessmentService } from "@/services/assessmentService";
import { taskService, isOverdue } from "@/services/taskService";
import { userService } from "@/services/userService";
import type { AssessmentAttempt, InventoryItem, Task, User } from "@/types";
import { assessmentById } from "@/data/assessments";

export const Route = createFileRoute("/staff/")({
  head: () => ({
    meta: [
      { title: "Staff dashboard — OCC Impact Report Tracker" },
      { name: "description", content: "Your staff dashboard for the Ollivier Community Circle impact tracker." },
      { property: "og:title", content: "Staff dashboard — OCC Impact Report Tracker" },
      { property: "og:description", content: "Inventory health, flagged assessments, and open tasks for OCC staff." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["staff"]}>
      <Dashboard />
    </ProtectedRoute>
  ),
});

const healthTone: Record<StockHealth, string> = {
  healthy: "bg-accent text-accent-foreground border-primary/25",
  watch: "bg-secondary text-secondary-foreground border-sage/50",
  low: "bg-terracotta/16 text-terracotta border-terracotta/40",
};

function Dashboard() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [flagged, setFlagged] = useState<AssessmentAttempt[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    if (!user) return;
    let alive = true;
    Promise.all([
      inventoryService.list(),
      assessmentService.flaggedAttempts(user.programs),
      taskService.listForUser(user.id),
      userService.list(),
    ]).then(([inv, flags, tks, us]) => {
      if (!alive) return;
      setItems(inv);
      setFlagged(flags);
      setTasks(tks);
      setUsers(us);
      setLoading(false);
    });
    return () => {
      alive = false;
    };
  }, [user]);

  if (loading) {
    return (
      <PageShell>
        <PageHeader title="Staff dashboard" description="Loading your operations overview…" />
        <PageSkeleton />
      </PageShell>
    );
  }

  const totalItems = items.length;
  const lowStock = items.filter((i) => stockHealth(i) === "low");
  const watchStock = items.filter((i) => stockHealth(i) === "watch");
  const poundsOnHand = Math.round(items.reduce((s, i) => s + i.quantityOnHand * i.lbsPerUnit, 0));
  const lastRestock = items.reduce<string | null>((latest, i) => {
    if (!i.lastRestockedAt) return latest;
    if (!latest || i.lastRestockedAt > latest) return i.lastRestockedAt;
    return latest;
  }, null);

  const byCategory = new Map<string, number>();
  for (const item of items) {
    byCategory.set(item.category, (byCategory.get(item.category) ?? 0) + item.quantityOnHand * item.lbsPerUnit);
  }
  const categoryData = Array.from(byCategory.entries())
    .map(([category, lbs]) => ({ category, lbs: Math.round(lbs) }))
    .sort((a, b) => b.lbs - a.lbs);

  const userName = (id: string) => users.find((u) => u.id === id)?.fullName ?? "Unknown";

  const openTasks = tasks.filter((t) => t.status !== "done").slice(0, 5);
  const priorityTone: Record<Task["priority"], string> = {
    low: "bg-secondary text-secondary-foreground border-sage/50",
    medium: "bg-accent text-accent-foreground border-primary/25",
    high: "bg-terracotta/16 text-terracotta border-terracotta/40",
  };

  return (
    <PageShell>
      <PageHeader
        title={`Welcome, ${user?.fullName ?? "friend"}`}
        description="Here's the pantry, assessment, and task snapshot for your programs today."
      />

      <StatGrid>
        <StatCard label="Inventory items" value={totalItems} icon={Box} hint="Tracked pantry SKUs" />
        <StatCard
          label="Low stock items"
          value={lowStock.length}
          icon={AlertTriangle}
          hint={`${watchStock.length} more on watch`}
        />
        <StatCard label="Pounds on hand" value={poundsOnHand.toLocaleString()} icon={Weight} hint="Across all categories" />
        <StatCard
          label="Last restock"
          value={lastRestock ? new Date(lastRestock).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "—"}
          icon={PackageCheck}
        />
      </StatGrid>

      {lowStock.length > 0 && (
        <div className="surface-card mt-6 flex flex-wrap items-center justify-between gap-3 border-terracotta/40 p-5">
          <div className="flex items-center gap-3">
            <AlertTriangle className="size-5 text-terracotta" aria-hidden />
            <div>
              <p className="text-sm font-medium text-foreground">
                {lowStock.length} item{lowStock.length === 1 ? "" : "s"} below reorder point
              </p>
              <p className="text-xs text-muted-foreground">
                {lowStock.slice(0, 4).map((i) => i.name).join(", ")}
                {lowStock.length > 4 ? "…" : ""}
              </p>
            </div>
          </div>
          <Link to="/staff/inventory" className="text-sm font-medium text-primary underline underline-offset-4">
            Manage inventory
          </Link>
        </div>
      )}

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <div>
          <SectionHeading title="Stock health" description="On hand vs. par level for every item" />
          <div className="surface-card max-h-[420px] space-y-3 overflow-y-auto p-4">
            {items.map((item) => {
              const health = stockHealth(item);
              const pct = Math.min(100, Math.round((item.quantityOnHand / Math.max(1, item.parLevel)) * 100));
              return (
                <div key={item.id} className="space-y-1.5 border-b border-border/60 pb-3 last:border-0 last:pb-0">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-medium text-foreground">{item.name}</p>
                    <Badge variant="outline" className={healthTone[health]}>
                      {health}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>
                      {item.quantityOnHand} / {item.parLevel} {item.unitLabel}
                    </span>
                    <span>{pct}%</span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
                    <div
                      className="h-full rounded-full bg-primary transition-all"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <ChartCard
          title="Pounds on hand by category"
          description="Current inventory weight breakdown"
          data={categoryData.map((c) => ({ category: c.category, lbs: c.lbs }))}
          columns={[
            { key: "category", label: "Category" },
            { key: "lbs", label: "Pounds" },
          ]}
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={categoryData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="category" {...axisProps} interval={0} angle={-20} textAnchor="end" height={60} />
              <YAxis {...axisProps} />
              <Tooltip {...tooltipStyle} />
              <Bar dataKey="lbs" fill="var(--hunter)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <div>
          <SectionHeading
            title="Flagged assessments"
            description="Attempts needing your review"
            actions={
              <Link to="/staff/participants" className="text-sm font-medium text-primary underline underline-offset-4">
                View all
              </Link>
            }
          />
          {flagged.length === 0 ? (
            <EmptyState title="No flags right now" description="Flagged assessment attempts will show up here for review." />
          ) : (
            <div className="surface-card space-y-3 p-4">
              {flagged.slice(0, 5).map((attempt) => (
                <div key={attempt.id} className="flex items-center justify-between gap-3 border-b border-border/60 pb-3 last:border-0 last:pb-0">
                  <div>
                    <p className="text-sm font-medium text-foreground">{userName(attempt.userId)}</p>
                    <p className="text-xs text-muted-foreground">
                      {assessmentById(attempt.assessmentId)?.title ?? "Assessment"} · {attempt.band}
                    </p>
                  </div>
                  <Badge variant="outline" className="border-terracotta/40 bg-terracotta/12 text-terracotta">
                    {attempt.reviewedAt ? "Reviewed" : "Needs review"}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </div>

        <div>
          <SectionHeading
            title="Your open tasks"
            description="Assigned by your admin"
            actions={
              <Link to="/staff/tasks" className="text-sm font-medium text-primary underline underline-offset-4">
                View all
              </Link>
            }
          />
          {openTasks.length === 0 ? (
            <EmptyState title="All caught up" description="You have no open tasks right now." />
          ) : (
            <div className="surface-card space-y-3 p-4">
              {openTasks.map((task) => (
                <div key={task.id} className="flex items-center justify-between gap-3 border-b border-border/60 pb-3 last:border-0 last:pb-0">
                  <div>
                    <p className="text-sm font-medium text-foreground">{task.title}</p>
                    <p className="text-xs text-muted-foreground">
                      Due {new Date(task.dueDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                      {isOverdue(task) ? " · Overdue" : ""}
                    </p>
                  </div>
                  <Badge variant="outline" className={priorityTone[task.priority]}>
                    {task.priority}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </PageShell>
  );
}
