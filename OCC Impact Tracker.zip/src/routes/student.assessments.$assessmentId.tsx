import { createFileRoute, Link, useNavigate, useParams } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { AlertTriangle, ArrowLeft, ArrowRight, CheckCircle2, PhoneCall, ShieldAlert } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import { PageSkeleton, ErrorState } from "@/components/kit/States";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { assessmentService } from "@/services/assessmentService";
import { assessmentById, SAFETY_DISCLAIMER, SAFETY_MESSAGE } from "@/data/assessments";
import { bandToneClass, CRISIS_RESOURCES } from "@/lib/scoring";
import type { Assessment, AssessmentAttempt, AttemptResponse } from "@/types";

export const Route = createFileRoute("/student/assessments/$assessmentId")({
  head: () => ({
    meta: [
      { title: "Take assessment — OCC Impact Report Tracker" },
      { name: "description", content: "Complete this assessment one question at a time and see your results." },
      { property: "og:title", content: "Take assessment — OCC Impact Report Tracker" },
      { property: "og:description", content: "Assessment intake flow with progress tracking and scoring." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["student"]}>
      <TakeAssessment />
    </ProtectedRoute>
  ),
});

type Stage = "intro" | "taking" | "result";

function TakeAssessment() {
  const { assessmentId } = useParams({ from: "/student/assessments/$assessmentId" });
  const { user } = useAuth();
  const navigate = useNavigate();

  const instrument: Assessment | undefined = assessmentById(assessmentId);
  const [stage, setStage] = useState<Stage>("intro");
  const [attempt, setAttempt] = useState<AssessmentAttempt | null>(null);
  const [responses, setResponses] = useState<Record<string, number>>({});
  const [textResponses, setTextResponses] = useState<Record<string, string>>({});
  const [index, setIndex] = useState(0);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<AssessmentAttempt | null>(null);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
  }, []);

  if (!instrument) {
    return (
      <PageShell>
        <ErrorState title="Assessment not found" description="This assessment doesn't exist or is no longer available." />
      </PageShell>
    );
  }

  const questions = [...instrument.questions].sort((a, b) => a.order - b.order);
  const total = questions.length;
  const current = questions[index];
  const pct = total ? Math.round(((index + (stage === "result" ? total : 0)) / total) * 100) : 0;

  const toAttemptResponses = (): AttemptResponse[] =>
    questions.map((q) => ({
      questionId: q.id,
      value: q.type === "text" ? 0 : responses[q.id] ?? 0,
    }));

  const start = async () => {
    if (!user) return;
    setBusy(true);
    try {
      const a = await assessmentService.startAttempt(instrument.id, user.id);
      setAttempt(a);
      const seeded: Record<string, number> = {};
      const seededText: Record<string, string> = {};
      for (const r of a.responses) seeded[r.questionId] = r.value;
      setResponses(seeded);
      setTextResponses(seededText);
      setStage("taking");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't start assessment");
    } finally {
      setBusy(false);
    }
  };

  const autosave = (next: Record<string, number>) => {
    if (!attempt) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      const payload: AttemptResponse[] = questions
        .filter((q) => next[q.id] !== undefined)
        .map((q) => ({ questionId: q.id, value: next[q.id] }));
      assessmentService.saveProgress(attempt.id, payload).catch(() => undefined);
    }, 350);
  };

  const selectOption = (questionId: string, value: number) => {
    const next = { ...responses, [questionId]: value };
    setResponses(next);
    autosave(next);
  };

  const canAdvance = current ? (current.type === "text" ? true : responses[current.id] !== undefined) : false;

  const goNext = () => {
    if (index < total - 1) setIndex(index + 1);
    else void submit();
  };

  const goBack = () => {
    if (index > 0) setIndex(index - 1);
  };

  const submit = async () => {
    if (!attempt) return;
    setBusy(true);
    try {
      const payload = toAttemptResponses();
      const completed = await assessmentService.submitAttempt(attempt.id, payload);
      setResult(completed);
      setStage("result");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't submit assessment");
    } finally {
      setBusy(false);
    }
  };

  if (stage === "intro") {
    return (
      <PageShell>
        <PageHeader
          title={instrument.title}
          description={instrument.description}
          breadcrumbs={[{ label: "Assessments", to: "/student/assessments" }, { label: instrument.title }]}
        />
        <div className="surface-card space-y-4 p-6">
          <p className="text-sm text-muted-foreground">
            {instrument.questions.length} questions · about {instrument.estimatedMinutes} minutes
          </p>
          <div className="flex items-start gap-3 rounded-lg border border-terracotta/30 bg-terracotta/10 p-4">
            <ShieldAlert className="mt-0.5 size-5 shrink-0 text-terracotta" aria-hidden />
            <p className="text-sm text-foreground">{SAFETY_DISCLAIMER}</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={start} disabled={busy}>
              {busy ? "Starting…" : "Start assessment"}
            </Button>
            <Button variant="outline" asChild>
              <Link to="/student/assessments">Cancel</Link>
            </Button>
          </div>
        </div>
      </PageShell>
    );
  }

  if (stage === "result" && result) {
    const bandInfo = instrument.bands.find((b) => b.label === result.band);
    return (
      <PageShell>
        <PageHeader
          title="Your results"
          description={instrument.title}
          breadcrumbs={[{ label: "Assessments", to: "/student/assessments" }, { label: "Results" }]}
        />
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="surface-card p-6 lg:col-span-2">
            <div className="flex flex-wrap items-center gap-3">
              <Badge variant="outline" className={cn("text-sm", bandToneClass(bandInfo?.tone ?? "good"))}>
                {result.band}
              </Badge>
              {result.flagged && (
                <Badge variant="outline" className="border-terracotta/40 bg-terracotta/10 text-terracotta">
                  Flagged for follow-up
                </Badge>
              )}
            </div>
            <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3">
              <div>
                <p className="stat-label">Raw score</p>
                <p className="stat-figure text-3xl">{result.rawScore}</p>
              </div>
              <div>
                <p className="stat-label">Normalized</p>
                <p className="stat-figure text-3xl">{result.normalizedScore}</p>
              </div>
            </div>
            <p className="mt-4 text-sm text-muted-foreground">{bandInfo?.interpretation}</p>

            {result.flagged && (
              <div className="mt-6 space-y-3 rounded-lg border border-terracotta/40 bg-terracotta/10 p-4">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="mt-0.5 size-5 shrink-0 text-terracotta" aria-hidden />
                  <p className="text-sm text-foreground">{SAFETY_MESSAGE}</p>
                </div>
                <div className="space-y-2">
                  {CRISIS_RESOURCES.map((r) => (
                    <a key={r.name} href={r.action} className="flex items-center gap-2 rounded-md bg-card p-3 text-sm hover:bg-secondary">
                      <PhoneCall className="size-4 shrink-0 text-terracotta" aria-hidden />
                      <span>
                        <span className="block">{r.name}</span>
                        <span className="block text-xs text-muted-foreground">{r.detail}</span>
                      </span>
                    </a>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-6 flex gap-2">
              <Button asChild>
                <Link to="/student/assessments">
                  <CheckCircle2 className="mr-1.5 size-4" aria-hidden /> Back to assessments
                </Link>
              </Button>
            </div>
          </div>
          <div className="surface-card p-6">
            <p className="stat-label">Instrument</p>
            <p className="mt-2 text-sm">{instrument.title}</p>
            <p className="mt-1 text-xs text-muted-foreground">{instrument.description}</p>
          </div>
        </div>
      </PageShell>
    );
  }

  if (!current) {
    return (
      <PageShell>
        <PageSkeleton />
      </PageShell>
    );
  }

  return (
    <PageShell>
      <PageHeader
        title={instrument.title}
        description={`Question ${index + 1} of ${total}`}
        breadcrumbs={[{ label: "Assessments", to: "/student/assessments" }, { label: instrument.title }]}
      />
      <Progress value={pct} className="mb-6" />
      <div className="surface-card space-y-6 p-6">
        <p className="text-lg leading-relaxed">{current.text}</p>

        {current.type === "text" ? (
          <Textarea
            value={textResponses[current.id] ?? ""}
            onChange={(e) => setTextResponses((prev) => ({ ...prev, [current.id]: e.target.value }))}
            placeholder="Type your answer…"
            rows={5}
          />
        ) : (
          <div className={cn("grid gap-2", current.type === "emojiScale" ? "grid-cols-2 sm:grid-cols-5" : "grid-cols-1 sm:grid-cols-2")}>
            {current.options.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => selectOption(current.id, opt.value)}
                className={cn(
                  "flex flex-col items-center gap-1 rounded-lg border border-input px-4 py-3 text-sm transition-colors hover:bg-secondary",
                  responses[current.id] === opt.value && "border-primary bg-accent text-accent-foreground",
                )}
                aria-pressed={responses[current.id] === opt.value}
              >
                {opt.emoji && <span className="text-2xl" aria-hidden>{opt.emoji}</span>}
                <span>{opt.label}</span>
              </button>
            ))}
          </div>
        )}

        <div className="flex items-center justify-between pt-2">
          <Button variant="outline" onClick={goBack} disabled={index === 0 || busy}>
            <ArrowLeft className="mr-1.5 size-4" aria-hidden /> Back
          </Button>
          <Button onClick={goNext} disabled={!canAdvance || busy}>
            {index === total - 1 ? (busy ? "Submitting…" : "Submit") : "Next"}
            {index < total - 1 && <ArrowRight className="ml-1.5 size-4" aria-hidden />}
          </Button>
        </div>
      </div>
    </PageShell>
  );
}
