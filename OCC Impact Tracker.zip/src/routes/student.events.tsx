import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { CalendarDays, MapPin, Users } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import { PageSkeleton, ErrorState, EmptyState } from "@/components/kit/States";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { eventService } from "@/services/eventService";
import type { Event } from "@/types";

export const Route = createFileRoute("/student/events")({
  head: () => ({
    meta: [
      { title: "Events — OCC Impact Report Tracker" },
      { name: "description", content: "Upcoming OCC community events grouped by month with RSVP." },
      { property: "og:title", content: "Events — OCC Impact Report Tracker" },
      { property: "og:description", content: "RSVP to upcoming distributions, workshops, and community events." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["student"]}>
      <EventsPage />
    </ProtectedRoute>
  ),
});

function EventsPage() {
  const [events, setEvents] = useState<Event[]>([]);
  const [rsvps, setRsvps] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    setError(false);
    Promise.all([eventService.list({ upcomingOnly: true }), eventService.myRsvps()])
      .then(([e, r]) => {
        setEvents(e);
        setRsvps(r);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const toggleRsvp = async (event: Event) => {
    setBusyId(event.id);
    try {
      if (rsvps.includes(event.id)) {
        await eventService.cancelRsvp(event.id);
        toast.success(`Cancelled RSVP for ${event.title}`);
      } else {
        if (event.rsvpCount >= event.capacity) {
          toast.error("This event is at capacity");
          return;
        }
        await eventService.rsvp(event.id);
        toast.success(`RSVP'd to ${event.title}`);
      }
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't update RSVP");
    } finally {
      setBusyId(null);
    }
  };

  const grouped = useMemo(() => {
    const map = new Map<string, Event[]>();
    for (const e of events) {
      const key = new Date(e.startsAt).toLocaleDateString("en-US", { month: "long", year: "numeric" });
      const list = map.get(key) ?? [];
      list.push(e);
      map.set(key, list);
    }
    return [...map.entries()];
  }, [events]);

  if (loading) {
    return (
      <PageShell>
        <PageSkeleton />
      </PageShell>
    );
  }

  if (error) {
    return (
      <PageShell>
        <ErrorState onRetry={load} />
      </PageShell>
    );
  }

  return (
    <PageShell>
      <PageHeader title="Events" description="Upcoming community events you can RSVP to." />

      {events.length === 0 ? (
        <EmptyState title="No upcoming events" description="Check back soon for new community events." />
      ) : (
        <div className="space-y-8">
          {grouped.map(([month, monthEvents]) => (
            <div key={month}>
              <h2 className="mb-3 text-xl">{month}</h2>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {monthEvents.map((event) => {
                  const registered = rsvps.includes(event.id);
                  const full = event.rsvpCount >= event.capacity;
                  const pct = Math.min(100, Math.round((event.rsvpCount / event.capacity) * 100));
                  return (
                    <div key={event.id} className="surface-card space-y-2 p-5">
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-lg">{event.title}</p>
                        <Badge variant="outline" className="capitalize">{event.type}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{event.description}</p>
                      <p className="flex items-center gap-1 text-xs text-muted-foreground">
                        <CalendarDays className="size-3.5" aria-hidden />
                        {new Date(event.startsAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                      </p>
                      <p className="flex items-center gap-1 text-xs text-muted-foreground">
                        <MapPin className="size-3.5" aria-hidden /> {event.location}
                      </p>
                      <div>
                        <p className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Users className="size-3.5" aria-hidden /> {event.rsvpCount}/{event.capacity} RSVP'd
                        </p>
                        <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-secondary">
                          <div className={cn("h-full rounded-full", full ? "bg-terracotta" : "bg-primary")} style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant={registered ? "outline" : "default"}
                        disabled={(!registered && full) || busyId === event.id}
                        onClick={() => toggleRsvp(event)}
                      >
                        {registered ? "Cancel RSVP" : full ? "Full" : "RSVP"}
                      </Button>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </PageShell>
  );
}
