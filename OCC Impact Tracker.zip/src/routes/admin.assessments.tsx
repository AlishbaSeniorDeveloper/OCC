import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { DataTable, type Column } from "@/components/kit/DataTable";
import { ErrorState, PageSkeleton, TableSkeleton } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/context/AuthContext";
import { assessmentService } from "@/services/assessmentService";
import { userService } from "@/services/userService";
import { bandToneClass } from "@/lib/scoring";
import type { Assessment, AssessmentAttempt, ProgramSlug, User } from "@/types";

export const Route = createFileRoute("/admin/assessments")({
  head: () => ({
    meta: [
      { title: "Assessments — OCC Impact Report Tracker" },
      { name: "description", content: "Manage the assessment instrument library and review flagged attempts." },
      { property: "og:title", content: "Assessments — OCC Impact Report Tracker" },
      { property: "og:description", content: "Manage the assessment instrument library and review flagged attempts." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["admin"]}>
      <AssessmentsPage />
    </ProtectedRoute>
  ),
});

const PROGRAM_LABEL: Record<ProgramSlug, string> = {
  "fresh-table": "The Fresh Table",
  "sprout-society": "Sprout Society",
  becoming: "Becoming",
};

function AssessmentsPage() {
  const { user: me } = useAuth();
  const [instruments, setInstruments] = useState<Assessment[]>([]);
  const [attempts, setAttempts] = useState<AssessmentAttempt[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [preview, setPreview] = useState<Assessment | null>(null);
  const [programFilter, setProgramFilter] = useState<ProgramSlug | "all">("all");
  const [flagFilter, setFlagFilter] = useState<"all" | "flagged" | "reviewed">("all");
  const [reviewing, setReviewing] = useState<AssessmentAttempt | null>(null);
  const [notes, setNotes] = useState("");

  const load = () => {
    setLoading(true);
    setError(false);
    Promise.all([assessmentService.listInstruments(), assessmentService.allAttempts(), userService.list()])
      .then(([i, a, u]) => {
        setInstruments(i);
        setAttempts(a);
        setUsers(u);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };
  useEffect(load, []);

  const userName = (id: string) => users.find((u) => u.id === id)?.fullName ?? id;

  const instrumentColumns: Column<Assessment>[] = [
    { key: "title", header: "Instrument", sortValue: (a) => a.title },
    { key: "programId", header: "Program", sortValue: (a) => a.programId, render: (a) => PROGRAM_LABEL[a.programId] },
    { key: "audience", header: "Audience", sortValue: (a) => a.audience },
    { key: "questions", header: "Questions", sortValue: (a) => a.questions.length },
    {
      key: "isActive",
      header: "Active",
      sortValue: (a) => (a.isActive ? 1 : 0),
      render: (a) => (
        <Switch
          checked={a.isActive}
          onCheckedChange={async (v) => {
            const updated = await assessmentService.updateInstrument(a.id, { isActive: v });
            setInstruments((prev) => prev.map((x) => (x.id === updated.id ? updated : x)));
            toast.success(v ? `${a.title} activated` : `${a.title} deactivated`);
          }}
        />
      ),
    },
    {
      key: "preview",
      header: "Preview",
      render: (a) => (
        <Button size="sm" variant="outline" onClick={() => setPreview(a)}>
          View questions
        </Button>
      ),
    },
  ];

  const filteredAttempts = useMemo(() => {
    let rows = attempts;
    if (programFilter !== "all") {
      const ids = new Set(users.filter((u) => u.programs.includes(programFilter)).map((u) => u.id));
      rows = rows.filter((a) => ids.has(a.userId));
    }
    if (flagFilter === "flagged") rows = rows.filter((a) => a.flagged && !a.reviewedAt);
    if (flagFilter === "reviewed") rows = rows.filter((a) => a.flagged && a.reviewedAt);
    return rows;
  }, [attempts, programFilter, flagFilter, users]);

  const attemptColumns: Column<AssessmentAttempt>[] = [
    { key: "userId", header: "Participant", sortValue: (a) => userName(a.userId) },
    { key: "assessmentId", header: "Assessment", sortValue: (a) => a.assessmentId },
    { key: "status", header: "Status", sortValue: (a) => a.status },
    {
      key: "band",
      header: "Band",
      sortValue: (a) => a.band,
      render: (a) => (a.band ? <Badge variant="outline">{a.band}</Badge> : "—"),
    },
    { key: "normalizedScore", header: "Score", sortValue: (a) => a.normalizedScore },
    {
      key: "flagged",
      header: "Flag",
      sortValue: (a) => (a.flagged ? 1 : 0),
      render: (a) =>
        a.flagged ? (
          <Badge variant="outline" className={a.reviewedAt ? "border-sage/50" : "border-terracotta/40 text-terracotta"}>
            {a.reviewedAt ? "Reviewed" : "Needs review"}
          </Badge>
        ) : (
          "—"
        ),
    },
    {
      key: "action",
      header: "Action",
      render: (a) =>
        a.flagged && !a.reviewedAt ? (
          <Button size="sm" variant="outline" onClick={() => { setReviewing(a); setNotes(""); }}>
            Review
          </Button>
        ) : (
          "—"
        ),
    },
  ];

  return (
    <PageShell>
      <PageHeader title="Assessments" description="Manage the instrument library and review flagged attempts across the organization." />

      {loading ? (
        <PageSkeleton />
      ) : error ? (
        <ErrorState onRetry={load} />
      ) : (
        <div className="space-y-10">
          <div>
            <SectionHeading title="Instrument library" description="Activate, deactivate, and preview the questions used in each assessment." />
            <DataTable rows={instruments} columns={instrumentColumns} searchKeys={(a) => a.title} exportName="instrument-library" />
          </div>

          <div>
            <SectionHeading
              title="All attempts"
              description="Every attempt across the organization, with flagged review workflow."
              actions={
                <div className="flex gap-2">
                  <Select value={programFilter} onValueChange={(v) => setProgramFilter(v as ProgramSlug | "all")}>
                    <SelectTrigger className="w-44"><SelectValue placeholder="Program" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All programs</SelectItem>
                      {(["fresh-table", "sprout-society", "becoming"] as ProgramSlug[]).map((p) => (
                        <SelectItem key={p} value={p}>{PROGRAM_LABEL[p]}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={flagFilter} onValueChange={(v) => setFlagFilter(v as typeof flagFilter)}>
                    <SelectTrigger className="w-40"><SelectValue placeholder="Flag" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All attempts</SelectItem>
                      <SelectItem value="flagged">Needs review</SelectItem>
                      <SelectItem value="reviewed">Reviewed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              }
            />
            <DataTable
              rows={filteredAttempts}
              columns={attemptColumns}
              searchKeys={(a) => `${userName(a.userId)} ${a.assessmentId}`}
              exportName="assessment-attempts"
              emptyTitle="No attempts match these filters"
              emptyDescription="Try a different program or flag filter."
            />
          </div>
        </div>
      )}

      {preview && (
        <Dialog open={!!preview} onOpenChange={(v) => !v && setPreview(null)}>
          <DialogContent className="max-h-[80vh] max-w-2xl overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{preview.title}</DialogTitle>
              <DialogDescription>{preview.description}</DialogDescription>
            </DialogHeader>
            <ol className="space-y-3 text-sm">
              {preview.questions.map((q, i) => (
                <li key={q.id} className="rounded-lg border border-border p-3">
                  <p className="mb-1 font-medium">{i + 1}. {q.text}</p>
                  {q.options.length > 0 && (
                    <p className="text-xs text-muted-foreground">
                      Options: {q.options.map((o) => o.label).join(", ")}
                    </p>
                  )}
                </li>
              ))}
            </ol>
          </DialogContent>
        </Dialog>
      )}

      {reviewing && (
        <Dialog open={!!reviewing} onOpenChange={(v) => !v && setReviewing(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Review flagged attempt</DialogTitle>
              <DialogDescription>
                {userName(reviewing.userId)} — {reviewing.assessmentId} — band: {reviewing.band || "n/a"}
              </DialogDescription>
            </DialogHeader>
            <Textarea placeholder="Review notes…" value={notes} onChange={(e) => setNotes(e.target.value)} rows={4} />
            <DialogFooter>
              <Button
                onClick={async () => {
                  const updated = await assessmentService.reviewAttempt(reviewing.id, me?.id ?? "admin", notes);
                  setAttempts((prev) => prev.map((a) => (a.id === updated.id ? updated : a)));
                  setReviewing(null);
                  toast.success("Attempt marked as reviewed");
                }}
              >
                Mark reviewed
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </PageShell>
  );
}
