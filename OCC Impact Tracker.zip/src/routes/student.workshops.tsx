import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { CalendarDays, MapPin, Star, Users } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { PageSkeleton, ErrorState, EmptyState } from "@/components/kit/States";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { workshopService } from "@/services/workshopService";
import type { Workshop, WorkshopEnrollment } from "@/types";

export const Route = createFileRoute("/student/workshops")({
  head: () => ({
    meta: [
      { title: "Workshops — OCC Impact Report Tracker" },
      { name: "description", content: "Register for upcoming workshops and review your workshop history." },
      { property: "og:title", content: "Workshops — OCC Impact Report Tracker" },
      { property: "og:description", content: "Browse, register, and give feedback on OCC workshops." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["student"]}>
      <WorkshopsPage />
    </ProtectedRoute>
  ),
});

function WorkshopsPage() {
  const { user } = useAuth();
  const [workshops, setWorkshops] = useState<Workshop[]>([]);
  const [enrollments, setEnrollments] = useState<WorkshopEnrollment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [feedbackTarget, setFeedbackTarget] = useState<WorkshopEnrollment | null>(null);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = () => {
    if (!user) return;
    setLoading(true);
    setError(false);
    Promise.all([workshopService.list(), workshopService.enrollmentsForUser(user.id)])
      .then(([w, e]) => {
        setWorkshops(w);
        setEnrollments(e);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const enrollmentFor = (workshopId: string) => enrollments.find((e) => e.workshopId === workshopId);

  const register = async (workshop: Workshop) => {
    if (!user) return;
    setBusyId(workshop.id);
    try {
      await workshopService.register(workshop.id, user.id);
      toast.success(`Registered for ${workshop.title}`);
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't register");
    } finally {
      setBusyId(null);
    }
  };

  const cancel = async (enrollment: WorkshopEnrollment, title: string) => {
    setBusyId(enrollment.id);
    try {
      await workshopService.cancel(enrollment.id);
      toast.success(`Cancelled registration for ${title}`);
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't cancel");
    } finally {
      setBusyId(null);
    }
  };

  const submitFeedback = async () => {
    if (!feedbackTarget) return;
    try {
      await workshopService.submitFeedback(feedbackTarget.id, rating, comment);
      toast.success("Thanks for the feedback!");
      setFeedbackTarget(null);
      setComment("");
      setRating(5);
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't submit feedback");
    }
  };

  if (loading) {
    return (
      <PageShell>
        <PageSkeleton />
      </PageShell>
    );
  }

  if (error) {
    return (
      <PageShell>
        <ErrorState onRetry={load} />
      </PageShell>
    );
  }

  const available = workshops.filter((w) => w.status === "upcoming");
  const upcomingRegistered = workshops.filter((w) => {
    const e = enrollmentFor(w.id);
    return w.status === "upcoming" && e?.status === "registered";
  });
  const history = workshops.filter((w) => {
    const e = enrollmentFor(w.id);
    return w.status !== "upcoming" && e;
  });

  return (
    <PageShell>
      <PageHeader title="Workshops" description="Register for upcoming sessions and reflect on past workshops." />

      <div className="mb-8">
        <SectionHeading title="Upcoming, registered" />
        {upcomingRegistered.length === 0 ? (
          <EmptyState title="Nothing registered" description="Register for a workshop below to see it here." />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {upcomingRegistered.map((w) => {
              const enrollment = enrollmentFor(w.id)!;
              return (
                <div key={w.id} className="surface-card space-y-2 p-5">
                  <p className="text-lg">{w.title}</p>
                  <p className="flex items-center gap-1 text-xs text-muted-foreground">
                    <CalendarDays className="size-3.5" aria-hidden />
                    {new Date(w.startsAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                  </p>
                  <p className="flex items-center gap-1 text-xs text-muted-foreground">
                    <MapPin className="size-3.5" aria-hidden /> {w.location}
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={busyId === enrollment.id}
                    onClick={() => cancel(enrollment, w.title)}
                  >
                    Cancel registration
                  </Button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="mb-8">
        <SectionHeading title="Available workshops" description="Open sessions you can register for." />
        {available.length === 0 ? (
          <EmptyState title="No open workshops" description="Check back soon for new sessions." />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {available.map((w) => {
              const enrollment = enrollmentFor(w.id);
              const full = w.enrolledCount >= w.capacity;
              return (
                <div key={w.id} className="surface-card space-y-2 p-5">
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-lg">{w.title}</p>
                    {full && <Badge variant="outline" className="border-terracotta/40 text-terracotta">Full</Badge>}
                  </div>
                  <p className="text-sm text-muted-foreground">{w.description}</p>
                  <p className="flex items-center gap-1 text-xs text-muted-foreground">
                    <CalendarDays className="size-3.5" aria-hidden />
                    {new Date(w.startsAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                  </p>
                  <p className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Users className="size-3.5" aria-hidden /> {w.enrolledCount}/{w.capacity} enrolled
                  </p>
                  {enrollment?.status === "registered" ? (
                    <Badge variant="outline" className="border-primary/40 text-primary">Registered</Badge>
                  ) : (
                    <Button size="sm" disabled={full || busyId === w.id} onClick={() => register(w)}>
                      {full ? "Full" : "Register"}
                    </Button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div>
        <SectionHeading title="History" />
        {history.length === 0 ? (
          <EmptyState title="No history yet" description="Completed workshops will appear here." />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {history.map((w) => {
              const enrollment = enrollmentFor(w.id)!;
              return (
                <div key={w.id} className="surface-card space-y-2 p-5">
                  <p className="text-lg">{w.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(w.startsAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                  </p>
                  <Badge variant="outline" className={cn(enrollment.status === "attended" ? "border-primary/40 text-primary" : "border-terracotta/40 text-terracotta")}>
                    {enrollment.status === "attended" ? "Attended" : "No-show"}
                  </Badge>
                  {enrollment.feedbackRating ? (
                    <p className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Star className="size-3.5 text-gold" aria-hidden /> You rated {enrollment.feedbackRating}/5
                    </p>
                  ) : (
                    enrollment.status === "attended" && (
                      <Dialog
                        open={feedbackTarget?.id === enrollment.id}
                        onOpenChange={(open) => {
                          if (open) {
                            setFeedbackTarget(enrollment);
                            setRating(5);
                            setComment("");
                          } else {
                            setFeedbackTarget(null);
                          }
                        }}
                      >
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm">Leave feedback</Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Feedback: {w.title}</DialogTitle>
                            <DialogDescription>Let us know how the workshop went.</DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div className="flex items-center gap-1">
                              {[1, 2, 3, 4, 5].map((n) => (
                                <button
                                  key={n}
                                  type="button"
                                  onClick={() => setRating(n)}
                                  aria-label={`Rate ${n} stars`}
                                  className="p-1"
                                >
                                  <Star className={cn("size-6", n <= rating ? "fill-gold text-gold" : "text-muted-foreground")} />
                                </button>
                              ))}
                            </div>
                            <Textarea
                              value={comment}
                              onChange={(e) => setComment(e.target.value)}
                              placeholder="Share your thoughts (optional)…"
                              rows={4}
                            />
                          </div>
                          <DialogFooter>
                            <Button onClick={submitFeedback}>Submit feedback</Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    )
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </PageShell>
  );
}
