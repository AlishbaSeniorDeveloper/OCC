import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { ChartCard, CHART_COLORS, axisProps, tooltipStyle } from "@/components/kit/ChartCard";
import { DataTable, type Column } from "@/components/kit/DataTable";
import { ErrorState, PageSkeleton } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { inventoryService, stockHealth } from "@/services/inventoryService";
import type { Distribution, InventoryItem, InventoryTransaction } from "@/types";

export const Route = createFileRoute("/admin/inventory")({
  head: () => ({
    meta: [
      { title: "Inventory — OCC Impact Report Tracker" },
      { name: "description", content: "Org-wide inventory, par levels, transactions, and distributions." },
      { property: "og:title", content: "Inventory — OCC Impact Report Tracker" },
      { property: "og:description", content: "Org-wide inventory, par levels, transactions, and distributions." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["admin"]}>
      <InventoryPage />
    </ProtectedRoute>
  ),
});

function InventoryPage() {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [txns, setTxns] = useState<InventoryTransaction[]>([]);
  const [dists, setDists] = useState<Distribution[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [editing, setEditing] = useState<InventoryItem | null>(null);
  const [txnType, setTxnType] = useState<InventoryTransaction["type"] | "all">("all");

  const load = () => {
    setLoading(true);
    setError(false);
    Promise.all([inventoryService.list(), inventoryService.transactions(), inventoryService.distributions()])
      .then(([i, t, d]) => {
        setItems(i);
        setTxns(t);
        setDists(d);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };
  useEffect(load, []);

  const itemColumns: Column<InventoryItem>[] = [
    { key: "name", header: "Item", sortValue: (i) => i.name },
    { key: "category", header: "Category", sortValue: (i) => i.category },
    { key: "quantityOnHand", header: "On hand", sortValue: (i) => i.quantityOnHand, render: (i) => `${i.quantityOnHand} ${i.unitLabel}` },
    { key: "parLevel", header: "Par level", sortValue: (i) => i.parLevel },
    { key: "reorderPoint", header: "Reorder pt", sortValue: (i) => i.reorderPoint },
    {
      key: "health",
      header: "Health",
      sortValue: (i) => stockHealth(i),
      render: (i) => {
        const h = stockHealth(i);
        return (
          <Badge variant="outline" className={h === "low" ? "border-terracotta/40 text-terracotta" : h === "watch" ? "border-sage/50" : "border-primary/30 bg-accent"}>
            {h}
          </Badge>
        );
      },
    },
    { key: "edit", header: "Par levels", render: (i) => <Button size="sm" variant="outline" onClick={() => setEditing(i)}>Edit</Button> },
  ];

  const filteredTxns = txnType === "all" ? txns : txns.filter((t) => t.type === txnType);
  const txnColumns: Column<InventoryTransaction>[] = [
    { key: "occurredAt", header: "Date", sortValue: (t) => t.occurredAt, render: (t) => new Date(t.occurredAt).toLocaleDateString("en-US") },
    { key: "itemId", header: "Item", sortValue: (t) => items.find((i) => i.id === t.itemId)?.name ?? t.itemId, render: (t) => items.find((i) => i.id === t.itemId)?.name ?? t.itemId },
    { key: "type", header: "Type", sortValue: (t) => t.type, render: (t) => <Badge variant="outline" className="capitalize">{t.type}</Badge> },
    { key: "quantity", header: "Quantity", sortValue: (t) => t.quantity, render: (t) => `${t.quantity} ${t.unit}` },
    { key: "notes", header: "Notes", sortValue: (t) => t.notes, hideOnMobile: true },
  ];

  const distColumns: Column<Distribution>[] = [
    { key: "date", header: "Date", sortValue: (d) => d.date, render: (d) => new Date(d.date).toLocaleDateString("en-US") },
    { key: "zip", header: "Zip", sortValue: (d) => d.zip },
    { key: "householdsServed", header: "Households", sortValue: (d) => d.householdsServed },
    { key: "individualsServed", header: "Individuals", sortValue: (d) => d.individualsServed },
    { key: "poundsDistributed", header: "Pounds", sortValue: (d) => d.poundsDistributed },
  ];

  const totalOnHand = items.reduce((s, i) => s + i.quantityOnHand, 0);
  const lowCount = items.filter((i) => stockHealth(i) === "low").length;
  const totalPoundsDist = dists.reduce((s, d) => s + d.poundsDistributed, 0);

  const poundsByMonth = dists.reduce<Record<string, number>>((acc, d) => {
    const label = new Date(d.date).toLocaleDateString("en-US", { month: "short", year: "2-digit" });
    acc[label] = (acc[label] ?? 0) + d.poundsDistributed;
    return acc;
  }, {});
  const chartData = Object.entries(poundsByMonth).map(([label, pounds]) => ({ label, pounds }));

  return (
    <PageShell>
      <PageHeader title="Inventory" description="Organization-wide stock, transactions, and distributions." />
      {loading ? (
        <PageSkeleton />
      ) : error ? (
        <ErrorState onRetry={load} />
      ) : (
        <div className="space-y-8">
          <StatGrid className="lg:grid-cols-4">
            <StatCard label="Items tracked" value={items.length} />
            <StatCard label="Units on hand" value={totalOnHand.toLocaleString()} />
            <StatCard label="Low stock items" value={lowCount} />
            <StatCard label="Pounds distributed (all time)" value={totalPoundsDist.toLocaleString()} />
          </StatGrid>

          <ChartCard title="Pounds distributed by month" data={chartData.map((c) => ({ Month: c.label, Pounds: c.pounds }))}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="label" {...axisProps} />
                <YAxis {...axisProps} />
                <Tooltip {...tooltipStyle} />
                <Bar dataKey="pounds" fill={CHART_COLORS.hunter} radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          <div>
            <SectionHeading title="Stock" description="Current inventory with editable par levels." />
            <DataTable rows={items} columns={itemColumns} searchKeys={(i) => `${i.name} ${i.category}`} exportName="inventory-stock" />
          </div>

          <div>
            <SectionHeading
              title="Transactions"
              description="Restocks, distributions, adjustments, and spoilage."
              actions={
                <Select value={txnType} onValueChange={(v) => setTxnType(v as typeof txnType)}>
                  <SelectTrigger className="w-40"><SelectValue placeholder="Type" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All types</SelectItem>
                    <SelectItem value="restock">Restock</SelectItem>
                    <SelectItem value="distribution">Distribution</SelectItem>
                    <SelectItem value="adjustment">Adjustment</SelectItem>
                    <SelectItem value="spoilage">Spoilage</SelectItem>
                  </SelectContent>
                </Select>
              }
            />
            <DataTable rows={filteredTxns} columns={txnColumns} searchKeys={(t) => t.notes} exportName="inventory-transactions" />
          </div>

          <div>
            <SectionHeading title="Distributions" description="Every food distribution event on record." />
            <DataTable rows={dists} columns={distColumns} searchKeys={(d) => d.zip} exportName="distributions" />
          </div>
        </div>
      )}

      {editing && (
        <ParLevelDialog
          item={editing}
          onClose={() => setEditing(null)}
          onSaved={(updated) => {
            setItems((prev) => prev.map((i) => (i.id === updated.id ? updated : i)));
            toast.success("Par levels updated");
          }}
        />
      )}
    </PageShell>
  );
}

function ParLevelDialog({ item, onClose, onSaved }: { item: InventoryItem; onClose: () => void; onSaved: (i: InventoryItem) => void }) {
  const [par, setPar] = useState(String(item.parLevel));
  const [reorder, setReorder] = useState(String(item.reorderPoint));
  const [saving, setSaving] = useState(false);
  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit par levels — {item.name}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <Label className="mb-1.5 block">Par level</Label>
            <Input type="number" value={par} onChange={(e) => setPar(e.target.value)} />
          </div>
          <div>
            <Label className="mb-1.5 block">Reorder point</Label>
            <Input type="number" value={reorder} onChange={(e) => setReorder(e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button
            disabled={saving}
            onClick={async () => {
              setSaving(true);
              try {
                const updated = await inventoryService.updateParLevels(item.id, Number(par), Number(reorder));
                onSaved(updated);
                onClose();
              } finally {
                setSaving(false);
              }
            }}
          >
            {saving ? "Saving…" : "Save"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
