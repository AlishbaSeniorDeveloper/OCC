import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import { DataTable, type Column } from "@/components/kit/DataTable";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { ErrorState, PageSkeleton } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/context/AuthContext";
import { userService } from "@/services/userService";
import { taskService, isOverdue } from "@/services/taskService";
import type { ProgramSlug, Task, User } from "@/types";

export const Route = createFileRoute("/admin/tasks")({
  head: () => ({
    meta: [
      { title: "Assign & manage tasks — OCC Impact Report Tracker" },
      { name: "description", content: "Assign tasks to staff and volunteers, track status, and follow up across the organization." },
      { property: "og:title", content: "Assign & manage tasks — OCC Impact Report Tracker" },
      { property: "og:description", content: "Assign tasks to staff and volunteers, track status, and follow up across the organization." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["admin"]}>
      <TasksPage />
    </ProtectedRoute>
  ),
});

const PROGRAMS: ProgramSlug[] = ["fresh-table", "sprout-society", "becoming"];
const PROGRAM_LABEL: Record<ProgramSlug, string> = {
  "fresh-table": "The Fresh Table",
  "sprout-society": "Sprout Society",
  becoming: "Becoming",
};
const PRIORITIES: Task["priority"][] = ["low", "medium", "high"];
const STATUSES: Task["status"][] = ["todo", "in-progress", "blocked", "done"];

function statusBadgeClass(status: Task["status"]) {
  switch (status) {
    case "done":
      return "border-primary/30 bg-accent text-accent-foreground";
    case "blocked":
      return "border-terracotta/40 bg-terracotta/12 text-terracotta";
    case "in-progress":
      return "border-sage/50 bg-secondary text-secondary-foreground";
    default:
      return "border-input";
  }
}

function priorityBadgeClass(priority: Task["priority"]) {
  switch (priority) {
    case "high":
      return "border-terracotta/40 bg-terracotta/12 text-terracotta";
    case "medium":
      return "border-sage/50 bg-secondary text-secondary-foreground";
    default:
      return "border-input";
  }
}

function TasksPage() {
  const { user: me } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const [statusFilter, setStatusFilter] = useState<Task["status"] | "all">("all");
  const [priorityFilter, setPriorityFilter] = useState<Task["priority"] | "all">("all");

  const [createOpen, setCreateOpen] = useState(false);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [selected, setSelected] = useState<Task | null>(null);

  const load = () => {
    setLoading(true);
    setError(false);
    Promise.all([taskService.listAll(), userService.list()])
      .then(([t, u]) => {
        setTasks(t);
        setUsers(u);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const usersById = useMemo(() => new Map(users.map((u) => [u.id, u])), [users]);

  const filteredTasks = useMemo(
    () =>
      tasks.filter(
        (t) => (statusFilter === "all" || t.status === statusFilter) && (priorityFilter === "all" || t.priority === priorityFilter),
      ),
    [tasks, statusFilter, priorityFilter],
  );

  const kpis = useMemo(
    () => ({
      open: tasks.filter((t) => t.status !== "done").length,
      overdue: tasks.filter((t) => isOverdue(t)).length,
      completed: tasks.filter((t) => t.status === "done").length,
      blocked: tasks.filter((t) => t.status === "blocked").length,
    }),
    [tasks],
  );

  const columns: Column<Task>[] = useMemo(
    () => [
      { key: "title", header: "Task", sortValue: (t) => t.title },
      {
        key: "assignedTo",
        header: "Assignee",
        sortValue: (t) => usersById.get(t.assignedTo)?.fullName ?? t.assignedTo,
        render: (t) => usersById.get(t.assignedTo)?.fullName ?? "Unknown",
      },
      {
        key: "priority",
        header: "Priority",
        sortValue: (t) => t.priority,
        render: (t) => (
          <Badge variant="outline" className={`capitalize ${priorityBadgeClass(t.priority)}`}>
            {t.priority}
          </Badge>
        ),
      },
      {
        key: "status",
        header: "Status",
        sortValue: (t) => t.status,
        render: (t) => (
          <Badge variant="outline" className={`capitalize ${statusBadgeClass(t.status)}`}>
            {t.status.replace("-", " ")}
          </Badge>
        ),
      },
      {
        key: "dueDate",
        header: "Due",
        sortValue: (t) => t.dueDate,
        render: (t) => (
          <span className={isOverdue(t) ? "text-terracotta" : ""}>
            {new Date(t.dueDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
            {isOverdue(t) ? " (overdue)" : ""}
          </span>
        ),
        hideOnMobile: true,
      },
      {
        key: "program",
        header: "Program",
        sortValue: (t) => (t.programId ? PROGRAM_LABEL[t.programId] : ""),
        render: (t) => (t.programId ? PROGRAM_LABEL[t.programId] : "—"),
        hideOnMobile: true,
      },
    ],
    [usersById],
  );

  return (
    <PageShell>
      <PageHeader
        title="Tasks"
        description="Assign and track tasks for any staff member, volunteer, or team across the organization."
        actions={
          <>
            <Button variant="outline" onClick={() => setBulkOpen(true)}>
              Bulk assign
            </Button>
            <Button onClick={() => setCreateOpen(true)}>Assign task</Button>
          </>
        }
      />

      {loading ? (
        <PageSkeleton />
      ) : error ? (
        <ErrorState onRetry={load} />
      ) : (
        <div className="space-y-6">
          <StatGrid>
            <StatCard label="Open tasks" value={kpis.open} />
            <StatCard label="Overdue" value={kpis.overdue} />
            <StatCard label="Completed" value={kpis.completed} />
            <StatCard label="Blocked" value={kpis.blocked} />
          </StatGrid>

          <div className="flex flex-wrap items-center gap-2">
            <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}>
              <SelectTrigger className="w-44"><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All statuses</SelectItem>
                {STATUSES.map((s) => (
                  <SelectItem key={s} value={s} className="capitalize">{s.replace("-", " ")}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={priorityFilter} onValueChange={(v) => setPriorityFilter(v as typeof priorityFilter)}>
              <SelectTrigger className="w-40"><SelectValue placeholder="Priority" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All priorities</SelectItem>
                {PRIORITIES.map((p) => (
                  <SelectItem key={p} value={p} className="capitalize">{p}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <DataTable
            rows={filteredTasks}
            columns={columns}
            searchKeys={(t) => `${t.title} ${t.description} ${usersById.get(t.assignedTo)?.fullName ?? ""}`}
            onRowClick={(t) => setSelected(t)}
            exportName="occ-tasks"
            emptyTitle="No tasks match these filters"
            emptyDescription="Assign a task or widen your filters."
          />
        </div>
      )}

      <CreateTaskDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        users={users}
        assignedBy={me?.id ?? "admin"}
        onCreated={(task) => {
          setTasks((prev) => [task, ...prev]);
          toast.success("Task assigned");
        }}
      />

      <BulkAssignDialog
        open={bulkOpen}
        onOpenChange={setBulkOpen}
        users={users}
        assignedBy={me?.id ?? "admin"}
        onAssigned={() => {
          load();
          toast.success("Tasks assigned");
        }}
      />

      {selected && (
        <TaskDetailDialog
          task={selected}
          onOpenChange={(v) => !v && setSelected(null)}
          assignee={usersById.get(selected.assignedTo)}
          currentUserId={me?.id ?? "admin"}
          onUpdated={(t) => {
            setTasks((prev) => prev.map((x) => (x.id === t.id ? t : x)));
            setSelected(t);
          }}
          onDeleted={(id) => {
            setTasks((prev) => prev.filter((x) => x.id !== id));
            setSelected(null);
            toast.success("Task deleted");
          }}
        />
      )}
    </PageShell>
  );
}

function CreateTaskDialog({
  open,
  onOpenChange,
  users,
  assignedBy,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  users: User[];
  assignedBy: string;
  onCreated: (t: Task) => void;
}) {
  const [assigneeId, setAssigneeId] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [program, setProgram] = useState<ProgramSlug | "none">("none");
  const [priority, setPriority] = useState<Task["priority"]>("medium");
  const [dueDate, setDueDate] = useState("");
  const [saving, setSaving] = useState(false);

  const reset = () => {
    setAssigneeId("");
    setTitle("");
    setDescription("");
    setProgram("none");
    setPriority("medium");
    setDueDate("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Assign a task</DialogTitle>
          <DialogDescription>Assign a task to any user in the organization.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <Label className="mb-1.5 block">Assignee</Label>
            <Select value={assigneeId} onValueChange={setAssigneeId}>
              <SelectTrigger><SelectValue placeholder="Choose a user" /></SelectTrigger>
              <SelectContent className="max-h-72">
                {users.map((u) => (
                  <SelectItem key={u.id} value={u.id}>
                    {u.fullName} — {u.role}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="mb-1.5 block">Title</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Follow up on assessment" />
          </div>
          <div>
            <Label className="mb-1.5 block">Description</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="mb-1.5 block">Program</Label>
              <Select value={program} onValueChange={(v) => setProgram(v as typeof program)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {PROGRAMS.map((p) => (
                    <SelectItem key={p} value={p}>{PROGRAM_LABEL[p]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="mb-1.5 block">Priority</Label>
              <Select value={priority} onValueChange={(v) => setPriority(v as Task["priority"])}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PRIORITIES.map((p) => (
                    <SelectItem key={p} value={p} className="capitalize">{p}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label className="mb-1.5 block">Due date</Label>
            <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button
            disabled={!assigneeId || !title || !dueDate || saving}
            onClick={async () => {
              setSaving(true);
              try {
                const task = await taskService.create({
                  title,
                  description,
                  assignedTo: assigneeId,
                  assignedBy,
                  programId: program === "none" ? undefined : program,
                  priority,
                  dueDate: new Date(dueDate).toISOString(),
                  status: "todo",
                });
                onOpenChange(false);
                reset();
                onCreated(task);
              } finally {
                setSaving(false);
              }
            }}
          >
            {saving ? "Assigning…" : "Assign task"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function BulkAssignDialog({
  open,
  onOpenChange,
  users,
  assignedBy,
  onAssigned,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  users: User[];
  assignedBy: string;
  onAssigned: () => void;
}) {
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState<Task["priority"]>("medium");
  const [dueDate, setDueDate] = useState("");
  const [saving, setSaving] = useState(false);

  const toggle = (id: string) => {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const reset = () => {
    setSelectedIds([]);
    setTitle("");
    setDescription("");
    setPriority("medium");
    setDueDate("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] max-w-lg overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Bulk assign a task</DialogTitle>
          <DialogDescription>Assign the same task to multiple users at once.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <Label className="mb-1.5 block">Title</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Complete monthly check-in" />
          </div>
          <div>
            <Label className="mb-1.5 block">Description</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="mb-1.5 block">Priority</Label>
              <Select value={priority} onValueChange={(v) => setPriority(v as Task["priority"])}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PRIORITIES.map((p) => (
                    <SelectItem key={p} value={p} className="capitalize">{p}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="mb-1.5 block">Due date</Label>
              <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
            </div>
          </div>
          <Separator />
          <div>
            <Label className="mb-1.5 block">Assignees ({selectedIds.length} selected)</Label>
            <div className="max-h-56 space-y-1 overflow-y-auto rounded-lg border border-border p-2">
              {users.map((u) => (
                <label key={u.id} className="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-secondary/50">
                  <Checkbox checked={selectedIds.includes(u.id)} onCheckedChange={() => toggle(u.id)} />
                  {u.fullName} <span className="text-xs text-muted-foreground">({u.role})</span>
                </label>
              ))}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button
            disabled={!title || !dueDate || selectedIds.length === 0 || saving}
            onClick={async () => {
              setSaving(true);
              try {
                await taskService.bulkCreate(
                  { title, description, assignedBy, priority, dueDate: new Date(dueDate).toISOString(), status: "todo" },
                  selectedIds,
                );
                onOpenChange(false);
                reset();
                onAssigned();
              } finally {
                setSaving(false);
              }
            }}
          >
            {saving ? "Assigning…" : `Assign to ${selectedIds.length || ""} user${selectedIds.length === 1 ? "" : "s"}`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function TaskDetailDialog({
  task,
  onOpenChange,
  assignee,
  currentUserId,
  onUpdated,
  onDeleted,
}: {
  task: Task;
  onOpenChange: (v: boolean) => void;
  assignee?: User;
  currentUserId: string;
  onUpdated: (t: Task) => void;
  onDeleted: (id: string) => void;
}) {
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);

  return (
    <Dialog open onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] max-w-xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{task.title}</DialogTitle>
          <DialogDescription>Assigned to {assignee?.fullName ?? "Unknown"}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 text-sm">
          <p className="text-muted-foreground">{task.description || "No description provided."}</p>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="stat-label">Priority</p>
              <Badge variant="outline" className={`mt-1 capitalize ${priorityBadgeClass(task.priority)}`}>{task.priority}</Badge>
            </div>
            <div>
              <p className="stat-label">Due date</p>
              <p className={isOverdue(task) ? "text-terracotta" : ""}>
                {new Date(task.dueDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                {isOverdue(task) ? " (overdue)" : ""}
              </p>
            </div>
          </div>

          <div>
            <Label className="mb-1.5 block">Status</Label>
            <Select
              value={task.status}
              onValueChange={async (v) => {
                setBusy(true);
                try {
                  const updated = await taskService.updateStatus(task.id, v as Task["status"]);
                  onUpdated(updated);
                  toast.success("Status updated");
                } finally {
                  setBusy(false);
                }
              }}
              disabled={busy}
            >
              <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
              <SelectContent>
                {STATUSES.map((s) => (
                  <SelectItem key={s} value={s} className="capitalize">{s.replace("-", " ")}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Separator />

          <div>
            <p className="stat-label mb-2">Comments</p>
            <div className="mb-3 max-h-48 space-y-2 overflow-y-auto">
              {task.comments.length === 0 && <p className="text-xs text-muted-foreground">No comments yet.</p>}
              {task.comments.map((c) => (
                <div key={c.id} className="rounded-lg border border-border bg-secondary/30 p-2.5">
                  <p>{c.body}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{new Date(c.createdAt).toLocaleString("en-US")}</p>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <Input value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Add a comment…" />
              <Button
                variant="outline"
                disabled={!comment.trim() || busy}
                onClick={async () => {
                  setBusy(true);
                  try {
                    const updated = await taskService.addComment(task.id, currentUserId, comment.trim());
                    onUpdated(updated);
                    setComment("");
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                Post
              </Button>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="destructive"
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              try {
                await taskService.remove(task.id);
                onDeleted(task.id);
              } finally {
                setBusy(false);
              }
            }}
          >
            Delete task
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
