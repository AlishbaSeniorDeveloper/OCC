import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CalendarClock, CalendarDays, GraduationCap, Star, TrendingUp, Users } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { ChartCard, CHART_COLORS, axisProps, tooltipStyle } from "@/components/kit/ChartCard";
import { PageSkeleton, EmptyState, ErrorState } from "@/components/kit/States";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/context/AuthContext";
import { workshopService } from "@/services/workshopService";
import { userService } from "@/services/userService";
import { eventService } from "@/services/eventService";
import type { Event, User, Workshop, WorkshopEnrollment } from "@/types";
import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from "recharts";

export const Route = createFileRoute("/parent/")({
  head: () => ({
    meta: [
      { title: "Parent dashboard — OCC Impact Report Tracker" },
      { name: "description", content: "Track your mental health workshops, attendance, feedback, and your child's progress in one place." },
      { property: "og:title", content: "Parent dashboard — OCC Impact Report Tracker" },
      { property: "og:description", content: "Workshops, attendance, and family progress for OCC parents and adults." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["parent"]}>
      <Dashboard />
    </ProtectedRoute>
  ),
});

interface Bundle {
  workshops: Workshop[];
  enrollments: WorkshopEnrollment[];
  children: User[];
  events: Event[];
}

function Dashboard() {
  const { user } = useAuth();
  const [data, setData] = useState<Bundle | null>(null);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = () => {
    if (!user) return;
    setLoading(true);
    setError(false);
    Promise.all([
      workshopService.list({ audience: "adult" }),
      workshopService.enrollmentsForUser(user.id),
      userService.childrenOf(user.id),
      eventService.list({ upcomingOnly: true }),
    ])
      .then(([workshops, enrollments, children, events]) => setData({ workshops, enrollments, children, events }))
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(load, [user]);

  if (loading || !data) {
    return (
      <PageShell>
        <PageSkeleton />
      </PageShell>
    );
  }
  if (error) {
    return (
      <PageShell>
        <ErrorState onRetry={load} />
      </PageShell>
    );
  }

  const { workshops, enrollments, children, events } = data;
  const workshopById = new Map(workshops.map((w) => [w.id, w]));

  const attended = enrollments.filter((e) => e.status === "attended");
  const registered = enrollments.filter((e) => e.status === "registered");
  const upcomingRegistered = registered.filter((e) => {
    const w = workshopById.get(e.workshopId);
    return w && new Date(w.startsAt).getTime() >= Date.now();
  });
  const pastCount = attended.length + enrollments.filter((e) => e.status === "no-show").length;
  const attendanceRate = pastCount === 0 ? 0 : Math.round((attended.length / pastCount) * 100);
  const rated = enrollments.filter((e) => typeof e.feedbackRating === "number");
  const avgFeedback = rated.length === 0 ? 0 : rated.reduce((sum, e) => sum + (e.feedbackRating ?? 0), 0) / rated.length;

  const nextEnrollment = upcomingRegistered
    .map((e) => ({ e, w: workshopById.get(e.workshopId) }))
    .filter((x): x is { e: WorkshopEnrollment; w: Workshop } => !!x.w)
    .sort((a, b) => a.w.startsAt.localeCompare(b.w.startsAt))[0];

  const monthly = new Map<string, { attended: number; total: number }>();
  for (const e of enrollments) {
    const w = workshopById.get(e.workshopId);
    if (!w || e.status === "registered") continue;
    const d = new Date(w.startsAt);
    const key = d.toLocaleDateString("en-US", { month: "short", year: "2-digit" });
    const entry = monthly.get(key) ?? { attended: 0, total: 0 };
    entry.total += 1;
    if (e.status === "attended") entry.attended += 1;
    monthly.set(key, entry);
  }
  const chartData = [...monthly.entries()].map(([month, v]) => ({
    month,
    rate: v.total === 0 ? 0 : Math.round((v.attended / v.total) * 100),
  }));

  const upcomingEvents = events.slice(0, 4);

  return (
    <PageShell>
      <PageHeader
        title={`Welcome, ${user?.fullName?.split(" ")[0] ?? "friend"}`}
        description="Your mental health workshops, attendance, and family progress at a glance."
        actions={
          <Button asChild>
            <Link to="/parent/workshops">Browse workshops</Link>
          </Button>
        }
      />

      <StatGrid>
        <StatCard label="Workshops attended" value={attended.length} icon={GraduationCap} hint="Lifetime total" />
        <StatCard label="Upcoming registered" value={upcomingRegistered.length} icon={CalendarClock} hint="Confirmed seats" />
        <StatCard label="Attendance rate" value={`${attendanceRate}%`} icon={TrendingUp} hint="Of completed workshops" />
        <StatCard
          label="Avg workshop feedback"
          value={rated.length ? avgFeedback.toFixed(1) : "—"}
          icon={Star}
          hint={rated.length ? `Out of 5, ${rated.length} rated` : "No ratings yet"}
        />
      </StatGrid>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <ChartCard
          title="Attendance rate over time"
          description="Share of workshops attended by month"
          className="lg:col-span-2"
          data={chartData.map((c) => ({ Month: c.month, "Attendance rate": `${c.rate}%` }))}
        >
          {chartData.length === 0 ? (
            <EmptyState title="No attendance yet" description="Register and attend a workshop to see your trend here." />
          ) : (
            <AreaChart data={chartData} margin={{ left: -20, right: 10, top: 10 }}>
              <defs>
                <linearGradient id="parentRate" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={CHART_COLORS.hunter} stopOpacity={0.35} />
                  <stop offset="95%" stopColor={CHART_COLORS.hunter} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="month" {...axisProps} />
              <YAxis {...axisProps} domain={[0, 100]} />
              <Area type="monotone" dataKey="rate" name="Attendance %" stroke={CHART_COLORS.hunter} fill="url(#parentRate)" strokeWidth={2} {...tooltipStyle} />
            </AreaChart>
          )}
        </ChartCard>

        <div className="surface-card flex flex-col gap-3 p-5">
          <h3 className="text-lg">Next workshop</h3>
          {nextEnrollment ? (
            <div className="space-y-2">
              <p className="text-base font-medium text-foreground">{nextEnrollment.w.title}</p>
              <p className="text-sm text-muted-foreground">
                {new Date(nextEnrollment.w.startsAt).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" })}
              </p>
              <p className="text-sm text-muted-foreground">{nextEnrollment.w.location}</p>
              <Badge variant="secondary">Facilitated by {nextEnrollment.w.facilitator}</Badge>
              <div className="pt-2">
                <Button asChild size="sm" variant="outline">
                  <Link to="/parent/workshops">View details</Link>
                </Button>
              </div>
            </div>
          ) : (
            <EmptyState
              title="Nothing scheduled"
              description="Register for a workshop to see it here."
              action={
                <Button asChild size="sm">
                  <Link to="/parent/workshops">Browse workshops</Link>
                </Button>
              }
            />
          )}
        </div>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <div className="surface-card p-5">
          <SectionHeading title="Child snapshot" description="Programs and progress for your linked children" />
          {children.length === 0 ? (
            <EmptyState title="No children linked yet" description="Once a child is linked to your account, their snapshot will appear here." />
          ) : (
            <div className="space-y-3">
              {children.slice(0, 3).map((child) => (
                <div key={child.id} className="flex items-center justify-between rounded-lg border border-border p-3">
                  <div>
                    <p className="text-sm font-medium text-foreground">{child.fullName}</p>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {child.programs.map((p) => (
                        <Badge key={p} variant="secondary" className="text-xs">
                          {p}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <Users className="size-5 text-sage" aria-hidden />
                </div>
              ))}
              <Button asChild variant="outline" size="sm" className="w-full">
                <Link to="/parent/my-child">View full details</Link>
              </Button>
            </div>
          )}
        </div>

        <div className="surface-card p-5">
          <SectionHeading title="Upcoming community events" description="RSVP to stay involved" />
          {upcomingEvents.length === 0 ? (
            <EmptyState title="No events scheduled" description="Check back soon for upcoming community events." />
          ) : (
            <div className="space-y-3">
              {upcomingEvents.map((event) => (
                <div key={event.id} className="flex items-start gap-3 rounded-lg border border-border p-3">
                  <CalendarDays className="mt-0.5 size-4 text-sage" aria-hidden />
                  <div>
                    <p className="text-sm font-medium text-foreground">{event.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(event.startsAt).toLocaleDateString("en-US", { dateStyle: "medium" })} · {event.location}
                    </p>
                  </div>
                </div>
              ))}
              <Button asChild variant="outline" size="sm" className="w-full">
                <Link to="/parent/events">See all events</Link>
              </Button>
            </div>
          )}
        </div>
      </div>
    </PageShell>
  );
}
