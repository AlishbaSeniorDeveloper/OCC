import { createFileRoute } from "@tanstack/react-router";
import { CalendarPlus, CheckCircle2, Users } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { PageSkeleton, EmptyState } from "@/components/kit/States";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/context/AuthContext";
import { programs } from "@/data/programs";
import { userService } from "@/services/userService";
import { workshopService } from "@/services/workshopService";
import type { Audience, ProgramSlug, User, Workshop, WorkshopEnrollment } from "@/types";

export const Route = createFileRoute("/staff/workshops")({
  head: () => ({
    meta: [
      { title: "Workshops — OCC Impact Report Tracker" },
      { name: "description", content: "Plan workshops and manage attendance rosters for OCC programs." },
      { property: "og:title", content: "Workshops — OCC Impact Report Tracker" },
      { property: "og:description", content: "Create workshops, manage rosters, and mark attendance." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["staff"]}>
      <WorkshopsPage />
    </ProtectedRoute>
  ),
});

function todayIso() {
  return new Date().toISOString().slice(0, 16);
}

function WorkshopsPage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [workshops, setWorkshops] = useState<Workshop[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [enrollments, setEnrollments] = useState<WorkshopEnrollment[]>([]);
  const [tab, setTab] = useState<"upcoming" | "past">("upcoming");
  const [rosterWorkshop, setRosterWorkshop] = useState<Workshop | null>(null);
  const [selectedAttendees, setSelectedAttendees] = useState<Set<string>>(new Set());

  const [createOpen, setCreateOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [programId, setProgramId] = useState<ProgramSlug>("fresh-table");
  const [audience, setAudience] = useState<Audience>("adult");
  const [description, setDescription] = useState("");
  const [facilitator, setFacilitator] = useState("");
  const [startsAt, setStartsAt] = useState(todayIso());
  const [duration, setDuration] = useState("60");
  const [location, setLocation] = useState("");
  const [capacity, setCapacity] = useState("20");
  const [saving, setSaving] = useState(false);

  const load = async () => {
    const [w, u, e] = await Promise.all([workshopService.list(), userService.list(), workshopService.allEnrollments()]);
    setWorkshops(w);
    setUsers(u);
    setEnrollments(e);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const myWorkshops = useMemo(() => {
    if (!user) return [];
    const programSet = new Set(user.programs);
    return workshops.filter((w) => programSet.has(w.programId));
  }, [workshops, user]);

  const now = Date.now();
  const upcoming = myWorkshops.filter((w) => new Date(w.startsAt).getTime() >= now && w.status !== "cancelled");
  const past = myWorkshops.filter((w) => new Date(w.startsAt).getTime() < now || w.status === "completed");

  if (loading || !user) {
    return (
      <PageShell>
        <PageHeader title="Workshops" description="Loading workshops…" />
        <PageSkeleton />
      </PageShell>
    );
  }

  const roster = rosterWorkshop ? enrollments.filter((e) => e.workshopId === rosterWorkshop.id) : [];
  const userName = (id: string) => users.find((u) => u.id === id)?.fullName ?? "Unknown participant";

  const openRoster = (w: Workshop) => {
    setRosterWorkshop(w);
    setSelectedAttendees(new Set());
  };

  const toggleAttendee = (id: string) => {
    setSelectedAttendees((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const bulkMark = async () => {
    if (!rosterWorkshop || selectedAttendees.size === 0) return;
    try {
      const n = await workshopService.bulkMarkAttendance(rosterWorkshop.id, Array.from(selectedAttendees));
      toast.success(`Marked ${n} attendee${n === 1 ? "" : "s"} present`);
      setSelectedAttendees(new Set());
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not mark attendance");
    }
  };

  const markOne = async (enrollmentId: string, status: WorkshopEnrollment["status"]) => {
    try {
      await workshopService.markAttendance(enrollmentId, status);
      toast.success("Attendance updated");
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not update attendance");
    }
  };

  const submitCreate = async () => {
    if (!title || !facilitator || !location) {
      toast.error("Fill in title, facilitator, and location.");
      return;
    }
    setSaving(true);
    try {
      await workshopService.create({
        title,
        programId,
        audience,
        description,
        facilitator,
        startsAt: new Date(startsAt).toISOString(),
        durationMinutes: Number(duration) || 60,
        location,
        capacity: Number(capacity) || 20,
        tags: [],
        status: "upcoming",
      });
      toast.success("Workshop created");
      setCreateOpen(false);
      setTitle("");
      setDescription("");
      setFacilitator("");
      setLocation("");
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not create workshop");
    } finally {
      setSaving(false);
    }
  };

  const WorkshopCard = ({ w }: { w: Workshop }) => (
    <div className="surface-card space-y-3 p-5">
      <div className="flex items-start justify-between gap-2">
        <div>
          <h3 className="text-lg">{w.title}</h3>
          <p className="text-xs text-muted-foreground">
            {programs.find((p) => p.slug === w.programId)?.name} · {w.audience}
          </p>
        </div>
        <Badge variant="outline">{w.status}</Badge>
      </div>
      <p className="text-sm text-muted-foreground">{w.description}</p>
      <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
        <span>{new Date(w.startsAt).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" })}</span>
        <span>{w.durationMinutes} min</span>
        <span>{w.location}</span>
        <span>
          {w.enrolledCount}/{w.capacity} enrolled
        </span>
      </div>
      <Button size="sm" variant="outline" onClick={() => openRoster(w)}>
        <Users className="mr-1.5 size-4" aria-hidden /> View roster
      </Button>
    </div>
  );

  return (
    <PageShell>
      <PageHeader
        title="Workshops"
        description="Plan sessions and manage attendance for your programs."
        actions={
          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button>
                <CalendarPlus className="mr-1.5 size-4" aria-hidden /> Create workshop
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-xl">
              <DialogHeader>
                <DialogTitle>Create a workshop</DialogTitle>
              </DialogHeader>
              <div className="max-h-[60vh] space-y-3 overflow-y-auto pr-1">
                <div>
                  <Label className="text-xs">Title</Label>
                  <Input value={title} onChange={(e) => setTitle(e.target.value)} />
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <Label className="text-xs">Program</Label>
                    <Select value={programId} onValueChange={(v) => setProgramId(v as ProgramSlug)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {programs.map((p) => (
                          <SelectItem key={p.slug} value={p.slug}>
                            {p.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs">Audience</Label>
                    <Select value={audience} onValueChange={(v) => setAudience(v as Audience)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="child">Child</SelectItem>
                        <SelectItem value="teen">Teen</SelectItem>
                        <SelectItem value="adult">Adult</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label className="text-xs">Description</Label>
                  <Textarea value={description} onChange={(e) => setDescription(e.target.value)} />
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <Label className="text-xs">Facilitator</Label>
                    <Input value={facilitator} onChange={(e) => setFacilitator(e.target.value)} />
                  </div>
                  <div>
                    <Label className="text-xs">Location</Label>
                    <Input value={location} onChange={(e) => setLocation(e.target.value)} />
                  </div>
                  <div>
                    <Label className="text-xs">Starts at</Label>
                    <Input type="datetime-local" value={startsAt} onChange={(e) => setStartsAt(e.target.value)} />
                  </div>
                  <div>
                    <Label className="text-xs">Duration (min)</Label>
                    <Input type="number" value={duration} onChange={(e) => setDuration(e.target.value)} />
                  </div>
                  <div>
                    <Label className="text-xs">Capacity</Label>
                    <Input type="number" value={capacity} onChange={(e) => setCapacity(e.target.value)} />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setCreateOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={submitCreate} disabled={saving}>
                  {saving ? "Creating…" : "Create workshop"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <StatGrid>
        <StatCard label="Upcoming workshops" value={upcoming.length} icon={CalendarPlus} />
        <StatCard label="Past workshops" value={past.length} icon={CheckCircle2} />
        <StatCard
          label="Total enrolled"
          value={myWorkshops.reduce((s, w) => s + w.enrolledCount, 0)}
          icon={Users}
        />
        <StatCard
          label="Avg. capacity used"
          value={
            myWorkshops.length
              ? `${Math.round(
                  (myWorkshops.reduce((s, w) => s + w.enrolledCount / Math.max(1, w.capacity), 0) / myWorkshops.length) * 100,
                )}%`
              : "—"
          }
          icon={Users}
        />
      </StatGrid>

      <div className="mt-8">
        <Tabs value={tab} onValueChange={(v) => setTab(v as "upcoming" | "past")}>
          <TabsList>
            <TabsTrigger value="upcoming">Upcoming ({upcoming.length})</TabsTrigger>
            <TabsTrigger value="past">Past ({past.length})</TabsTrigger>
          </TabsList>
          <TabsContent value="upcoming" className="mt-4">
            {upcoming.length === 0 ? (
              <EmptyState title="No upcoming workshops" description="Create a workshop to get started." />
            ) : (
              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                {upcoming.map((w) => (
                  <WorkshopCard key={w.id} w={w} />
                ))}
              </div>
            )}
          </TabsContent>
          <TabsContent value="past" className="mt-4">
            {past.length === 0 ? (
              <EmptyState title="No past workshops" description="Completed workshops will appear here." />
            ) : (
              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                {past.map((w) => (
                  <WorkshopCard key={w.id} w={w} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={!!rosterWorkshop} onOpenChange={(open) => !open && setRosterWorkshop(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{rosterWorkshop?.title} roster</DialogTitle>
          </DialogHeader>
          {roster.length === 0 ? (
            <EmptyState title="No enrollments yet" description="No one has registered for this workshop yet." />
          ) : (
            <div className="max-h-[50vh] space-y-2 overflow-y-auto">
              {roster.map((e) => (
                <div key={e.id} className="flex items-center justify-between gap-3 rounded-lg border border-border p-3">
                  <div className="flex items-center gap-3">
                    <Checkbox
                      checked={selectedAttendees.has(e.userId)}
                      onCheckedChange={() => toggleAttendee(e.userId)}
                      aria-label={`Select ${userName(e.userId)}`}
                    />
                    <div>
                      <p className="text-sm font-medium text-foreground">{userName(e.userId)}</p>
                      <Badge variant="outline" className="mt-1">
                        {e.status}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex gap-1.5">
                    <Button size="sm" variant="outline" onClick={() => markOne(e.id, "attended")}>
                      Attended
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => markOne(e.id, "no-show")}>
                      No-show
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setRosterWorkshop(null)}>
              Close
            </Button>
            <Button onClick={bulkMark} disabled={selectedAttendees.size === 0}>
              Mark selected present
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageShell>
  );
}
