import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Clock3, Plus } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import { StatCard, StatGrid } from "@/components/kit/StatCard";
import { ChartCard, CHART_COLORS, axisProps, tooltipStyle } from "@/components/kit/ChartCard";
import { DataTable, type Column } from "@/components/kit/DataTable";
import { PageSkeleton } from "@/components/kit/States";
import { useAuth } from "@/context/AuthContext";
import { eventService } from "@/services/eventService";
import type { Event, VolunteerHourLog } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export const Route = createFileRoute("/volunteer/hours")({
  head: () => ({
    meta: [
      { title: "My hours — OCC Impact Report Tracker" },
      { name: "description", content: "Track and log the volunteer hours you've contributed to OCC programs." },
      { property: "og:title", content: "My hours — OCC Impact Report Tracker" },
      { property: "og:description", content: "See monthly trends and log new volunteer hours." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["volunteer"]}>
      <HoursPage />
    </ProtectedRoute>
  ),
});

function monthKey(date: string) {
  const d = new Date(date);
  return d.toLocaleDateString("en-US", { month: "short", year: "2-digit" });
}

function HoursPage() {
  const { user } = useAuth();
  const [logs, setLogs] = useState<VolunteerHourLog[] | null>(null);
  const [events, setEvents] = useState<Event[]>([]);
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [hours, setHours] = useState("2");
  const [activity, setActivity] = useState("");
  const [eventId, setEventId] = useState<string>("none");

  const load = async () => {
    if (!user) return;
    const [rows, evs] = await Promise.all([eventService.hoursForUser(user.id), eventService.list()]);
    setLogs(rows);
    setEvents(evs);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const totalHours = useMemo(() => (logs ?? []).reduce((sum, l) => sum + l.hours, 0), [logs]);
  const thisMonthHours = useMemo(() => {
    const now = new Date();
    return (logs ?? [])
      .filter((l) => {
        const d = new Date(l.date);
        return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
      })
      .reduce((sum, l) => sum + l.hours, 0);
  }, [logs]);

  const chartData = useMemo(() => {
    const map = new Map<string, number>();
    for (const l of logs ?? []) {
      const key = monthKey(l.date);
      map.set(key, (map.get(key) ?? 0) + l.hours);
    }
    return [...map.entries()].map(([month, value]) => ({ month, hours: Number(value.toFixed(1)) }));
  }, [logs]);

  const columns: Column<VolunteerHourLog>[] = [
    {
      key: "date",
      header: "Date",
      sortValue: (r) => r.date,
      render: (r) => new Date(r.date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
    },
    { key: "activity", header: "Activity", sortValue: (r) => r.activity },
    {
      key: "event",
      header: "Event",
      sortValue: (r) => events.find((e) => e.id === r.eventId)?.title ?? "—",
    },
    { key: "hours", header: "Hours", sortValue: (r) => r.hours },
  ];

  const submit = async () => {
    if (!user) return;
    const h = Number(hours);
    if (!h || h <= 0 || !activity.trim()) {
      toast.error("Enter hours and an activity");
      return;
    }
    try {
      await eventService.logHours({
        userId: user.id,
        eventId: eventId === "none" ? undefined : eventId,
        hours: h,
        activity: activity.trim(),
        date,
      });
      toast.success("Hours logged");
      setOpen(false);
      setActivity("");
      setHours("2");
      setEventId("none");
      load();
    } catch {
      toast.error("Couldn't log hours");
    }
  };

  if (logs === null) {
    return (
      <PageShell>
        <PageSkeleton />
      </PageShell>
    );
  }

  return (
    <PageShell>
      <PageHeader
        title="My hours"
        description="See your contributed hours over time and log new sessions."
        actions={
          <Button onClick={() => setOpen(true)}>
            <Plus className="mr-1.5 size-4" aria-hidden /> Log hours
          </Button>
        }
      />

      <StatGrid className="mb-6">
        <StatCard label="Total hours logged" value={totalHours.toFixed(1)} icon={Clock3} />
        <StatCard label="Hours this month" value={thisMonthHours.toFixed(1)} icon={Clock3} />
        <StatCard label="Sessions logged" value={logs.length} />
        <StatCard label="Avg hours / session" value={logs.length ? (totalHours / logs.length).toFixed(1) : "0"} />
      </StatGrid>

      <ChartCard
        title="Hours by month"
        description="Your total logged hours across recent months."
        className="mb-6"
        data={chartData}
        columns={[{ key: "month", label: "Month" }, { key: "hours", label: "Hours" }]}
      >
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
            <XAxis dataKey="month" {...axisProps} />
            <YAxis {...axisProps} allowDecimals={false} />
            <Tooltip {...tooltipStyle} />
            <Bar dataKey="hours" fill={CHART_COLORS.hunter} radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <DataTable
        rows={logs}
        columns={columns}
        searchKeys={(r) => r.activity}
        exportName="my-volunteer-hours"
        emptyTitle="No hours logged yet"
        emptyDescription="Log your first volunteer session to start tracking your impact."
      />

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Log volunteer hours</DialogTitle>
            <DialogDescription>Add a new hours entry to your record.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="hrs-date">Date</Label>
              <Input id="hrs-date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="hrs-hours">Hours</Label>
              <Input id="hrs-hours" type="number" min="0.5" step="0.5" value={hours} onChange={(e) => setHours(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="hrs-activity">Activity</Label>
              <Input id="hrs-activity" value={activity} onChange={(e) => setActivity(e.target.value)} placeholder="e.g. Food sorting" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="hrs-event">Related event (optional)</Label>
              <Select value={eventId} onValueChange={setEventId}>
                <SelectTrigger id="hrs-event"><SelectValue placeholder="None" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {events.map((e) => (
                    <SelectItem key={e.id} value={e.id}>{e.title}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={submit}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageShell>
  );
}
