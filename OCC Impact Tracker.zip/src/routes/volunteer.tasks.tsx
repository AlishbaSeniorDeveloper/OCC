import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { CheckCircle2, Clock, ListTodo, PauseCircle, Paperclip, MessageSquare } from "lucide-react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { PageHeader, PageShell, SectionHeading } from "@/components/layout/PageShell";
import { EmptyState, PageSkeleton } from "@/components/kit/States";
import { useAuth } from "@/context/AuthContext";
import { taskService, isOverdue } from "@/services/taskService";
import type { Task } from "@/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/volunteer/tasks")({
  head: () => ({
    meta: [
      { title: "My tasks — OCC Impact Report Tracker" },
      { name: "description", content: "View and manage the tasks assigned to you as an OCC volunteer." },
      { property: "og:title", content: "My tasks — OCC Impact Report Tracker" },
      { property: "og:description", content: "Track, update, and complete your volunteer tasks." },
    ],
  }),
  component: () => (
    <ProtectedRoute allow={["volunteer"]}>
      <TasksPage />
    </ProtectedRoute>
  ),
});

const COLUMNS: { key: Task["status"]; label: string; icon: typeof ListTodo }[] = [
  { key: "todo", label: "To do", icon: ListTodo },
  { key: "in-progress", label: "In progress", icon: Clock },
  { key: "blocked", label: "Blocked", icon: PauseCircle },
  { key: "done", label: "Done", icon: CheckCircle2 },
];

const PRIORITY_TONE: Record<Task["priority"], string> = {
  low: "bg-secondary text-foreground",
  medium: "bg-gold/20 text-foreground",
  high: "bg-terracotta/20 text-terracotta",
};

function TasksPage() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[] | null>(null);
  const [error, setError] = useState(false);
  const [priorityFilter, setPriorityFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [active, setActive] = useState<Task | null>(null);
  const [comment, setComment] = useState("");
  const [completionNote, setCompletionNote] = useState("");
  const [attachmentName, setAttachmentName] = useState("");

  const load = async () => {
    if (!user) return;
    setError(false);
    try {
      const rows = await taskService.listForUser(user.id);
      setTasks(rows);
    } catch {
      setError(true);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const filtered = useMemo(() => {
    if (!tasks) return [];
    return tasks.filter(
      (t) => (priorityFilter === "all" || t.priority === priorityFilter) && (statusFilter === "all" || t.status === statusFilter),
    );
  }, [tasks, priorityFilter, statusFilter]);

  const grouped = useMemo(() => {
    const map: Record<Task["status"], Task[]> = { todo: [], "in-progress": [], blocked: [], done: [] };
    for (const t of filtered) map[t.status].push(t);
    return map;
  }, [filtered]);

  const changeStatus = async (task: Task, status: Task["status"], note?: string) => {
    try {
      const updated = await taskService.updateStatus(task.id, status, note);
      setTasks((prev) => (prev ? prev.map((t) => (t.id === updated.id ? updated : t)) : prev));
      setActive((prev) => (prev && prev.id === updated.id ? updated : prev));
      toast.success(`Task moved to ${status.replace("-", " ")}`);
    } catch {
      toast.error("Couldn't update task status");
    }
  };

  const submitComment = async () => {
    if (!active || !user || !comment.trim()) return;
    try {
      const updated = await taskService.addComment(active.id, user.id, comment.trim());
      setTasks((prev) => (prev ? prev.map((t) => (t.id === updated.id ? updated : t)) : prev));
      setActive(updated);
      setComment("");
      toast.success("Comment added");
    } catch {
      toast.error("Couldn't add comment");
    }
  };

  const submitAttachment = async () => {
    if (!active || !attachmentName.trim()) return;
    try {
      const updated = await taskService.addAttachment(active.id, attachmentName.trim());
      setTasks((prev) => (prev ? prev.map((t) => (t.id === updated.id ? updated : t)) : prev));
      setActive(updated);
      setAttachmentName("");
      toast.success("Attachment added");
    } catch {
      toast.error("Couldn't add attachment");
    }
  };

  if (tasks === null && !error) {
    return (
      <PageShell>
        <PageSkeleton />
      </PageShell>
    );
  }

  return (
    <PageShell>
      <PageHeader
        title="My tasks"
        description="Everything assigned to you, organized by status. Keep it moving!"
      />

      <div className="mb-6 flex flex-wrap gap-3">
        <Select value={priorityFilter} onValueChange={setPriorityFilter}>
          <SelectTrigger className="w-40"><SelectValue placeholder="Priority" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All priorities</SelectItem>
            <SelectItem value="low">Low</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="high">High</SelectItem>
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {COLUMNS.map((c) => (
              <SelectItem key={c.key} value={c.key}>{c.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {error ? (
        <EmptyState title="Couldn't load tasks" description="Please try again shortly." />
      ) : tasks && tasks.length === 0 ? (
        <EmptyState title="No tasks assigned yet" description="Check back soon — staff will assign tasks here." />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {COLUMNS.map((col) => (
            <div key={col.key} className="space-y-3">
              <SectionHeading title={`${col.label} (${grouped[col.key].length})`} />
              <div className="space-y-3">
                {grouped[col.key].length === 0 && (
                  <p className="rounded-lg border border-dashed border-border p-4 text-center text-xs text-muted-foreground">
                    Nothing here
                  </p>
                )}
                {grouped[col.key].map((task) => {
                  const overdue = isOverdue(task);
                  return (
                    <button
                      key={task.id}
                      onClick={() => setActive(task)}
                      className="surface-card block w-full space-y-2 p-4 text-left transition-shadow hover:shadow-md"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-sm font-medium">{task.title}</p>
                        {overdue && <Badge className="bg-terracotta/20 text-terracotta">Overdue</Badge>}
                      </div>
                      <p className="line-clamp-2 text-xs text-muted-foreground">{task.description}</p>
                      <div className="flex items-center justify-between text-xs">
                        <Badge className={PRIORITY_TONE[task.priority]}>{task.priority}</Badge>
                        <span className="text-muted-foreground">
                          Due {new Date(task.dueDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={!!active} onOpenChange={(open) => !open && setActive(null)}>
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
          {active && (
            <>
              <DialogHeader>
                <DialogTitle>{active.title}</DialogTitle>
                <DialogDescription>{active.description}</DialogDescription>
              </DialogHeader>

              <div className="flex flex-wrap items-center gap-2">
                <Badge className={PRIORITY_TONE[active.priority]}>{active.priority} priority</Badge>
                <Badge variant="outline">
                  Due {new Date(active.dueDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                </Badge>
                {isOverdue(active) && <Badge className="bg-terracotta/20 text-terracotta">Overdue</Badge>}
                <Badge variant="outline" className="capitalize">{active.status.replace("-", " ")}</Badge>
              </div>

              <div className="flex flex-wrap gap-2">
                {COLUMNS.map((c) => (
                  <Button
                    key={c.key}
                    size="sm"
                    variant={active.status === c.key ? "default" : "outline"}
                    onClick={() => {
                      if (c.key === "done") {
                        changeStatus(active, "done", completionNote || undefined);
                      } else {
                        changeStatus(active, c.key);
                      }
                    }}
                  >
                    {c.label}
                  </Button>
                ))}
              </div>

              {active.status !== "done" && (
                <div className="space-y-1.5">
                  <p className="text-xs text-muted-foreground">Completion note (optional, used when marking done)</p>
                  <Textarea
                    value={completionNote}
                    onChange={(e) => setCompletionNote(e.target.value)}
                    placeholder="What did you accomplish?"
                    rows={2}
                  />
                </div>
              )}
              {active.completionNote && (
                <p className="rounded-lg bg-secondary p-3 text-xs text-muted-foreground">
                  <strong className="text-foreground">Completion note: </strong>
                  {active.completionNote}
                </p>
              )}

              <div className="space-y-2">
                <p className="flex items-center gap-1.5 text-sm font-medium"><Paperclip className="size-4" aria-hidden /> Attachments</p>
                {active.attachments.length > 0 ? (
                  <ul className="space-y-1 text-xs text-muted-foreground">
                    {active.attachments.map((a, i) => <li key={i}>📎 {a}</li>)}
                  </ul>
                ) : (
                  <p className="text-xs text-muted-foreground">No attachments yet.</p>
                )}
                <div className="flex gap-2">
                  <Input value={attachmentName} onChange={(e) => setAttachmentName(e.target.value)} placeholder="file-name.pdf" />
                  <Button variant="outline" onClick={submitAttachment}>Add</Button>
                </div>
              </div>

              <div className="space-y-2">
                <p className="flex items-center gap-1.5 text-sm font-medium"><MessageSquare className="size-4" aria-hidden /> Comments</p>
                <div className="max-h-40 space-y-2 overflow-y-auto">
                  {active.comments.length === 0 && <p className="text-xs text-muted-foreground">No comments yet.</p>}
                  {active.comments.map((c) => (
                    <div key={c.id} className="rounded-lg bg-secondary p-2.5 text-xs">
                      <p>{c.body}</p>
                      <p className="mt-1 text-[10px] text-muted-foreground">
                        {new Date(c.createdAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                      </p>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Add a comment…" rows={2} />
                </div>
                <Button size="sm" onClick={submitComment} disabled={!comment.trim()}>Post comment</Button>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setActive(null)}>Close</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </PageShell>
  );
}
