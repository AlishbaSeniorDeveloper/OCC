export type Role = "admin" | "student" | "parent" | "volunteer" | "staff";

export type ProgramSlug = "fresh-table" | "sprout-society" | "becoming";

export interface Entity {
  id: string;
  createdAt: string;
  updatedAt: string;
}

export interface User extends Entity {
  email: string;
  fullName: string;
  role: Role;
  programs: ProgramSlug[];
  dateOfBirth: string;
  age: number;
  phone: string;
  zip: string;
  preferredLanguage: string;
  guardianId?: string;
  avatarUrl?: string;
  status: "active" | "inactive" | "pending";
  joinedAt: string;
  lastActiveAt: string;
}

export interface Program extends Entity {
  slug: ProgramSlug;
  name: string;
  tagline: string;
  description: string;
  problemAddressed: string;
  whoWeServe: string[];
  whatWeDeliver: string[];
  topics: string[];
  outcomesTracked: string[];
  ageMin: number;
  ageMax: number;
  colorAccent: string;
  icon: "utensils" | "sprout" | "sparkles";
}

export type QuestionType = "likert" | "multipleChoice" | "scale" | "text" | "emojiScale";

export interface QuestionOption {
  label: string;
  value: number;
  emoji?: string;
}

export interface Question {
  id: string;
  order: number;
  text: string;
  type: QuestionType;
  options: QuestionOption[];
  required: boolean;
  reverseScored: boolean;
  domain?: string;
}

export interface ScoreBand {
  label: string;
  min: number;
  max: number;
  tone: "good" | "watch" | "alert" | "severe";
  interpretation: string;
}

export type Audience = "child" | "teen" | "adult";

export interface Assessment extends Entity {
  title: string;
  programId: ProgramSlug;
  audience: Audience;
  instrumentType: "screener" | "self-report" | "knowledge" | "feedback" | "goal-tracker";
  description: string;
  questions: Question[];
  scoringMethod: "sum" | "sum-reverse" | "correct-count" | "goal";
  bands: ScoreBand[];
  estimatedMinutes: number;
  isActive: boolean;
  safetyItemId?: string;
  domains?: string[];
  childFriendly?: boolean;
}

export interface AttemptResponse {
  questionId: string;
  value: number;
}

export interface AssessmentAttempt extends Entity {
  assessmentId: string;
  userId: string;
  startedAt: string;
  completedAt?: string;
  status: "in-progress" | "completed" | "abandoned";
  responses: AttemptResponse[];
  rawScore: number;
  normalizedScore: number;
  band: string;
  domainScores: Record<string, number>;
  flagged: boolean;
  reviewedBy?: string;
  reviewedAt?: string;
  staffNotes?: string;
}

export interface AttendanceSlot extends Entity {
  userId: string;
  programId: ProgramSlug;
  type: "assessment" | "workshop" | "distribution" | "session";
  title: string;
  scheduledAt: string;
  durationMinutes: number;
  location: string;
  status: "upcoming" | "attended" | "missed" | "excused";
  checkedInAt?: string;
  assessmentId?: string;
}

export interface Workshop extends Entity {
  title: string;
  programId: ProgramSlug;
  audience: Audience;
  description: string;
  facilitator: string;
  startsAt: string;
  durationMinutes: number;
  location: string;
  capacity: number;
  enrolledCount: number;
  tags: string[];
  materialsUrl?: string;
  status: "upcoming" | "completed" | "cancelled";
}

export interface WorkshopEnrollment extends Entity {
  workshopId: string;
  userId: string;
  status: "registered" | "attended" | "no-show";
  feedbackRating?: number;
  feedbackComment?: string;
  postScore?: number;
}

export interface Event extends Entity {
  title: string;
  type: "distribution" | "workshop" | "community" | "volunteer";
  programId?: ProgramSlug;
  startsAt: string;
  endsAt: string;
  location: string;
  address: string;
  description: string;
  capacity: number;
  rsvpCount: number;
  isPublic: boolean;
}

export interface InventoryItem extends Entity {
  name: string;
  category: string;
  unit: string;
  unitLabel: string;
  quantityOnHand: number;
  parLevel: number;
  reorderPoint: number;
  lbsPerUnit: number;
  lastRestockedAt: string;
}

export interface InventoryTransaction extends Entity {
  itemId: string;
  type: "restock" | "distribution" | "adjustment" | "spoilage";
  quantity: number;
  unit: string;
  staffId: string;
  notes: string;
  occurredAt: string;
  source?: string;
}

export interface TaskComment {
  id: string;
  authorId: string;
  body: string;
  createdAt: string;
}

export interface Task extends Entity {
  title: string;
  description: string;
  assignedTo: string;
  assignedBy: string;
  programId?: ProgramSlug;
  priority: "low" | "medium" | "high";
  dueDate: string;
  status: "todo" | "in-progress" | "blocked" | "done";
  completedAt?: string;
  completionNote?: string;
  attachments: string[];
  comments: TaskComment[];
}

export interface Report extends Entity {
  title: string;
  type: string;
  scope: string;
  filters: Record<string, string>;
  generatedBy: string;
  generatedAt: string;
  format: "pdf" | "csv";
  fileUrl?: string;
}

export interface Notification extends Entity {
  userId: string;
  type: "safety" | "task" | "workshop" | "inventory" | "general";
  title: string;
  body: string;
  read: boolean;
  linkTo?: string;
}

export interface Distribution extends Entity {
  eventId: string;
  date: string;
  householdsServed: number;
  individualsServed: number;
  poundsDistributed: number;
  itemsDistributed: { itemId: string; quantity: number }[];
  volunteersPresent: number;
  notes: string;
  zip: string;
  newHouseholds: number;
}

export interface VolunteerHourLog extends Entity {
  userId: string;
  eventId?: string;
  date: string;
  hours: number;
  activity: string;
}

export interface Goal extends Entity {
  userId: string;
  title: string;
  targetDate: string;
  progress: number;
  achieved: boolean;
}

export interface MockDb {
  users: User[];
  attempts: AssessmentAttempt[];
  slots: AttendanceSlot[];
  workshops: Workshop[];
  enrollments: WorkshopEnrollment[];
  events: Event[];
  inventory: InventoryItem[];
  transactions: InventoryTransaction[];
  tasks: Task[];
  reports: Report[];
  notifications: Notification[];
  distributions: Distribution[];
  hourLogs: VolunteerHourLog[];
  goals: Goal[];
  assessmentOverrides: Assessment[];
  session: { userId: string | null };
}
