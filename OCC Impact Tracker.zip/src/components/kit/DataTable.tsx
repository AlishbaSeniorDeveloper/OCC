import { ArrowDown, ArrowUp, Download, Search } from "lucide-react";
import { useMemo, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { reportService } from "@/services/reportService";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { EmptyState } from "./States";

export interface Column<T> {
  key: string;
  header: string;
  render?: (row: T) => ReactNode;
  sortValue?: (row: T) => string | number;
  csvValue?: (row: T) => string | number;
  className?: string;
  hideOnMobile?: boolean;
}

export function DataTable<T extends { id: string }>({
  rows,
  columns,
  searchKeys,
  onRowClick,
  pageSize = 12,
  exportName,
  toolbar,
  emptyTitle = "Nothing here yet",
  emptyDescription = "When there's data to show, it will appear in this table.",
  emptyAction,
}: {
  rows: T[];
  columns: Column<T>[];
  searchKeys?: (row: T) => string;
  onRowClick?: (row: T) => void;
  pageSize?: number;
  exportName?: string;
  toolbar?: ReactNode;
  emptyTitle?: string;
  emptyDescription?: string;
  emptyAction?: ReactNode;
}) {
  const [search, setSearch] = useState("");
  const [sortKey, setSortKey] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");
  const [page, setPage] = useState(0);

  const filtered = useMemo(() => {
    let out = rows;
    if (search && searchKeys) {
      const s = search.toLowerCase();
      out = out.filter((r) => searchKeys(r).toLowerCase().includes(s));
    }
    if (sortKey) {
      const col = columns.find((c) => c.key === sortKey);
      if (col?.sortValue) {
        out = [...out].sort((a, b) => {
          const av = col.sortValue!(a);
          const bv = col.sortValue!(b);
          const cmp = typeof av === "number" && typeof bv === "number" ? av - bv : String(av).localeCompare(String(bv));
          return sortDir === "asc" ? cmp : -cmp;
        });
      }
    }
    return out;
  }, [rows, search, searchKeys, sortKey, sortDir, columns]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize));
  const current = Math.min(page, pageCount - 1);
  const visible = filtered.slice(current * pageSize, current * pageSize + pageSize);

  const exportCsv = async () => {
    const data = filtered.map((row) => {
      const obj: Record<string, string | number> = {};
      for (const col of columns) {
        obj[col.header] = col.csvValue ? col.csvValue(row) : col.sortValue ? col.sortValue(row) : "";
      }
      return obj;
    });
    await reportService.exportCsv(exportName ?? "export", data);
    toast.success("CSV downloaded");
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        {searchKeys && (
          <div className="relative min-w-[220px] flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-sage" aria-hidden />
            <Input
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(0);
              }}
              placeholder="Search…"
              aria-label="Search table"
              className="pl-9"
            />
          </div>
        )}
        {toolbar}
        <Button variant="outline" size="sm" onClick={exportCsv} className="ml-auto">
          <Download className="mr-1.5 size-4" aria-hidden /> CSV
        </Button>
      </div>

      {filtered.length === 0 ? (
        <EmptyState title={emptyTitle} description={emptyDescription} action={emptyAction} />
      ) : (
        <>
          {/* Desktop table */}
          <div className="hidden overflow-hidden rounded-xl border border-border bg-card md:block">
            <Table>
              <TableHeader>
                <TableRow>
                  {columns.map((col) => (
                    <TableHead key={col.key} className={col.className}>
                      {col.sortValue ? (
                        <button
                          className="inline-flex items-center gap-1 hover:text-primary"
                          onClick={() => {
                            if (sortKey === col.key) setSortDir(sortDir === "asc" ? "desc" : "asc");
                            else {
                              setSortKey(col.key);
                              setSortDir("asc");
                            }
                          }}
                        >
                          {col.header}
                          {sortKey === col.key &&
                            (sortDir === "asc" ? (
                              <ArrowUp className="size-3" aria-hidden />
                            ) : (
                              <ArrowDown className="size-3" aria-hidden />
                            ))}
                        </button>
                      ) : (
                        col.header
                      )}
                    </TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {visible.map((row) => (
                  <TableRow
                    key={row.id}
                    onClick={onRowClick ? () => onRowClick(row) : undefined}
                    className={cn(onRowClick && "cursor-pointer")}
                  >
                    {columns.map((col) => (
                      <TableCell key={col.key} className={col.className}>
                        {col.render ? col.render(row) : String(col.sortValue?.(row) ?? "—")}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Mobile stacked cards */}
          <div className="space-y-3 md:hidden">
            {visible.map((row) => (
              <div
                key={row.id}
                role={onRowClick ? "button" : undefined}
                tabIndex={onRowClick ? 0 : undefined}
                onClick={onRowClick ? () => onRowClick(row) : undefined}
                onKeyDown={
                  onRowClick
                    ? (e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault();
                          onRowClick(row);
                        }
                      }
                    : undefined
                }
                className="surface-card block w-full space-y-2 p-4 text-left"
              >
                {columns
                  .filter((c) => !c.hideOnMobile)
                  .map((col) => (
                    <div key={col.key} className="flex items-start justify-between gap-3">
                      <span className="stat-label pt-0.5">{col.header}</span>
                      <span className="text-right text-sm">
                        {col.render ? col.render(row) : String(col.sortValue?.(row) ?? "—")}
                      </span>
                    </div>
                  ))}
              </div>
            ))}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 text-sm text-muted-foreground">
            <p>
              Showing {current * pageSize + 1}–{Math.min(filtered.length, (current + 1) * pageSize)} of{" "}
              {filtered.length}
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled={current === 0} onClick={() => setPage(current - 1)}>
                Previous
              </Button>
              <span>
                Page {current + 1} of {pageCount}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={current >= pageCount - 1}
                onClick={() => setPage(current + 1)}
              >
                Next
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
