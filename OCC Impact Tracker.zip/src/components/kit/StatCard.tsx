import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function StatCard({
  label,
  value,
  hint,
  icon: Icon,
  size = "md",
  className,
}: {
  label: string;
  value: string | number;
  hint?: string;
  icon?: LucideIcon;
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  const figureSize = size === "lg" ? "text-5xl" : size === "sm" ? "text-3xl" : "text-4xl";
  return (
    <div className={cn("surface-card flex flex-col gap-2 p-5", className)}>
      <div className="flex items-start justify-between">
        <p className={cn("stat-figure", figureSize)}>{value}</p>
        {Icon && <Icon className="size-5 text-sage" aria-hidden />}
      </div>
      <p className="stat-label">{label}</p>
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

export function StatGrid({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn("grid gap-4 sm:grid-cols-2 lg:grid-cols-4", className)}>{children}</div>
  );
}

export function ProgressMeter({
  label,
  value,
  max,
  unit = "",
}: {
  label: string;
  value: number;
  max: number;
  unit?: string;
}) {
  const pct = Math.min(100, Math.round((value / max) * 100));
  return (
    <div className="surface-card p-5">
      <p className="stat-label">{label}</p>
      <p className="stat-figure mt-2 text-4xl">
        {value.toLocaleString()}
        {unit}
      </p>
      <p className="mt-1 text-xs text-muted-foreground">
        {pct}% of the {max.toLocaleString()}
        {unit} goal
      </p>
      <div
        className="mt-3 h-2 overflow-hidden rounded-full bg-secondary"
        role="progressbar"
        aria-valuenow={pct}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={`${label} progress`}
      >
        <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}
