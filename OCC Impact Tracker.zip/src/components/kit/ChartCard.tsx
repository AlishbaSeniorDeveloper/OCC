import { Table2 } from "lucide-react";
import { useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export const CHART_COLORS = {
  hunter: "var(--hunter)",
  sage: "var(--sage)",
  gold: "var(--gold)",
  hunterSoft: "var(--hunter-soft)",
  terracotta: "var(--terracotta)",
};

export const CHART_SERIES = [
  CHART_COLORS.hunter,
  CHART_COLORS.sage,
  CHART_COLORS.gold,
  CHART_COLORS.hunterSoft,
  CHART_COLORS.terracotta,
];

export function ChartCard({
  title,
  description,
  children,
  data,
  columns,
  className,
  actions,
}: {
  title: string;
  description?: string;
  children: ReactNode;
  /** Accessible fallback: the same figures as a table. */
  data?: Record<string, string | number>[];
  columns?: { key: string; label: string }[];
  className?: string;
  actions?: ReactNode;
}) {
  const [showTable, setShowTable] = useState(false);
  const cols = columns ?? (data?.[0] ? Object.keys(data[0]).map((k) => ({ key: k, label: k })) : []);

  return (
    <section className={cn("surface-card p-5", className)} aria-label={title}>
      <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="text-lg">{title}</h3>
          {description && <p className="mt-1 text-xs text-muted-foreground">{description}</p>}
        </div>
        <div className="flex items-center gap-2">
          {actions}
          {data && data.length > 0 && (
            <button
              onClick={() => setShowTable((v) => !v)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-input px-2.5 py-1.5 text-xs text-foreground transition-colors hover:bg-secondary"
              aria-pressed={showTable}
            >
              <Table2 className="size-3.5" aria-hidden />
              {showTable ? "Show chart" : "Show data table"}
            </button>
          )}
        </div>
      </div>

      {showTable && data ? (
        <div className="max-h-80 overflow-auto rounded-lg border border-border">
          <Table>
            <TableHeader>
              <TableRow>
                {cols.map((c) => (
                  <TableHead key={c.key}>{c.label}</TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((row, i) => (
                <TableRow key={i}>
                  {cols.map((c) => (
                    <TableCell key={c.key}>{String(row[c.key] ?? "—")}</TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <div className="h-72 w-full">{children}</div>
      )}
    </section>
  );
}

export const axisProps = {
  stroke: "var(--sage)",
  tick: { fill: "var(--muted-foreground)", fontSize: 11 },
  tickLine: false,
};

export const tooltipStyle = {
  contentStyle: {
    background: "var(--card)",
    border: "1px solid var(--border)",
    borderRadius: "10px",
    fontSize: "12px",
    color: "var(--foreground)",
  },
};
