import { useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { HOME_FOR_ROLE, useAuth } from "@/context/AuthContext";
import { authService } from "@/services/authService";
import type { ProgramSlug, Role } from "@/types";

function GoogleMark() {
  return (
    <svg viewBox="0 0 24 24" className="size-4" aria-hidden>
      <path
        fill="#4285F4"
        d="M23.5 12.3c0-.9-.1-1.5-.2-2.2H12v4.2h6.5c-.1 1-.8 2.6-2.4 3.6l3.6 2.8c2.1-1.9 3.8-4.8 3.8-8.4z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.2 0 5.9-1.1 7.7-2.9l-3.6-2.8c-1 .7-2.3 1.2-4.1 1.2-3.1 0-5.8-2.1-6.8-4.9l-3.8 2.9C3.3 21.3 7.3 24 12 24z"
      />
      <path fill="#FBBC05" d="M5.2 14.6c-.3-.8-.4-1.6-.4-2.6s.2-1.8.4-2.6L1.4 6.5C.5 8.2 0 10 0 12s.5 3.8 1.4 5.5l3.8-2.9z" />
      <path
        fill="#EA4335"
        d="M12 4.7c2.2 0 3.7.9 4.5 1.7l3.3-3.2C17.9 1.2 15.2 0 12 0 7.3 0 3.3 2.7 1.4 6.5l3.8 2.9C6.2 6.7 8.9 4.7 12 4.7z"
      />
    </svg>
  );
}

const PROGRAM_DEFAULTS: Record<Role, ProgramSlug[]> = {
  admin: ["fresh-table", "sprout-society", "becoming"],
  staff: ["fresh-table"],
  volunteer: ["fresh-table"],
  parent: ["fresh-table"],
  student: ["sprout-society"],
};

export function AuthCard({
  role,
  roleLabel,
  blurb,
  defaultTab = "signin",
}: {
  role: Role;
  roleLabel: string;
  blurb: string;
  defaultTab?: "signin" | "signup";
}) {
  const { signIn, signInWithGoogle, signInAsRole, setUser } = useAuth();
  const navigate = useNavigate();
  const [busy, setBusy] = useState<string | null>(null);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [name, setName] = useState("");
  const [suEmail, setSuEmail] = useState("");
  const [suPassword, setSuPassword] = useState("");
  const [dob, setDob] = useState("");

  const go = (r: Role) => navigate({ to: HOME_FOR_ROLE[r] });

  async function run(key: string, fn: () => Promise<Role>) {
    setBusy(key);
    try {
      const r = await fn();
      toast.success(`Welcome to OCC, ${roleLabel.toLowerCase()}!`);
      go(r);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Something went wrong. Try again.");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="surface-card mx-auto w-full max-w-md p-6 sm:p-8">
      <h2 className="text-2xl">{roleLabel} access</h2>
      <p className="mt-1 text-sm text-muted-foreground">{blurb}</p>

      <Button
        type="button"
        variant="outline"
        className="mt-6 w-full gap-2"
        disabled={busy !== null}
        onClick={() => run("google", async () => (await signInWithGoogle(role)).role)}
      >
        <GoogleMark />
        {busy === "google" ? "Connecting to Google…" : `Continue with Google`}
      </Button>

      <div className="my-6 flex items-center gap-3 text-xs uppercase tracking-wide text-muted-foreground">
        <span className="h-px flex-1 bg-sage/40" />
        or use email
        <span className="h-px flex-1 bg-sage/40" />
      </div>

      <Tabs defaultValue={defaultTab}>
        <TabsList className="w-full">
          <TabsTrigger value="signin" className="flex-1">
            Sign in
          </TabsTrigger>
          <TabsTrigger value="signup" className="flex-1">
            Sign up
          </TabsTrigger>
        </TabsList>

        <TabsContent value="signin" className="mt-5">
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              void run("signin", async () => (await signIn(email, password, role)).role);
            }}
          >
            <div className="space-y-2">
              <Label htmlFor="signin-email">Email</Label>
              <Input
                id="signin-email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.org"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="signin-password">Password</Label>
              <Input
                id="signin-password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
              />
            </div>
            <Button type="submit" className="w-full" disabled={busy !== null}>
              {busy === "signin" ? "Signing in…" : "Sign in"}
            </Button>
          </form>
        </TabsContent>

        <TabsContent value="signup" className="mt-5">
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              void run("signup", async () => {
                const user = await authService.signUp({
                  email: suEmail,
                  password: suPassword,
                  fullName: name,
                  role,
                  programs: PROGRAM_DEFAULTS[role],
                  dateOfBirth: dob || "2000-01-01",
                  phone: "",
                  zip: "",
                  preferredLanguage: "English",
                });
                setUser(user);
                return user.role;
              });
            }}
          >
            <div className="space-y-2">
              <Label htmlFor="signup-name">Full name</Label>
              <Input id="signup-name" required value={name} onChange={(e) => setName(e.target.value)} placeholder="Jordan Rivera" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="signup-email">Email</Label>
              <Input
                id="signup-email"
                type="email"
                autoComplete="email"
                required
                value={suEmail}
                onChange={(e) => setSuEmail(e.target.value)}
                placeholder="you@example.org"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="signup-password">Password</Label>
              <Input
                id="signup-password"
                type="password"
                autoComplete="new-password"
                required
                minLength={6}
                value={suPassword}
                onChange={(e) => setSuPassword(e.target.value)}
                placeholder="At least 6 characters"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="signup-dob">Date of birth</Label>
              <Input id="signup-dob" type="date" value={dob} onChange={(e) => setDob(e.target.value)} />
            </div>
            <Button type="submit" className="w-full" disabled={busy !== null}>
              {busy === "signup" ? "Creating account…" : `Create ${roleLabel.toLowerCase()} account`}
            </Button>
          </form>
        </TabsContent>
      </Tabs>

      <button
        type="button"
        className="mt-6 w-full text-center text-xs text-muted-foreground underline-offset-2 hover:underline"
        disabled={busy !== null}
        onClick={() => void run("demo", async () => (await signInAsRole(role)).role)}
      >
        {busy === "demo" ? "Loading demo…" : `Explore the demo ${roleLabel.toLowerCase()} account`}
      </button>
    </div>
  );
}
