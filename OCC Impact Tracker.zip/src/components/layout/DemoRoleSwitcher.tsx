import { useNavigate } from "@tanstack/react-router";
import { FlaskConical } from "lucide-react";
import { toast } from "sonner";
import { HOME_FOR_ROLE, useAuth } from "@/context/AuthContext";
import { ROLE_LABEL } from "@/config/nav";
import type { Role } from "@/types";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

const ROLES: Role[] = ["student", "parent", "volunteer", "staff", "admin"];

/** Development-only affordance. Delete this file and its usage in __root.tsx to remove. */
export function DemoRoleSwitcher() {
  const { signInAsRole, user } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Popover>
        <PopoverTrigger asChild>
          <button className="flex items-center gap-2 rounded-lg border border-dashed border-sage bg-card/95 px-3 py-2 text-xs shadow-soft backdrop-blur">
            <FlaskConical className="size-3.5 text-sage" aria-hidden />
            <span className="stat-label">Demo mode</span>
            <span className="text-foreground">switch role</span>
          </button>
        </PopoverTrigger>
        <PopoverContent align="end" className="w-56 border-dashed">
          <p className="mb-2 text-xs text-muted-foreground">
            Sign in instantly as a seeded account. Development only.
          </p>
          <div className="flex flex-col gap-1">
            {ROLES.map((role) => (
              <button
                key={role}
                onClick={async () => {
                  const u = await signInAsRole(role);
                  toast.success(`Signed in as ${u.fullName}`, { description: ROLE_LABEL[role] });
                  void navigate({ to: HOME_FOR_ROLE[role] });
                }}
                className={`rounded-lg px-3 py-2 text-left text-sm transition-colors hover:bg-secondary ${
                  user?.role === role ? "bg-secondary font-medium" : ""
                }`}
              >
                {ROLE_LABEL[role]}
              </button>
            ))}
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
