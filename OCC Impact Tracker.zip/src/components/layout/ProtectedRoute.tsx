import type { ReactNode } from "react";
import { useRoleGuard } from "@/context/AuthContext";
import { PageShell } from "@/components/layout/PageShell";
import { Skeleton } from "@/components/ui/skeleton";
import type { Role } from "@/types";

export function ProtectedRoute({ allow, children }: { allow: Role[]; children: ReactNode }) {
  const { loading, allowed } = useRoleGuard(allow);

  if (loading || !allowed) {
    return (
      <PageShell>
        <div className="space-y-4">
          <Skeleton className="h-10 w-64" />
          <Skeleton className="h-4 w-96" />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-28 rounded-xl" />
            ))}
          </div>
          <Skeleton className="h-72 rounded-xl" />
        </div>
      </PageShell>
    );
  }

  return <>{children}</>;
}
