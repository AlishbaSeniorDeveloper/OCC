import { Link, useRouterState } from "@tanstack/react-router";
import { Bell, Check, LogOut, Menu, User as UserIcon } from "lucide-react";
import { useEffect, useState } from "react";
import { NAV_BY_ROLE, PUBLIC_NAV, ROLE_LABEL } from "@/config/nav";
import { useAuth } from "@/context/AuthContext";
import { programBySlug } from "@/data/programs";
import { cn } from "@/lib/utils";
import { notificationService } from "@/services/eventService";
import type { Notification } from "@/types";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";

function initials(name: string) {
  return name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("");
}

export function AppHeader() {
  const { user, signOut } = useAuth();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    if (!user) {
      setNotifications([]);
      return;
    }
    void notificationService.listForUser(user.id).then(setNotifications);
  }, [user, pathname]);

  const nav = user ? NAV_BY_ROLE[user.role] : PUBLIC_NAV;
  const unread = notifications.filter((n) => !n.read).length;
  const programBadge = user?.programs[0] ? programBySlug(user.programs[0]) : undefined;

  return (
    <header className="fixed inset-x-0 top-0 z-50 bg-hunter text-cream shadow-lift">
      <div className="mx-auto flex h-16 max-w-[1600px] items-center gap-4 px-4 sm:px-6">
        <Link to="/" className="flex shrink-0 items-center gap-2.5">
          <span className="flex size-8 items-center justify-center rounded-full border border-cream/40 font-serif text-sm">
            O
          </span>
          <span className="font-serif text-lg leading-tight">
            OCC <span className="hidden text-cream/70 sm:inline">Impact Tracker</span>
          </span>
        </Link>

        <nav className="hidden flex-1 items-center justify-center gap-1 md:flex">
          {nav.map((item) => {
            const active = pathname === item.to || (item.to !== "/" && pathname.startsWith(item.to + "/"));
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "rounded-lg px-3 py-1.5 text-sm transition-colors",
                  active ? "bg-cream/15 text-cream" : "text-cream/75 hover:bg-cream/10 hover:text-cream",
                )}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          {programBadge && (
            <span className="hidden rounded-full border border-cream/30 px-3 py-1 text-xs text-cream/85 lg:inline">
              {programBadge.name}
            </span>
          )}

          {user && (
            <Popover>
              <PopoverTrigger asChild>
                <button
                  aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`}
                  className="relative rounded-lg p-2 text-cream/85 transition-colors hover:bg-cream/10 hover:text-cream"
                >
                  <Bell className="size-5" aria-hidden />
                  {unread > 0 && (
                    <span className="absolute right-1 top-1 flex size-4 items-center justify-center rounded-full bg-terracotta font-serif text-[10px] text-cream">
                      {unread}
                    </span>
                  )}
                </button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-80 p-0">
                <div className="flex items-center justify-between border-b border-border px-4 py-3">
                  <p className="font-serif text-sm">Notifications</p>
                  {unread > 0 && (
                    <button
                      className="text-xs text-primary underline-offset-2 hover:underline"
                      onClick={async () => {
                        await notificationService.markAllRead(user.id);
                        setNotifications(await notificationService.listForUser(user.id));
                      }}
                    >
                      Mark all read
                    </button>
                  )}
                </div>
                <div className="max-h-80 overflow-y-auto">
                  {notifications.length === 0 && (
                    <p className="px-4 py-6 text-sm text-muted-foreground">You're all caught up.</p>
                  )}
                  {notifications.slice(0, 12).map((n) => (
                    <button
                      key={n.id}
                      onClick={async () => {
                        await notificationService.markRead(n.id);
                        setNotifications(await notificationService.listForUser(user.id));
                      }}
                      className="block w-full border-b border-border/60 px-4 py-3 text-left last:border-0 hover:bg-secondary/60"
                    >
                      <p className="flex items-center gap-2 text-sm font-medium">
                        {n.type === "safety" && <span className="size-2 rounded-full bg-terracotta" aria-hidden />}
                        {n.title}
                        {n.read && <Check className="ml-auto size-3.5 text-sage" aria-label="Read" />}
                      </p>
                      <p className="mt-0.5 text-xs text-muted-foreground">{n.body}</p>
                    </button>
                  ))}
                </div>
              </PopoverContent>
            </Popover>
          )}

          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  className="flex items-center gap-2 rounded-lg p-1 pr-2 transition-colors hover:bg-cream/10"
                  aria-label="Account menu"
                >
                  <Avatar className="size-8 border border-cream/30">
                    <AvatarFallback className="bg-cream/15 font-serif text-xs text-cream">
                      {initials(user.fullName)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="hidden text-sm text-cream/90 lg:inline">{user.fullName.split(" ")[0]}</span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <p className="font-serif text-sm">{user.fullName}</p>
                  <p className="text-xs font-normal text-muted-foreground">{ROLE_LABEL[user.role]}</p>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link to="/about">
                    <UserIcon className="mr-2 size-4" aria-hidden /> About
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={() => void signOut()}>
                  <LogOut className="mr-2 size-4" aria-hidden /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button asChild variant="secondary" size="sm" className="hidden md:inline-flex">
              <Link to="/signin">Sign in</Link>
            </Button>
          )}

          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <button
                className="rounded-lg p-2 text-cream/85 hover:bg-cream/10 md:hidden"
                aria-label="Open navigation"
              >
                <Menu className="size-5" aria-hidden />
              </button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72 bg-hunter text-cream">
              <SheetTitle className="px-4 pt-4 font-serif text-cream">Menu</SheetTitle>
              <nav className="mt-4 flex flex-col gap-1 px-2">
                {nav.map((item) => (
                  <Link
                    key={item.to}
                    to={item.to}
                    onClick={() => setOpen(false)}
                    className="rounded-lg px-3 py-2.5 text-sm text-cream/85 hover:bg-cream/10"
                  >
                    {item.label}
                  </Link>
                ))}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
