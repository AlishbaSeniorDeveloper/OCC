import type { Role } from "@/types";

export interface NavItem {
  label: string;
  to: string;
}

export const NAV_BY_ROLE: Record<Role, NavItem[]> = {
  student: [
    { label: "Home", to: "/student" },
    { label: "Attendance", to: "/student/attendance" },
    { label: "Assessments", to: "/student/assessments" },
    { label: "Workshops", to: "/student/workshops" },
    { label: "Events", to: "/student/events" },
    { label: "Reports", to: "/student/reports" },
  ],
  parent: [
    { label: "Home", to: "/parent" },
    { label: "Workshops", to: "/parent/workshops" },
    { label: "Attendance", to: "/parent/attendance" },
    { label: "My Child", to: "/parent/my-child" },
    { label: "Events", to: "/parent/events" },
  ],
  volunteer: [
    { label: "Home", to: "/volunteer" },
    { label: "My Tasks", to: "/volunteer/tasks" },
    { label: "Events", to: "/volunteer/events" },
    { label: "Hours", to: "/volunteer/hours" },
    { label: "Reports", to: "/volunteer/reports" },
  ],
  staff: [
    { label: "Home", to: "/staff" },
    { label: "Inventory", to: "/staff/inventory" },
    { label: "Workshops", to: "/staff/workshops" },
    { label: "Tasks", to: "/staff/tasks" },
    { label: "Participants", to: "/staff/participants" },
    { label: "Reports", to: "/staff/reports" },
  ],
  admin: [
    { label: "Overview", to: "/admin" },
    { label: "Programs", to: "/admin/programs" },
    { label: "Users", to: "/admin/users" },
    { label: "Assessments", to: "/admin/assessments" },
    { label: "Inventory", to: "/admin/inventory" },
    { label: "Workshops", to: "/admin/workshops" },
    { label: "Events", to: "/admin/events" },
    { label: "Tasks", to: "/admin/tasks" },
    { label: "Reports", to: "/admin/reports" },
    { label: "Settings", to: "/admin/settings" },
  ],
};

export const PUBLIC_NAV: NavItem[] = [
  { label: "About", to: "/about" },
  { label: "Sign in", to: "/signin" },
];

export const ROLE_LABEL: Record<Role, string> = {
  student: "Student",
  parent: "Parent / Adult",
  volunteer: "Volunteer",
  staff: "Staff",
  admin: "Administrator",
};
