import { useNavigate } from "@tanstack/react-router";
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { subscribe } from "@/lib/mock-db";
import { authService } from "@/services/authService";
import type { Role, User } from "@/types";

interface AuthState {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string, role?: Role) => Promise<User>;
  signInWithGoogle: (role: Role) => Promise<User>;
  signInAsRole: (role: Role) => Promise<User>;
  signOut: () => Promise<void>;
  refresh: () => Promise<void>;
  setUser: (user: User | null) => void;
}

const AuthContext = createContext<AuthState | null>(null);

export const HOME_FOR_ROLE: Record<Role, string> = {
  admin: "/admin",
  staff: "/staff",
  volunteer: "/volunteer",
  parent: "/parent",
  student: "/student",
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    const current = await authService.getCurrentUser();
    setUser(current);
    setLoading(false);
  }, []);

  useEffect(() => {
    void refresh();
    return subscribe(() => {
      void authService.getCurrentUser().then(setUser);
    });
  }, [refresh]);

  const value = useMemo<AuthState>(
    () => ({
      user,
      loading,
      signIn: async (email, password, role) => {
        const u = await authService.signIn(email, password, role);
        setUser(u);
        return u;
      },
      signInWithGoogle: async (role) => {
        const u = await authService.signInWithGoogle(role);
        setUser(u);
        return u;
      },
      signInAsRole: async (role) => {
        const u = await authService.signInAsRole(role);
        setUser(u);
        return u;
      },
      signOut: async () => {
        await authService.signOut();
        setUser(null);
      },
      refresh,
      setUser,
    }),
    [user, loading, refresh],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}

/** Redirects to the user's own home when their role isn't allowed. */
export function useRoleGuard(allow: Role[]) {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (loading) return;
    if (!user) {
      void navigate({ to: "/signin" });
      return;
    }
    if (user.role !== "admin" && !allow.includes(user.role)) {
      void navigate({ to: HOME_FOR_ROLE[user.role] });
    }
  }, [user, loading, allow, navigate]);

  const allowed = !!user && (user.role === "admin" || allow.includes(user.role));
  return { user, loading, allowed };
}
