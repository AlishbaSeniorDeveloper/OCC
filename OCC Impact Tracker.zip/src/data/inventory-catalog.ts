export interface CatalogItem {
  name: string;
  unit: string;
  unitLabel: string;
  category: string;
  lbsPerUnit: number;
}

export const inventoryCatalog: CatalogItem[] = [
  { name: "Rice", unit: "bag", unitLabel: "bag (5 lb)", category: "Grains", lbsPerUnit: 5 },
  { name: "Canned Soup", unit: "can", unitLabel: "can", category: "Canned Goods", lbsPerUnit: 1.1 },
  { name: "Canned Greens", unit: "can", unitLabel: "can", category: "Canned Goods", lbsPerUnit: 0.9 },
  { name: "Canned Corn", unit: "can", unitLabel: "can", category: "Canned Goods", lbsPerUnit: 0.9 },
  { name: "Onions", unit: "lb", unitLabel: "lb", category: "Produce", lbsPerUnit: 1 },
  { name: "Pasta Sauce", unit: "jar", unitLabel: "jar (24 oz)", category: "Canned Goods", lbsPerUnit: 1.5 },
  { name: "Spaghetti Sauce", unit: "jar", unitLabel: "jar (24 oz)", category: "Canned Goods", lbsPerUnit: 1.5 },
  { name: "Peanut Butter", unit: "jar", unitLabel: "jar (16 oz)", category: "Protein", lbsPerUnit: 1 },
  { name: "Peanut Butter Crackers", unit: "pack", unitLabel: "pack", category: "Snacks", lbsPerUnit: 0.4 },
  { name: "Jelly", unit: "jar", unitLabel: "jar (18 oz)", category: "Breakfast", lbsPerUnit: 1.1 },
  { name: "Canned Tuna", unit: "can", unitLabel: "can (5 oz)", category: "Protein", lbsPerUnit: 0.3 },
  { name: "Canned Chicken", unit: "can", unitLabel: "can (10 oz)", category: "Protein", lbsPerUnit: 0.6 },
  { name: "Pancakes (frozen)", unit: "box", unitLabel: "box", category: "Breakfast", lbsPerUnit: 1.5 },
  { name: "Pancake Mix", unit: "box", unitLabel: "box (32 oz)", category: "Breakfast", lbsPerUnit: 2 },
  { name: "Syrup", unit: "bottle", unitLabel: "bottle (24 oz)", category: "Breakfast", lbsPerUnit: 1.5 },
  { name: "Cereal", unit: "box", unitLabel: "box (18 oz)", category: "Breakfast", lbsPerUnit: 1.1 },
  { name: "Mac and Cheese", unit: "box", unitLabel: "box", category: "Grains", lbsPerUnit: 0.5 },
  { name: "Canned Fruit", unit: "can", unitLabel: "can (15 oz)", category: "Canned Goods", lbsPerUnit: 0.9 },
  { name: "Baby Food", unit: "jar", unitLabel: "jar (4 oz)", category: "Infant", lbsPerUnit: 0.25 },
  { name: "Baby Formula", unit: "container", unitLabel: "container (12.4 oz)", category: "Infant", lbsPerUnit: 0.8 },
  { name: "Diapers", unit: "pack", unitLabel: "pack", category: "Infant", lbsPerUnit: 3 },
];

export const inventoryCategories = Array.from(new Set(inventoryCatalog.map((i) => i.category)));
