import { assessments } from "@/data/assessments";
import { inventoryCatalog } from "@/data/inventory-catalog";
import { FRESH_TABLE_GOALS } from "@/data/programs";
import type {
  AssessmentAttempt,
  AttendanceSlot,
  Distribution,
  Event,
  Goal,
  InventoryItem,
  InventoryTransaction,
  MockDb,
  Notification,
  ProgramSlug,
  Task,
  User,
  VolunteerHourLog,
  Workshop,
  WorkshopEnrollment,
} from "@/types";

/* Deterministic PRNG so every reload/refresh produces the same demo world. */
let seedState = 20260201;
function rnd(): number {
  seedState = (seedState * 1664525 + 1013904223) % 4294967296;
  return seedState / 4294967296;
}
function ri(min: number, max: number): number {
  return Math.floor(rnd() * (max - min + 1)) + min;
}
function pick<T>(arr: T[]): T {
  return arr[Math.floor(rnd() * arr.length)] as T;
}
function chance(p: number): boolean {
  return rnd() < p;
}

const FIRST_F = [
  "Amara", "Keisha", "Destiny", "Imani", "Jasmine", "Aaliyah", "Nia", "Zuri", "Camila", "Sofia",
  "Layla", "Maya", "Tamika", "Brianna", "Alanis", "Rosa", "Yvette", "Danielle", "Trinity", "Serena",
  "Noelle", "Kimberly", "Precious", "Alicia", "Marisol", "Chanelle", "Jada", "Kenya", "Bianca", "Adaeze",
];
const FIRST_M = [
  "Marcus", "Darius", "Elijah", "Terrence", "Andre", "Malik", "Jamal", "Xavier", "Miguel", "Carlos",
  "Deshawn", "Isaiah", "Rashad", "Omar", "Tyrone", "Devon", "Kwame", "Julio", "Anthony", "Reggie",
];
const LAST = [
  "Ollivier", "Bracey", "Whitaker", "Peebles", "Ferebee", "Sessoms", "Boone", "Copeland", "Riddick",
  "Vann", "Sawyer", "Holloman", "Cuffee", "Fentress", "Blount", "Deloatch", "Nguyen", "Santiago",
  "Delgado", "Mercer", "Wiggins", "Overton", "Beamon", "Yeboah", "Okafor", "Pierce", "Dozier",
  "Trotman", "Lassiter", "Manns", "Batts", "Godwin", "Hargrove", "Ricks", "Askew",
];
const ZIPS = ["23502", "23504", "23508", "23513", "23320", "23324", "23434", "23701", "23703", "23666", "23669", "23607"];
const LANGS = ["English", "English", "English", "English", "Spanish", "Tagalog", "Haitian Creole", "Arabic"];
const LOCATIONS = [
  "OCC Community Room, Norfolk",
  "Park Place Neighborhood Center",
  "Berkley Family Hub",
  "Chesapeake Public Library — South Branch",
  "Suffolk Wellness Annex",
  "Hampton Community Center",
  "Portsmouth Youth Pavilion",
];

const TODAY = new Date("2026-08-02T12:00:00.000Z");
const MONTH_MS = 30.44 * 24 * 3600 * 1000;

function iso(d: Date) {
  return d.toISOString();
}
function daysAgo(n: number) {
  return new Date(TODAY.getTime() - n * 86400000);
}
function daysAhead(n: number) {
  return new Date(TODAY.getTime() + n * 86400000);
}
function withTime(d: Date, hour: number, minute = 0) {
  const c = new Date(d);
  c.setUTCHours(hour, minute, 0, 0);
  return c;
}
function dobForAge(age: number) {
  const d = new Date(TODAY);
  d.setUTCFullYear(d.getUTCFullYear() - age);
  d.setUTCMonth(ri(0, 11), ri(1, 28));
  return d.toISOString().slice(0, 10);
}
function ageFrom(dob: string) {
  const d = new Date(dob);
  let a = TODAY.getUTCFullYear() - d.getUTCFullYear();
  const m = TODAY.getUTCMonth() - d.getUTCMonth();
  if (m < 0 || (m === 0 && TODAY.getUTCDate() < d.getUTCDate())) a--;
  return a;
}

let idc = 0;
const nid = (prefix: string) => `${prefix}_${(++idc).toString(36)}${Math.floor(rnd() * 1e6).toString(36)}`;

function stamp<T extends object>(o: T, created: Date): T & { createdAt: string; updatedAt: string } {
  return { ...o, createdAt: iso(created), updatedAt: iso(created) };
}

/* Seasonal multiplier: dips in December and July */
function seasonalFactor(d: Date) {
  const m = d.getUTCMonth();
  if (m === 11) return 0.55;
  if (m === 6) return 0.6;
  return 1;
}

export function generateSeed(): MockDb {
  seedState = 20260201;
  idc = 0;

  const users: User[] = [];
  const usedEmails = new Set<string>();

  function makeUser(opts: {
    role: User["role"];
    programs: ProgramSlug[];
    age: number;
    female?: boolean;
    joinedMonthsAgo: number;
    guardianId?: string;
  }): User {
    const first = opts.female ?? chance(0.6) ? pick(FIRST_F) : pick(FIRST_M);
    const last = pick(LAST);
    const fullName = `${first} ${last}`;
    let email = `${first}.${last}`.toLowerCase().replace(/[^a-z.]/g, "") + "@example.org";
    let n = 2;
    while (usedEmails.has(email)) {
      email = `${first}.${last}${n++}`.toLowerCase().replace(/[^a-z.0-9]/g, "") + "@example.org";
    }
    usedEmails.add(email);
    const joined = new Date(TODAY.getTime() - opts.joinedMonthsAgo * MONTH_MS - ri(0, 20) * 86400000);
    const dob = dobForAge(opts.age);
    const u: User = stamp(
      {
        id: nid("usr"),
        email,
        fullName,
        role: opts.role,
        programs: opts.programs,
        dateOfBirth: dob,
        age: ageFrom(dob),
        phone: `(757) 555-0${ri(100, 999)}`,
        zip: pick(ZIPS),
        preferredLanguage: pick(LANGS),
        ...(opts.guardianId ? { guardianId: opts.guardianId } : {}),
        status: chance(0.92) ? "active" : chance(0.5) ? "inactive" : "pending",
        joinedAt: iso(joined),
        lastActiveAt: iso(daysAgo(ri(0, 30))),
      },
      joined,
    ) as User;
    users.push(u);
    return u;
  }

  /* ── Admin & demo accounts ── */
  const admin: User = stamp(
    {
      id: "usr_admin",
      email: "admin@ollivierc.org",
      fullName: "Nia Ollivier",
      role: "admin" as const,
      programs: ["fresh-table", "sprout-society", "becoming"] as ProgramSlug[],
      dateOfBirth: dobForAge(44),
      age: 44,
      phone: "(757) 555-0142",
      zip: "23504",
      preferredLanguage: "English",
      status: "active" as const,
      joinedAt: iso(daysAgo(700)),
      lastActiveAt: iso(TODAY),
    },
    daysAgo(700),
  ) as User;
  users.push(admin);

  const staff: User[] = [];
  const staffNames = [
    ["Tamika Boone", "fresh-table"],
    ["Andre Riddick", "fresh-table"],
    ["Jasmine Copeland", "sprout-society"],
    ["Rosa Delgado", "sprout-society"],
    ["Serena Whitaker", "becoming"],
    ["Marcus Peebles", "becoming"],
  ] as [string, ProgramSlug][];
  staffNames.forEach(([name, program], i) => {
    const joined = daysAgo(520 - i * 20);
    const u = stamp(
      {
        id: i === 0 ? "usr_staff" : nid("usr"),
        email: name.toLowerCase().replace(" ", ".") + "@ollivierc.org",
        fullName: name,
        role: "staff" as const,
        programs: [program],
        dateOfBirth: dobForAge(ri(27, 52)),
        age: ri(27, 52),
        phone: `(757) 555-0${ri(100, 999)}`,
        zip: pick(ZIPS),
        preferredLanguage: "English",
        status: "active" as const,
        joinedAt: iso(joined),
        lastActiveAt: iso(daysAgo(ri(0, 4))),
      },
      joined,
    ) as User;
    users.push(u);
    staff.push(u);
  });

  const volunteers: User[] = [];
  for (let i = 0; i < 12; i++) {
    const u = makeUser({
      role: "volunteer",
      programs: [pick(["fresh-table", "fresh-table", "sprout-society", "becoming"] as ProgramSlug[])],
      age: ri(19, 68),
      joinedMonthsAgo: ri(1, 17),
    });
    if (i === 0) u.id = "usr_volunteer";
    volunteers.push(u);
  }

  const parents: User[] = [];
  for (let i = 0; i < 45; i++) {
    const programs: ProgramSlug[] = chance(0.5)
      ? ["fresh-table"]
      : chance(0.5)
        ? ["sprout-society"]
        : ["fresh-table", "sprout-society"];
    const u = makeUser({ role: "parent", programs, age: ri(26, 58), joinedMonthsAgo: ri(0, 18) });
    if (i === 0) u.id = "usr_parent";
    parents.push(u);
  }

  const students: User[] = [];
  const sprout: User[] = [];
  const becoming: User[] = [];
  const freshMembers: User[] = [];

  for (let i = 0; i < 38; i++) {
    const guardian = i < 16 ? parents[i % parents.length] : undefined;
    const u = makeUser({
      role: "student",
      programs: ["sprout-society"],
      age: ri(5, 11),
      joinedMonthsAgo: ri(0, 17),
      ...(guardian ? { guardianId: guardian.id } : {}),
    });
    sprout.push(u);
    students.push(u);
  }
  for (let i = 0; i < 30; i++) {
    const guardian = i < 11 ? parents[(i + 20) % parents.length] : undefined;
    const u = makeUser({
      role: "student",
      programs: ["becoming"],
      age: ri(12, 18),
      female: true,
      joinedMonthsAgo: ri(0, 17),
      ...(guardian ? { guardianId: guardian.id } : {}),
    });
    becoming.push(u);
    students.push(u);
    if (i === 0) u.id = "usr_student";
  }
  for (let i = 0; i < 8; i++) {
    const u = makeUser({
      role: "student",
      programs: ["fresh-table"],
      age: ri(14, 22),
      joinedMonthsAgo: ri(0, 15),
    });
    freshMembers.push(u);
    students.push(u);
  }
  if (becoming[0]) becoming[0].id = "usr_student";

  /* ── Assessment attempts ── */
  const attempts: AssessmentAttempt[] = [];
  const notifications: Notification[] = [];

  function makeAttempt(user: User, assessmentId: string, monthsAgo: number, improvement: number): AssessmentAttempt | null {
    const a = assessments.find((x) => x.id === assessmentId);
    if (!a || a.questions.length === 0) return null;
    const when = new Date(TODAY.getTime() - monthsAgo * MONTH_MS - ri(0, 12) * 86400000);
    const isDeficit = a.instrumentType === "screener" && a.id !== "usda-6" ? true : false;

    const responses = a.questions
      .filter((qq) => qq.type !== "text")
      .map((qq) => {
        const vals = qq.options.map((o) => o.value);
        const hi = Math.max(...vals);
        const lo = Math.min(...vals);
        const span = hi - lo;
        // base tendency 0..1 where higher = better outcome
        let t = 0.35 + rnd() * 0.4 + improvement;
        t = Math.max(0.02, Math.min(0.98, t));
        const good = isDeficit ? 1 - t : t;
        const raw = lo + Math.round(good * span * (0.6 + rnd() * 0.7));
        return { questionId: qq.id, value: Math.max(lo, Math.min(hi, raw)) };
      });

    const byId = new Map(responses.map((r) => [r.questionId, r.value]));
    let rawScore = 0;
    const domainTotals: Record<string, { sum: number; max: number }> = {};
    for (const qq of a.questions) {
      if (qq.type === "text" || qq.options.length === 0) continue;
      const v = byId.get(qq.id) ?? 0;
      const vals = qq.options.map((o) => o.value);
      const hi = Math.max(...vals);
      const lo = Math.min(...vals);
      const eff = qq.reverseScored ? hi + lo - v : v;
      rawScore += eff;
      const dom = qq.domain ?? "Overall";
      domainTotals[dom] ??= { sum: 0, max: 0 };
      domainTotals[dom].sum += eff;
      domainTotals[dom].max += hi;
    }
    const maxRaw = a.questions.reduce(
      (s, qq) => (qq.options.length ? s + Math.max(...qq.options.map((o) => o.value)) : s),
      0,
    );
    const minRaw = a.questions.reduce(
      (s, qq) => (qq.options.length ? s + Math.min(...qq.options.map((o) => o.value)) : s),
      0,
    );
    const normalized = maxRaw === minRaw ? 0 : Math.round(((rawScore - minRaw) / (maxRaw - minRaw)) * 100);
    const bandDef = a.bands.find((b) => rawScore >= b.min && rawScore <= b.max) ?? a.bands[a.bands.length - 1];
    const domainScores: Record<string, number> = {};
    for (const [d, t] of Object.entries(domainTotals)) domainScores[d] = t.max ? Math.round((t.sum / t.max) * 100) : 0;

    const safetyHit = a.safetyItemId ? (byId.get(a.safetyItemId) ?? 0) > 0 : false;
    const flagged = safetyHit || bandDef?.tone === "severe";

    const attempt = stamp(
      {
        id: nid("att"),
        assessmentId: a.id,
        userId: user.id,
        startedAt: iso(when),
        completedAt: iso(new Date(when.getTime() + a.estimatedMinutes * 60000)),
        status: "completed" as const,
        responses,
        rawScore,
        normalizedScore: normalized,
        band: bandDef?.label ?? "Unscored",
        domainScores,
        flagged,
      },
      when,
    ) as AssessmentAttempt;
    attempts.push(attempt);
    return attempt;
  }

  const instrumentsFor: Record<string, string[]> = {
    "becoming": ["phq-a", "gad-7-teen", "rosenberg", "workforce-readiness", "financial-legal", "leadership-inventory"],
    "sprout-society": ["feelings-checkin", "coping-toolbox", "how-i-see-myself"],
    "fresh-table": ["usda-6", "nutrition-confidence"],
  };

  for (const u of students) {
    const list = instrumentsFor[u.programs[0] as string] ?? [];
    for (const instrument of list) {
      if (!chance(0.78)) continue;
      const takes = ri(2, 4);
      for (let k = 0; k < takes; k++) {
        const monthsAgo = 14 - k * ri(3, 4);
        if (monthsAgo < 0) continue;
        makeAttempt(u, instrument, monthsAgo, k * 0.08);
      }
    }
  }
  for (const p of parents) {
    for (const instrument of ["phq-9", "gad-7-adult", "caregiver-stress", "caregiver-feedback", "usda-6"]) {
      if (!chance(0.42)) continue;
      const takes = ri(1, 3);
      for (let k = 0; k < takes; k++) {
        makeAttempt(p, instrument, Math.max(0, 12 - k * 4), k * 0.07);
      }
    }
  }

  /* Guarantee 5 flagged attempts in the review queue */
  let flaggedCount = attempts.filter((a) => a.flagged).length;
  const flagTargets = [...becoming.slice(0, 8), ...parents.slice(0, 8)];
  let ti = 0;
  while (flaggedCount < 5 && ti < flagTargets.length) {
    const user = flagTargets[ti++]!;
    const a = assessments.find((x) => x.id === (user.role === "parent" ? "phq-9" : "phq-a"))!;
    const when = daysAgo(ri(2, 25));
    const responses = a.questions.map((qq, i) => ({ questionId: qq.id, value: i === 8 ? ri(1, 3) : ri(2, 3) }));
    const rawScore = responses.reduce((s, r) => s + r.value, 0);
    const bandDef = a.bands.find((b) => rawScore >= b.min && rawScore <= b.max) ?? a.bands[a.bands.length - 1];
    const att = stamp(
      {
        id: nid("att"),
        assessmentId: a.id,
        userId: user.id,
        startedAt: iso(when),
        completedAt: iso(when),
        status: "completed" as const,
        responses,
        rawScore,
        normalizedScore: Math.round((rawScore / 27) * 100),
        band: bandDef?.label ?? "Severe",
        domainScores: { Mood: Math.round((rawScore / 27) * 100), Safety: 80 },
        flagged: true,
      },
      when,
    ) as AssessmentAttempt;
    attempts.push(att);
    flaggedCount++;
    for (const s of [admin, ...staff.slice(0, 2)]) {
      notifications.push(
        stamp(
          {
            id: nid("ntf"),
            userId: s.id,
            type: "safety" as const,
            title: "Assessment needs review",
            body: `${user.fullName} completed ${a.title} and was flagged for follow-up.`,
            read: false,
            linkTo: "/staff",
          },
          when,
        ) as Notification,
      );
    }
    if (user.guardianId) {
      notifications.push(
        stamp(
          {
            id: nid("ntf"),
            userId: user.guardianId,
            type: "safety" as const,
            title: "Support resources for your child",
            body: `A recent check-in suggests ${user.fullName.split(" ")[0]} could use extra support. A staff member will reach out.`,
            read: false,
            linkTo: "/parent/my-child",
          },
          when,
        ) as Notification,
      );
    }
  }

  /* ── Workshops ── */
  const workshopSeeds: [string, ProgramSlug, "child" | "teen" | "adult", string[]][] = [
    ["Naming Big Feelings: The Emotion Wheel", "sprout-society", "child", ["Understanding emotions"]],
    ["Stress vs. Anxiety: Knowing the Difference", "sprout-society", "child", ["Stress vs. Anxiety"]],
    ["Belly Breathing and Body Scans", "sprout-society", "child", ["Mindfulness and breathing"]],
    ["Coping Toolbox Workshop", "sprout-society", "child", ["Coping skills"]],
    ["Friendship Skills: Using Our Words", "sprout-society", "child", ["Friendship and communication"]],
    ["Kid Yoga and Movement Hour", "sprout-society", "child", ["Mindfulness and breathing"]],
    ["My Goals Board", "sprout-society", "child", ["Self-esteem and confidence"]],
    ["Screens and Feelings: Social Media Awareness", "sprout-society", "child", ["Social media awareness"]],
    ["Bounce Back: Healthy Habits and Resilience", "sprout-society", "child", ["Healthy habits and resilience"]],
    ["Confidence Circle: Self-Esteem Lab", "sprout-society", "child", ["Self-esteem and confidence"]],
    ["Building Your First Resume", "becoming", "teen", ["Building your first resume"]],
    ["Know Your Rights: Legal Literacy for Teens", "becoming", "teen", ["Know your rights"]],
    ["Budgeting on a Real Paycheck", "becoming", "teen", ["Budgeting on a real paycheck"]],
    ["Interviewing with Confidence", "becoming", "teen", ["Interviewing with confidence"]],
    ["Careers You've Never Heard Of", "becoming", "teen", ["Career exploration"]],
    ["Leading Where You Are", "becoming", "teen", ["Leadership in your community"]],
    ["Anxiety Toolkit for Teens", "becoming", "teen", ["Emotional wellness"]],
    ["Credit, Banking, and Your First Account", "becoming", "teen", ["Budgeting on a real paycheck"]],
    ["Mentorship Match Kickoff", "becoming", "teen", ["Confidence and identity"]],
    ["Community Service Project Planning", "becoming", "teen", ["Leadership in your community"]],
    ["Cooking Well on a Tight Budget", "fresh-table", "adult", ["Cooking well on a tight budget"]],
    ["Reading the Label: Sugar, Sodium, Servings", "fresh-table", "adult", ["Reading nutrition labels"]],
    ["Meal Planning for a Full Week", "fresh-table", "adult", ["Meal planning on a budget"]],
    ["Shopping Smart at the Corner Store", "fresh-table", "adult", ["Shopping smart"]],
    ["Pantry Staples, Real Meals", "fresh-table", "adult", ["Cooking well on a tight budget"]],
    ["Feeding Picky Eaters Well", "fresh-table", "adult", ["Meal planning on a budget"]],
    ["Food Safety at Home", "fresh-table", "adult", ["Food safety at home"]],
    ["Caregiver Stress: You Matter Too", "sprout-society", "adult", ["Understanding emotions"]],
    ["Talking to Your Child About Big Feelings", "sprout-society", "adult", ["Understanding emotions"]],
    ["Supporting a Teen Through Anxiety", "becoming", "adult", ["Emotional wellness"]],
    ["Mindfulness for Caregivers", "sprout-society", "adult", ["Mindfulness and breathing"]],
    ["Home Routines That Steady Everyone", "sprout-society", "adult", ["Healthy habits and resilience"]],
    ["Resume Review Clinic", "becoming", "teen", ["Building your first resume"]],
    ["Financial Literacy: Saving Your First $500", "becoming", "teen", ["Budgeting on a real paycheck"]],
    ["Emotional Wheel Refresher", "sprout-society", "child", ["Emotional Wheel activities"]],
    ["Nutrition 101 for Growing Families", "fresh-table", "adult", ["Reading nutrition labels"]],
    ["Advocating for Yourself at School", "becoming", "teen", ["Know your rights"]],
    ["Volunteer Orientation: Distribution Day", "fresh-table", "adult", ["Shopping smart"]],
    ["Self-Care Saturday", "sprout-society", "adult", ["Mindfulness and breathing"]],
    ["Post-Secondary Planning Night", "becoming", "teen", ["Career exploration"]],
  ];

  const workshops: Workshop[] = workshopSeeds.map((w, i) => {
    const [title, programId, audience, tags] = w;
    const isFuture = i >= workshopSeeds.length - 11;
    const when = isFuture ? withTime(daysAhead(ri(2, 80)), ri(14, 18)) : withTime(daysAgo(ri(10, 500)), ri(14, 18));
    const capacity = ri(12, 30);
    const facilitator = pick(staff).fullName;
    return stamp(
      {
        id: nid("wsp"),
        title,
        programId,
        audience,
        description: `A ${audience === "child" ? "playful" : audience === "teen" ? "hands-on" : "practical"} session on ${tags[0]?.toLowerCase()}. Bring yourself; we bring the rest.`,
        facilitator,
        startsAt: iso(when),
        durationMinutes: pick([60, 75, 90, 120]),
        location: pick(LOCATIONS),
        capacity,
        enrolledCount: ri(Math.floor(capacity * 0.4), capacity),
        tags,
        status: isFuture ? ("upcoming" as const) : ("completed" as const),
      },
      when,
    ) as Workshop;
  });

  /* ── Workshop enrollments ── */
  const enrollments: WorkshopEnrollment[] = [];
  const audienceUsers = (a: string, program: ProgramSlug) => {
    if (a === "child") return sprout.filter((u) => u.programs.includes(program));
    if (a === "teen") return becoming;
    return parents;
  };
  for (const w of workshops) {
    const pool = audienceUsers(w.audience, w.programId);
    const count = Math.min(pool.length, w.enrolledCount);
    const shuffled = [...pool].sort(() => rnd() - 0.5).slice(0, count);
    for (const u of shuffled) {
      const past = w.status === "completed";
      const attended = past ? chance(0.82) : false;
      enrollments.push(
        stamp(
          {
            id: nid("enr"),
            workshopId: w.id,
            userId: u.id,
            status: past ? (attended ? ("attended" as const) : ("no-show" as const)) : ("registered" as const),
            ...(attended && chance(0.7) ? { feedbackRating: ri(3, 5), feedbackComment: pick([
              "Really practical. I used it that same week.",
              "My kid talked about this the whole ride home.",
              "The facilitator made it easy to ask questions.",
              "Wish it were longer.",
              "Exactly what I needed right now.",
            ]) } : {}),
            ...(attended ? { postScore: ri(60, 98) } : {}),
          },
          new Date(w.startsAt),
        ) as WorkshopEnrollment,
      );
    }
  }

  /* ── Inventory ── */
  const inventory: InventoryItem[] = inventoryCatalog.map((c) => {
    const par = ri(60, 340);
    const reorder = Math.round(par * 0.4);
    const roll = rnd();
    const qty = roll < 0.18 ? ri(4, reorder - 1) : roll < 0.42 ? ri(reorder, par - 1) : ri(par, Math.round(par * 1.8));
    const restocked = daysAgo(ri(1, 40));
    return stamp(
      {
        id: nid("inv"),
        name: c.name,
        category: c.category,
        unit: c.unit,
        unitLabel: c.unitLabel,
        quantityOnHand: Math.max(0, qty),
        parLevel: par,
        reorderPoint: reorder,
        lbsPerUnit: c.lbsPerUnit,
        lastRestockedAt: iso(restocked),
      },
      daysAgo(500),
    ) as InventoryItem;
  });

  /* ── Distributions + events + inventory transactions ── */
  const events: Event[] = [];
  const distributions: Distribution[] = [];
  const transactions: InventoryTransaction[] = [];

  const distCount = 26;
  const targetHouseholds = FRESH_TABLE_GOALS.households;
  const targetPounds = FRESH_TABLE_GOALS.pounds;
  const weights: number[] = [];
  for (let i = 0; i < distCount; i++) {
    const when = daysAgo((distCount - i) * 14);
    weights.push((0.75 + (i / distCount) * 0.5) * seasonalFactor(when));
  }
  const weightSum = weights.reduce((a, b) => a + b, 0);
  let householdsAllocated = 0;
  let poundsAllocated = 0;

  for (let i = 0; i < distCount; i++) {
    const when = withTime(daysAgo((distCount - i) * 14), 15);
    const isLast = i === distCount - 1;
    const hh = isLast
      ? targetHouseholds - householdsAllocated
      : Math.round((weights[i]! / weightSum) * targetHouseholds);
    const lbs = isLast ? targetPounds - poundsAllocated : Math.round((weights[i]! / weightSum) * targetPounds);
    householdsAllocated += hh;
    poundsAllocated += lbs;

    const ev = stamp(
      {
        id: nid("evt"),
        title: `Fresh Table Distribution — ${when.toLocaleDateString("en-US", { month: "long", day: "numeric" })}`,
        type: "distribution" as const,
        programId: "fresh-table" as ProgramSlug,
        startsAt: iso(when),
        endsAt: iso(new Date(when.getTime() + 3 * 3600000)),
        location: pick(LOCATIONS),
        address: `${ri(100, 4900)} ${pick(["Church St", "Granby St", "Colley Ave", "Military Hwy", "Portsmouth Blvd", "Mercury Blvd"])}, ${pick(["Norfolk", "Chesapeake", "Suffolk", "Hampton", "Portsmouth"])}, VA`,
        description: "Bi-weekly food distribution with nutrition education and referrals on site.",
        capacity: 120,
        rsvpCount: Math.min(120, hh),
        isPublic: true,
      },
      when,
    ) as Event;
    events.push(ev);

    const itemsDistributed = inventory
      .filter(() => chance(0.65))
      .map((item) => ({ itemId: item.id, quantity: ri(10, 90) }));

    distributions.push(
      stamp(
        {
          id: nid("dst"),
          eventId: ev.id,
          date: iso(when),
          householdsServed: hh,
          individualsServed: Math.round(hh * (2.6 + rnd() * 0.9)),
          poundsDistributed: lbs,
          itemsDistributed,
          volunteersPresent: ri(4, 14),
          notes: pick([
            "Steady turnout. Produce went first.",
            "Two new partner referrals made on site.",
            "Rain held off; line moved quickly.",
            "Higher than usual senior turnout.",
            "Ran short on infant supplies.",
          ]),
          zip: pick(ZIPS),
          newHouseholds: Math.round(hh * (0.18 + rnd() * 0.22)),
        },
        when,
      ) as Distribution,
    );

    for (const line of itemsDistributed) {
      const item = inventory.find((x) => x.id === line.itemId)!;
      transactions.push(
        stamp(
          {
            id: nid("txn"),
            itemId: item.id,
            type: "distribution" as const,
            quantity: line.quantity,
            unit: item.unit,
            staffId: pick(staff).id,
            notes: `Distribution ${ev.title}`,
            occurredAt: iso(when),
          },
          when,
        ) as InventoryTransaction,
      );
    }
  }

  /* Restock and adjustment transactions */
  for (let i = 0; i < 90; i++) {
    const item = pick(inventory);
    const when = daysAgo(ri(1, 360));
    const type = chance(0.8) ? ("restock" as const) : chance(0.5) ? ("adjustment" as const) : ("spoilage" as const);
    transactions.push(
      stamp(
        {
          id: nid("txn"),
          itemId: item.id,
          type,
          quantity: type === "restock" ? ri(40, 260) : ri(2, 20),
          unit: item.unit,
          staffId: pick(staff).id,
          notes:
            type === "restock"
              ? `Received from ${pick(["Foodbank of SEVA", "Farmers Market Partners", "Community Drive", "Kroger Donation", "Church Partner Drive"])}`
              : type === "spoilage"
                ? "Removed past-date stock"
                : "Cycle count correction",
          occurredAt: iso(when),
          ...(type === "restock"
            ? { source: pick(["Foodbank of SEVA", "Farmers Market Partners", "Community Drive", "Kroger Donation"]) }
            : {}),
        },
        when,
      ) as InventoryTransaction,
    );
  }
  transactions.sort((a, b) => b.occurredAt.localeCompare(a.occurredAt));

  /* Upcoming public events */
  const upcomingSeeds: [string, Event["type"], ProgramSlug | undefined][] = [
    ["Fresh Table Distribution — Berkley", "distribution", "fresh-table"],
    ["Fresh Table Distribution — Park Place", "distribution", "fresh-table"],
    ["Fresh Table Distribution — Suffolk", "distribution", "fresh-table"],
    ["Sprout Society Family Night", "community", "sprout-society"],
    ["Becoming Career Fair", "community", "becoming"],
    ["Community Wellness Walk", "community", undefined],
    ["Volunteer Sorting Shift", "volunteer", "fresh-table"],
    ["Volunteer Distribution Shift — Norfolk", "volunteer", "fresh-table"],
    ["Volunteer Shift — Sprout Society Setup", "volunteer", "sprout-society"],
    ["Back to School Backpack Drive", "community", undefined],
    ["Mental Health First Aid Community Session", "workshop", undefined],
    ["Becoming Mentorship Mixer", "community", "becoming"],
    ["Sprout Society Garden Day", "community", "sprout-society"],
    ["Senior Grocery Delivery Route", "volunteer", "fresh-table"],
    ["Fresh Table Distribution — Hampton", "distribution", "fresh-table"],
    ["Teen Resume Clinic Drop-In", "workshop", "becoming"],
    ["Caregiver Coffee & Connect", "community", "sprout-society"],
    ["Holiday Food Box Packing", "volunteer", "fresh-table"],
    ["Community Resource Fair", "community", undefined],
    ["Becoming Service Project: Park Cleanup", "volunteer", "becoming"],
  ];
  upcomingSeeds.forEach(([title, type, programId], i) => {
    const when = withTime(daysAhead(ri(2, 88)), ri(9, 18));
    const capacity = ri(20, 150);
    events.push(
      stamp(
        {
          id: i === 0 ? "evt_next" : nid("evt"),
          title,
          type,
          ...(programId ? { programId } : {}),
          startsAt: iso(when),
          endsAt: iso(new Date(when.getTime() + ri(2, 4) * 3600000)),
          location: pick(LOCATIONS),
          address: `${ri(100, 4900)} ${pick(["Church St", "Granby St", "Colley Ave", "Military Hwy", "Portsmouth Blvd"])}, ${pick(["Norfolk", "Chesapeake", "Suffolk", "Hampton"])}, VA`,
          description: "Open to the community. Bring a neighbor.",
          capacity,
          rsvpCount: ri(5, capacity),
          isPublic: true,
        },
        when,
      ) as Event,
    );
  });

  /* ── Attendance slots ── */
  const slots: AttendanceSlot[] = [];
  const participants = [...students, ...parents];
  for (const u of participants) {
    const program = (u.programs[0] ?? "fresh-table") as ProgramSlug;
    const monthsEnrolled = Math.min(18, Math.max(2, Math.round((TODAY.getTime() - new Date(u.joinedAt).getTime()) / MONTH_MS)));
    const total = Math.max(8, monthsEnrolled * ri(2, 3));
    const rate = 0.68 + rnd() * 0.26;
    for (let i = 0; i < total; i++) {
      const when = withTime(daysAgo(ri(1, monthsEnrolled * 30)), ri(15, 18));
      const attended = chance(rate);
      slots.push(
        stamp(
          {
            id: nid("slt"),
            userId: u.id,
            programId: program,
            type: pick(["session", "session", "workshop", "assessment", "distribution"]),
            title: pick([
              "Weekly program session",
              "Group workshop",
              "Check-in assessment",
              "Distribution pickup",
              "Mentorship hour",
            ]),
            scheduledAt: iso(when),
            durationMinutes: pick([45, 60, 90]),
            location: pick(LOCATIONS),
            status: attended ? ("attended" as const) : chance(0.4) ? ("excused" as const) : ("missed" as const),
            ...(attended ? { checkedInAt: iso(when) } : {}),
          },
          when,
        ) as AttendanceSlot,
      );
    }
    // upcoming slots
    for (let i = 0; i < ri(2, 4); i++) {
      const when = withTime(daysAhead(ri(0, 30)), ri(15, 18));
      slots.push(
        stamp(
          {
            id: nid("slt"),
            userId: u.id,
            programId: program,
            type: pick(["session", "workshop", "assessment"]),
            title: pick(["Weekly program session", "Group workshop", "Check-in assessment"]),
            scheduledAt: iso(when),
            durationMinutes: 60,
            location: pick(LOCATIONS),
            status: "upcoming" as const,
          },
          when,
        ) as AttendanceSlot,
      );
    }
  }

  /* ── Tasks ── */
  const taskTitles = [
    ["Pack 40 senior grocery boxes", "fresh-table"],
    ["Call households for distribution reminder", "fresh-table"],
    ["Restock infant supplies shelf", "fresh-table"],
    ["Sort produce donation from farmers market", "fresh-table"],
    ["Print nutrition handouts for Saturday", "fresh-table"],
    ["Set up Sprout Society craft stations", "sprout-society"],
    ["Laminate emotion wheel cards", "sprout-society"],
    ["Follow up with two caregivers on feedback forms", "sprout-society"],
    ["Prep yoga mats and calm corner", "sprout-society"],
    ["Schedule mentorship match interviews", "becoming"],
    ["Review 8 teen resumes before clinic", "becoming"],
    ["Book guest speaker for career night", "becoming"],
    ["Order printer paper and folders", undefined],
    ["Update volunteer roster spreadsheet", undefined],
    ["Draft monthly impact email", undefined],
    ["Confirm venue for community resource fair", undefined],
    ["Enter attendance from last session", undefined],
    ["Check expiration dates on canned goods", "fresh-table"],
    ["Assemble welcome packets for new families", undefined],
    ["Photograph distribution for grant report", "fresh-table"],
  ] as [string, ProgramSlug | undefined][];

  const tasks: Task[] = [];
  const assignees = [...volunteers, ...staff];
  for (let i = 0; i < 70; i++) {
    const [title, programId] = pick(taskTitles);
    const assignee = pick(assignees);
    const created = daysAgo(ri(1, 120));
    const statusRoll = rnd();
    const status: Task["status"] =
      statusRoll < 0.32 ? "todo" : statusRoll < 0.52 ? "in-progress" : statusRoll < 0.62 ? "blocked" : "done";
    const due = chance(0.35) ? daysAgo(ri(1, 20)) : daysAhead(ri(1, 30));
    tasks.push(
      stamp(
        {
          id: nid("tsk"),
          title,
          description: `${title}. Coordinate with the program lead and log completion in the tracker when finished.`,
          assignedTo: assignee.id,
          assignedBy: chance(0.6) ? admin.id : pick(staff).id,
          ...(programId ? { programId } : {}),
          priority: pick(["low", "medium", "medium", "high"]),
          dueDate: iso(due),
          status,
          ...(status === "done" ? { completedAt: iso(daysAgo(ri(1, 30))), completionNote: "Done and logged." } : {}),
          attachments: [],
          comments: chance(0.4)
            ? [
                {
                  id: nid("cmt"),
                  authorId: pick(staff).id,
                  body: pick([
                    "Supplies are in the back closet.",
                    "Let me know if you need a second pair of hands.",
                    "Pushed the deadline out a few days.",
                  ]),
                  createdAt: iso(daysAgo(ri(1, 20))),
                },
              ]
            : [],
        },
        created,
      ) as Task,
    );
  }

  /* ── Volunteer hours ── */
  const hourLogs: VolunteerHourLog[] = [];
  for (const v of volunteers) {
    for (let m = 0; m < 14; m++) {
      const shifts = ri(0, 3);
      for (let s = 0; s < shifts; s++) {
        const when = daysAgo(m * 30 + ri(1, 28));
        hourLogs.push(
          stamp(
            {
              id: nid("hrs"),
              userId: v.id,
              date: iso(when),
              hours: ri(2, 6),
              activity: pick(["Distribution shift", "Sorting and packing", "Program setup", "Front desk & check-in", "Delivery route"]),
            },
            when,
          ) as VolunteerHourLog,
        );
      }
    }
  }

  /* ── Goals (Sprout Society) ── */
  const goals: Goal[] = [];
  const goalTitles = [
    "Use my breathing tool when I get upset",
    "Say one kind thing to a friend each day",
    "Try a new vegetable this week",
    "Ask for help when I need it",
    "Go to bed on time five nights",
    "Finish my reading every day",
  ];
  for (const child of sprout) {
    for (let i = 0; i < ri(1, 3); i++) {
      const created = daysAgo(ri(10, 120));
      const progress = ri(0, 100);
      goals.push(
        stamp(
          {
            id: nid("gol"),
            userId: child.id,
            title: pick(goalTitles),
            targetDate: iso(daysAhead(ri(5, 60))),
            progress,
            achieved: progress >= 100,
          },
          created,
        ) as Goal,
      );
    }
  }
  for (const teen of becoming.slice(0, 18)) {
    const created = daysAgo(ri(10, 120));
    const progress = ri(20, 100);
    goals.push(
      stamp(
        {
          id: nid("gol"),
          userId: teen.id,
          title: pick(["Finish my resume", "Apply to two summer programs", "Save $100", "Complete 10 service hours", "Identify a post-secondary goal"]),
          targetDate: iso(daysAhead(ri(5, 90))),
          progress,
          achieved: progress >= 100,
        },
        created,
      ) as Goal,
    );
  }

  /* ── General notifications ── */
  for (const u of [admin, ...staff, ...volunteers.slice(0, 6), ...students.slice(0, 20), ...parents.slice(0, 12)]) {
    const count = ri(1, 3);
    for (let i = 0; i < count; i++) {
      const when = daysAgo(ri(0, 14));
      notifications.push(
        stamp(
          {
            id: nid("ntf"),
            userId: u.id,
            type: pick(["task", "workshop", "inventory", "general"]),
            title: pick([
              "New workshop open for registration",
              "Your next session is coming up",
              "A task was assigned to you",
              "Low stock on a pantry item",
              "Your report is ready",
            ]),
            body: "Tap to see the details in your dashboard.",
            read: chance(0.5),
            createdAt: iso(when),
          },
          when,
        ) as Notification,
      );
    }
  }

  return {
    users,
    attempts,
    slots,
    workshops,
    enrollments,
    events,
    inventory,
    transactions,
    tasks,
    reports: [],
    notifications,
    distributions,
    hourLogs,
    goals,
    assessmentOverrides: [],
    session: { userId: null },
  };
}
