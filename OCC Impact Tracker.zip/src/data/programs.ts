import type { Program } from "@/types";

const now = "2026-01-01T00:00:00.000Z";

export const MISSION =
  "Ollivier Community Circle advances health equity for underserved individuals and families of all backgrounds across Virginia by providing nutritious food, culturally responsive mental health education, and holistic wellness programs that empower everyone to thrive.";

export const VISION =
  "We envision a future where all Virginia communities thrive, driven by a measurable reduction in food insecurity and mental health disparities to levels below national and state averages.";

export const VALUES = [
  "Equity in Access",
  "Dignity in Human-Centered Care",
  "Community-Led Solutions",
  "Collaborative Impact",
  "Accountability & Outcomes",
  "Cultural Responsiveness",
];

export const FRESH_TABLE_GOALS = { households: 1000, pounds: 10475 };

export const programs: Program[] = [
  {
    id: "fresh-table",
    slug: "fresh-table",
    name: "The Fresh Table",
    tagline: "Food security for Hampton Roads.",
    description:
      "Bi-weekly food distribution paired with nutrition education, healthy eating resources, and referrals so households across Hampton Roads can put good food on the table.",
    problemAddressed:
      "Food insecurity across Hampton Roads leaves households choosing between groceries and other essentials, with limited access to fresh, culturally familiar food.",
    whoWeServe: [
      "Children and adolescents",
      "Families and caregivers",
      "Seniors",
      "Veterans",
      "Underserved households",
    ],
    whatWeDeliver: [
      "Bi-weekly food distribution events",
      "Nutrition education",
      "Healthy eating resources",
      "Wellness and prevention information",
      "Referrals to community resources",
    ],
    topics: [
      "Meal planning on a budget",
      "Reading nutrition labels",
      "Cooking well on a tight budget",
      "Shopping smart",
      "Food safety at home",
    ],
    outcomesTracked: [
      "Households served",
      "Pounds of food distributed",
      "Individuals served",
      "Household food security score",
      "Nutrition confidence",
    ],
    ageMin: 0,
    ageMax: 120,
    colorAccent: "hunter",
    icon: "utensils",
    createdAt: now,
    updatedAt: now,
  },
  {
    id: "sprout-society",
    slug: "sprout-society",
    name: "Sprout Society",
    tagline: "Mental health education for children ages 5–11.",
    description:
      "A warm, playful space where children learn to name feelings, build coping skills, and grow confidence through movement, mindfulness, and creative wellness.",
    problemAddressed:
      "Young children rarely get age-appropriate mental health education, so big feelings go unnamed and coping skills go untaught.",
    whoWeServe: ["Children ages 5–11", "Their caregivers and families"],
    whatWeDeliver: [
      "Mental health education",
      "Social-emotional learning",
      "Emotional regulation activities",
      "Coping skills practice",
      "Mindfulness and yoga",
      "Goal-setting",
      "Self-esteem building",
      "Creative wellness experiences",
    ],
    topics: [
      "Understanding emotions",
      "Emotional Wheel activities",
      "Stress vs. Anxiety",
      "Coping skills",
      "Friendship and communication",
      "Social media awareness",
      "Mindfulness and breathing",
      "Self-esteem and confidence",
      "Healthy habits and resilience",
    ],
    outcomesTracked: [
      "Emotional regulation skills",
      "Use of healthy coping strategies",
      "Self-esteem",
      "Goal achievement",
      "Resilience",
      "Caregiver feedback",
      "Attendance and retention",
    ],
    ageMin: 5,
    ageMax: 11,
    colorAccent: "sage",
    icon: "sprout",
    createdAt: now,
    updatedAt: now,
  },
  {
    id: "becoming",
    slug: "becoming",
    name: "Becoming",
    tagline: "Empowerment for teen girls ages 12–18.",
    description:
      "Leadership, wellness, and workforce readiness for teen girls across Hampton Roads — with mentorship and real-world skills that open doors.",
    problemAddressed:
      "Teen girls in underserved Hampton Roads communities face compounding gaps in mental health support, career exposure, and financial and legal literacy.",
    whoWeServe: ["Teen girls ages 12–18", "First-generation college hopefuls", "Young caregivers"],
    whatWeDeliver: [
      "Teen empowerment programming",
      "Leadership development",
      "Mental health education",
      "Career exploration",
      "Job readiness",
      "Resume development",
      "Financial literacy",
      "Legal literacy and advocacy education",
      "Mentorship",
      "Community service projects",
    ],
    topics: [
      "Confidence and identity",
      "Emotional wellness",
      "Building your first resume",
      "Interviewing with confidence",
      "Budgeting on a real paycheck",
      "Know your rights",
      "Career exploration",
      "Leadership in your community",
    ],
    outcomesTracked: [
      "Confidence and self-esteem",
      "Emotional wellness",
      "Workforce readiness",
      "Resume completion",
      "Career exploration participation",
      "Leadership development",
      "Post-secondary goal identification",
      "Community service participation",
    ],
    ageMin: 12,
    ageMax: 18,
    colorAccent: "terracotta",
    icon: "sparkles",
    createdAt: now,
    updatedAt: now,
  },
];

export const programBySlug = (slug: string) => programs.find((p) => p.slug === slug);
