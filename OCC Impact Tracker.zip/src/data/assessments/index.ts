import type { Assessment, Question, QuestionOption, ScoreBand } from "@/types";

const TS = "2026-01-01T00:00:00.000Z";

const PHQ_OPTIONS: QuestionOption[] = [
  { label: "Not at all", value: 0 },
  { label: "Several days", value: 1 },
  { label: "More than half the days", value: 2 },
  { label: "Nearly every day", value: 3 },
];

const AGREE4: QuestionOption[] = [
  { label: "Strongly Disagree", value: 0 },
  { label: "Disagree", value: 1 },
  { label: "Agree", value: 2 },
  { label: "Strongly Agree", value: 3 },
];

const CONF5: QuestionOption[] = [
  { label: "Not confident", value: 1 },
  { label: "Slightly confident", value: 2 },
  { label: "Somewhat confident", value: 3 },
  { label: "Confident", value: 4 },
  { label: "Very confident", value: 5 },
];

const FREQ5: QuestionOption[] = [
  { label: "Never", value: 1 },
  { label: "Rarely", value: 2 },
  { label: "Sometimes", value: 3 },
  { label: "Often", value: 4 },
  { label: "Always", value: 5 },
];

const EMOJI5: QuestionOption[] = [
  { label: "Not yet", value: 1, emoji: "😞" },
  { label: "A little", value: 2, emoji: "😕" },
  { label: "Okay", value: 3, emoji: "😐" },
  { label: "Pretty good", value: 4, emoji: "🙂" },
  { label: "Yes, always!", value: 5, emoji: "😄" },
];

const KID3: QuestionOption[] = [
  { label: "Not yet", value: 1, emoji: "🌱" },
  { label: "Sometimes", value: 2, emoji: "🌿" },
  { label: "Yes, I can", value: 3, emoji: "🌳" },
];

const SMILEY3: QuestionOption[] = [
  { label: "Not really", value: 1, emoji: "😐" },
  { label: "Sometimes", value: 2, emoji: "🙂" },
  { label: "Yes!", value: 3, emoji: "😄" },
];

const YESNO_USDA: QuestionOption[] = [
  { label: "Never true", value: 0 },
  { label: "Sometimes true", value: 1 },
  { label: "Often true", value: 1 },
];

function q(
  id: string,
  order: number,
  text: string,
  options: QuestionOption[],
  extra: Partial<Question> = {},
): Question {
  return {
    id,
    order,
    text,
    type: options[0]?.emoji ? "emojiScale" : options.length > 4 ? "scale" : "likert",
    options,
    required: true,
    reverseScored: false,
    ...extra,
  };
}

function build(a: Omit<Assessment, "createdAt" | "updatedAt">): Assessment {
  return { ...a, createdAt: TS, updatedAt: TS };
}

const band = (
  label: string,
  min: number,
  max: number,
  tone: ScoreBand["tone"],
  interpretation: string,
): ScoreBand => ({ label, min, max, tone, interpretation });

/* ────────────── BECOMING ────────────── */

const phqaItems = [
  "Little interest or pleasure in doing things",
  "Feeling down, depressed, irritable, or hopeless",
  "Trouble falling asleep, staying asleep, or sleeping too much",
  "Feeling tired or having little energy",
  "Poor appetite, weight loss, or overeating",
  "Feeling bad about yourself — or that you are a failure, or have let yourself or your family down",
  "Trouble concentrating on things like schoolwork, reading, or watching TV",
  "Moving or speaking so slowly that other people notice — or being fidgety or restless",
  "Thoughts that you would be better off dead, or of hurting yourself in some way",
];

const gad7Items = [
  "Feeling nervous, anxious, or on edge",
  "Not being able to stop or control worrying",
  "Worrying too much about different things",
  "Trouble relaxing",
  "Being so restless that it is hard to sit still",
  "Becoming easily annoyed or irritable",
  "Feeling afraid as if something awful might happen",
];

const rosenbergItems: [string, boolean][] = [
  ["On the whole, I am satisfied with myself.", false],
  ["At times I think I am no good at all.", true],
  ["I feel that I have a number of good qualities.", false],
  ["I am able to do things as well as most other people.", false],
  ["I feel I do not have much to be proud of.", true],
  ["I certainly feel useless at times.", true],
  ["I feel that I am a person of worth, at least the equal of others.", false],
  ["I wish I could have more respect for myself.", true],
  ["All in all, I am inclined to feel that I am a failure.", true],
  ["I take a positive attitude toward myself.", false],
];

const workforceItems: [string, string][] = [
  ["I can write a resume that shows my strengths.", "Resume & Application Skills"],
  ["I know how to describe my experience in an application.", "Resume & Application Skills"],
  ["I can write a cover letter or short intro about myself.", "Resume & Application Skills"],
  ["I feel ready to answer common interview questions.", "Interview Confidence"],
  ["I know how to dress and prepare for an interview.", "Interview Confidence"],
  ["I can talk about my strengths out loud without shrinking.", "Interview Confidence"],
  ["I can ask a supervisor a question when I am unsure.", "Workplace Communication"],
  ["I can work through a disagreement with a coworker.", "Workplace Communication"],
  ["I know how to give and receive feedback at work.", "Workplace Communication"],
  ["I have a clear idea of a career field I want to explore.", "Career Direction"],
  ["I know what education or training my goal requires.", "Career Direction"],
  ["I know at least one adult who can help me get there.", "Career Direction"],
];

const finLegalItems: [string, string[], number][] = [
  ["A budget is best described as…", ["A list of your debts", "A plan for money coming in and going out", "Your credit score", "A savings account"], 1],
  ["Which action most helps build credit history?", ["Skipping payments", "Paying your bill on time every month", "Closing all accounts", "Only using cash"], 1],
  ["What does APR measure?", ["Yearly cost of borrowing", "Bank branch count", "Monthly income", "Tax rate"], 0],
  ["A checking account is mainly for…", ["Long-term growth", "Everyday spending and bills", "Retirement", "Buying stocks"], 1],
  ["Before signing a contract you should…", ["Sign quickly to be polite", "Read every term and ask questions", "Assume it is standard", "Let a friend sign"], 1],
  ["A security deposit is…", ["A gift to the landlord", "Refundable money held against damage", "First month's rent", "A fee for applying"], 1],
  ["If a landlord will not make a needed repair, a tenant can…", ["Do nothing", "Request it in writing and contact a tenant rights agency", "Stop paying with no notice", "Move out without notice"], 1],
  ["An emergency fund should ideally cover…", ["One day", "3–6 months of essential costs", "10 years", "Nothing"], 1],
  ["If stopped by police, you have the right to…", ["Nothing", "Remain silent and ask for a lawyer", "Leave immediately", "Refuse to identify yourself in all cases"], 1],
  ["Gross pay differs from net pay because net pay…", ["Is before taxes", "Is after taxes and deductions", "Includes bonuses only", "Is the same"], 1],
];

const leadershipItems = [
  "I speak up when I see something that is not right.",
  "I can lead a small group toward a shared goal.",
  "I look for ways to serve my community.",
  "I can plan a project from start to finish.",
  "I listen well to people who disagree with me.",
  "I encourage other people's ideas.",
  "I follow through on commitments I make.",
  "I see myself as a leader.",
];

/* ────────────── SPROUT SOCIETY ────────────── */

const feelingsItems = [
  "I can name how I feel.",
  "I can tell when I'm getting upset.",
  "I can talk about my feelings with a grown-up.",
  "I can calm my body down when I need to.",
  "I know that all feelings are okay to have.",
  "I can tell when a friend is upset.",
  "I can wait my turn even when it's hard.",
  "I feel good about my day most days.",
];

const copingItems: [string, string][] = [
  ["I can take slow deep breaths when I feel big feelings.", "Deep breathing"],
  ["I can ask a grown-up for help.", "Asking for help"],
  ["I can take a break in a quiet spot.", "Taking a break"],
  ["I can use my words instead of my hands.", "Using words"],
  ["I can notice five things around me to feel calm.", "Mindfulness"],
  ["I can move my body — stretch, walk, or dance — to feel better.", "Movement"],
  ["I can count to ten before I answer.", "Deep breathing"],
  ["I can name one thing I am thankful for.", "Mindfulness"],
];

const selfViewItems = [
  "I like being me.",
  "I am good at something.",
  "I can try again when something is hard.",
  "My friends like being with me.",
  "I am kind to myself when I make a mistake.",
  "I am proud of something I did this week.",
];

const caregiverItems = [
  "My child can name their feelings at home.",
  "My child uses a calming strategy when upset.",
  "My child recovers from frustration more quickly than before.",
  "My child talks with me about their day.",
  "My child shows kindness to siblings or friends.",
  "My child's sleep and routines are steady.",
  "My child asks for help when they need it.",
  "My child seems more confident than when they started.",
  "I feel more confident supporting my child's emotions.",
  "I would recommend this program to another family.",
];

/* ────────────── FRESH TABLE / ADULT ────────────── */

const usdaItems = [
  "The food that we bought just didn't last, and we didn't have money to get more.",
  "We couldn't afford to eat balanced meals.",
  "In the last 12 months, did you or other adults in your household ever cut the size of your meals or skip meals because there wasn't enough money for food?",
  "How often did this happen?",
  "In the last 12 months, did you ever eat less than you felt you should because there wasn't enough money for food?",
  "In the last 12 months, were you ever hungry but didn't eat because there wasn't enough money for food?",
];

const nutritionItems: [string, string][] = [
  ["I can plan a week of meals before I shop.", "Meal planning"],
  ["I can build a grocery list from what I already have at home.", "Meal planning"],
  ["I can read a nutrition label and understand serving size.", "Label reading"],
  ["I can compare two products and pick the healthier one.", "Label reading"],
  ["I can find the added sugar on a label.", "Label reading"],
  ["I can shop for a full week within a set budget.", "Budget shopping"],
  ["I know how to use store sales and unit pricing.", "Budget shopping"],
  ["I can cook a balanced meal from pantry staples.", "Cooking confidence"],
  ["I can cook dried beans, rice, or other bulk staples.", "Cooking confidence"],
  ["I feel confident feeding my household well on what we have.", "Cooking confidence"],
];

const caregiverStressItems: [string, string][] = [
  ["I feel overwhelmed by the demands of caregiving.", "Stress load"],
  ["I have trouble sleeping because of worry.", "Stress load"],
  ["I feel stretched thin between work and family.", "Stress load"],
  ["I have someone I can talk to honestly.", "Social support"],
  ["I have people who would help me in a hard week.", "Social support"],
  ["I feel connected to my community.", "Social support"],
  ["I can get a break when I need one.", "Respite access"],
  ["I have reliable childcare when I need it.", "Respite access"],
  ["I know how to respond when my child is emotionally struggling.", "Supporting my child"],
  ["I feel confident talking with my child about mental health.", "Supporting my child"],
];

/* ────────────── ASSESSMENT DEFINITIONS ────────────── */

export const assessments: Assessment[] = [
  build({
    id: "phq-a",
    title: "PHQ-A — Adolescent Depression Check-In",
    programId: "becoming",
    audience: "teen",
    instrumentType: "screener",
    description:
      "Nine questions about the last two weeks. It helps us understand how you've been feeling lately.",
    questions: phqaItems.map((t, i) =>
      q(`phqa-${i + 1}`, i + 1, `Over the last 2 weeks, how often have you been bothered by: ${t}`, PHQ_OPTIONS, {
        domain: i === 8 ? "Safety" : "Mood",
      }),
    ),
    scoringMethod: "sum",
    bands: [
      band("Minimal", 0, 4, "good", "Your answers suggest very few low-mood symptoms right now."),
      band("Mild", 5, 9, "good", "Some low-mood symptoms are showing up. Worth keeping an eye on."),
      band("Moderate", 10, 14, "watch", "A number of symptoms are present. Let's talk about support."),
      band("Moderately Severe", 15, 19, "alert", "Symptoms are showing up often. Extra support would help."),
      band("Severe", 20, 27, "severe", "Your answers point to a heavy load right now. You deserve support today."),
    ],
    estimatedMinutes: 5,
    isActive: true,
    safetyItemId: "phqa-9",
    domains: ["Mood", "Safety"],
  }),
  build({
    id: "gad-7-teen",
    title: "GAD-7 — Anxiety Check-In",
    programId: "becoming",
    audience: "teen",
    instrumentType: "screener",
    description: "Seven questions about worry and nervousness over the last two weeks.",
    questions: gad7Items.map((t, i) =>
      q(`gad7t-${i + 1}`, i + 1, `Over the last 2 weeks, how often have you been bothered by: ${t}`, PHQ_OPTIONS, {
        domain: "Anxiety",
      }),
    ),
    scoringMethod: "sum",
    bands: [
      band("Minimal", 0, 4, "good", "Very little anxiety showing up right now."),
      band("Mild", 5, 9, "good", "Some worry is present. Coping tools can help."),
      band("Moderate", 10, 14, "watch", "Worry is affecting your days. Let's build a plan."),
      band("Severe", 15, 21, "severe", "Anxiety is heavy right now. Extra support is warranted."),
    ],
    estimatedMinutes: 4,
    isActive: true,
    domains: ["Anxiety"],
  }),
  build({
    id: "rosenberg",
    title: "Rosenberg Self-Esteem Scale",
    programId: "becoming",
    audience: "teen",
    instrumentType: "self-report",
    description: "Ten statements about how you see yourself.",
    questions: rosenbergItems.map(([t, rev], i) =>
      q(`rse-${i + 1}`, i + 1, t, AGREE4, { reverseScored: rev, domain: "Self-esteem" }),
    ),
    scoringMethod: "sum-reverse",
    bands: [
      band("Low", 0, 14, "watch", "Self-esteem is running low. This grows with practice and support."),
      band("Normal", 15, 25, "good", "Your self-view sits in the typical range."),
      band("High", 26, 30, "good", "You hold a strong, positive view of yourself."),
    ],
    estimatedMinutes: 4,
    isActive: true,
    domains: ["Self-esteem"],
  }),
  build({
    id: "workforce-readiness",
    title: "Workforce Readiness Self-Check",
    programId: "becoming",
    audience: "teen",
    instrumentType: "self-report",
    description: "Twelve items across resume skills, interview confidence, workplace communication, and career direction.",
    questions: workforceItems.map(([t, d], i) => q(`wfr-${i + 1}`, i + 1, t, CONF5, { domain: d })),
    scoringMethod: "sum",
    bands: [
      band("Getting started", 12, 27, "watch", "You're at the beginning — plenty to build here."),
      band("Building", 28, 43, "good", "Real skills are forming. Keep practicing."),
      band("Job ready", 44, 60, "good", "You're carrying strong workforce confidence."),
    ],
    estimatedMinutes: 6,
    isActive: true,
    domains: ["Resume & Application Skills", "Interview Confidence", "Workplace Communication", "Career Direction"],
  }),
  build({
    id: "financial-legal",
    title: "Financial & Legal Literacy Check",
    programId: "becoming",
    audience: "teen",
    instrumentType: "knowledge",
    description: "Ten knowledge questions on budgeting, credit, banking, contracts, tenant rights, and your rights.",
    questions: finLegalItems.map(([text, opts, correct], i) => ({
      id: `fll-${i + 1}`,
      order: i + 1,
      text,
      type: "multipleChoice" as const,
      options: opts.map((label, idx) => ({ label, value: idx === correct ? 1 : 0 })),
      required: true,
      reverseScored: false,
      domain: "Knowledge",
    })),
    scoringMethod: "correct-count",
    bands: [
      band("Building knowledge", 0, 4, "watch", "Lots of new ground to cover — that's what the workshops are for."),
      band("Solid footing", 5, 7, "good", "You've got the basics down."),
      band("Strong", 8, 10, "good", "You know your money and your rights."),
    ],
    estimatedMinutes: 8,
    isActive: true,
    domains: ["Knowledge"],
  }),
  build({
    id: "leadership-inventory",
    title: "Leadership & Community Engagement Inventory",
    programId: "becoming",
    audience: "teen",
    instrumentType: "self-report",
    description: "Eight items on how you lead and show up for your community.",
    questions: leadershipItems.map((t, i) => q(`lci-${i + 1}`, i + 1, t, FREQ5, { domain: "Leadership" })),
    scoringMethod: "sum",
    bands: [
      band("Emerging", 8, 18, "watch", "Leadership is a skill — you're at the start of it."),
      band("Growing", 19, 30, "good", "You're stepping up more and more."),
      band("Leading", 31, 40, "good", "You lead and others follow your example."),
    ],
    estimatedMinutes: 4,
    isActive: true,
    domains: ["Leadership"],
  }),

  build({
    id: "feelings-checkin",
    title: "My Feelings Check-In",
    programId: "sprout-society",
    audience: "child",
    instrumentType: "self-report",
    description: "Tap the face that matches you. There are no wrong answers!",
    questions: feelingsItems.map((t, i) => q(`fci-${i + 1}`, i + 1, t, EMOJI5, { domain: "Feelings" })),
    scoringMethod: "sum",
    bands: [
      band("Growing", 8, 18, "good", "You're just starting to learn about your feelings. Keep going!"),
      band("Sprouting", 19, 30, "good", "You're getting good at noticing your feelings."),
      band("Blooming", 31, 40, "good", "Wow! You know your feelings really well."),
    ],
    estimatedMinutes: 3,
    isActive: true,
    childFriendly: true,
    domains: ["Feelings"],
  }),
  build({
    id: "coping-toolbox",
    title: "My Coping Toolbox",
    programId: "sprout-society",
    audience: "child",
    instrumentType: "self-report",
    description: "Which calm-down tools are in your toolbox?",
    questions: copingItems.map(([t, d], i) => q(`cop-${i + 1}`, i + 1, t, KID3, { domain: d })),
    scoringMethod: "sum",
    bands: [
      band("Growing", 8, 13, "good", "You're collecting your first tools. Nice start!"),
      band("Sprouting", 14, 19, "good", "Your toolbox is filling up."),
      band("Blooming", 20, 24, "good", "Your toolbox is full of great tools!"),
    ],
    estimatedMinutes: 3,
    isActive: true,
    childFriendly: true,
    domains: ["Deep breathing", "Asking for help", "Taking a break", "Using words", "Mindfulness", "Movement"],
  }),
  build({
    id: "how-i-see-myself",
    title: "How I See Myself",
    programId: "sprout-society",
    audience: "child",
    instrumentType: "self-report",
    description: "Six quick questions about you.",
    questions: selfViewItems.map((t, i) => q(`hsm-${i + 1}`, i + 1, t, SMILEY3, { domain: "Self-view" })),
    scoringMethod: "sum",
    bands: [
      band("Growing", 6, 10, "good", "You're learning what makes you special."),
      band("Sprouting", 11, 14, "good", "You see good things in yourself."),
      band("Blooming", 15, 18, "good", "You feel great about being you!"),
    ],
    estimatedMinutes: 2,
    isActive: true,
    childFriendly: true,
    domains: ["Self-view"],
  }),
  build({
    id: "my-goals",
    title: "My Goals",
    programId: "sprout-society",
    audience: "child",
    instrumentType: "goal-tracker",
    description: "Pick up to three goals and color in your progress each week.",
    questions: [],
    scoringMethod: "goal",
    bands: [band("In progress", 0, 100, "good", "Keep going — every week counts.")],
    estimatedMinutes: 3,
    isActive: true,
    childFriendly: true,
  }),
  build({
    id: "caregiver-feedback",
    title: "Caregiver Feedback Form",
    programId: "sprout-society",
    audience: "adult",
    instrumentType: "feedback",
    description: "Ten questions about what you're seeing at home. Completed by a parent or guardian.",
    questions: caregiverItems.map((t, i) => q(`cgf-${i + 1}`, i + 1, t, FREQ5, { domain: "Home observation" })),
    scoringMethod: "sum",
    bands: [
      band("Early days", 10, 24, "watch", "Change is still emerging at home."),
      band("Progressing", 25, 39, "good", "You're seeing steady growth at home."),
      band("Thriving", 40, 50, "good", "Strong growth showing up at home."),
    ],
    estimatedMinutes: 5,
    isActive: true,
    domains: ["Home observation"],
  }),

  build({
    id: "usda-6",
    title: "Household Food Security Survey (USDA 6-Item)",
    programId: "fresh-table",
    audience: "adult",
    instrumentType: "screener",
    description:
      "Six standard questions about food in your household over the last 12 months. This is our primary outcome measure.",
    questions: usdaItems.map((t, i) => q(`usda-${i + 1}`, i + 1, t, YESNO_USDA, { domain: "Food security" })),
    scoringMethod: "sum",
    bands: [
      band("High or marginal food security", 0, 1, "good", "Your household generally has enough food."),
      band("Low food security", 2, 4, "watch", "Your household is stretching food. We can help with that."),
      band("Very low food security", 5, 6, "alert", "Meals are being missed. Let's get you connected today."),
    ],
    estimatedMinutes: 4,
    isActive: true,
    domains: ["Food security"],
  }),
  build({
    id: "nutrition-confidence",
    title: "Nutrition Confidence & Knowledge Check",
    programId: "fresh-table",
    audience: "adult",
    instrumentType: "self-report",
    description: "Ten items on meal planning, label reading, budget shopping, and cooking confidence.",
    questions: nutritionItems.map(([t, d], i) => q(`nut-${i + 1}`, i + 1, t, CONF5, { domain: d })),
    scoringMethod: "sum",
    bands: [
      band("Building", 10, 24, "watch", "Good place to start — our nutrition sessions cover all of this."),
      band("Confident", 25, 39, "good", "You've got solid kitchen and shopping habits."),
      band("Very confident", 40, 50, "good", "You could teach this class."),
    ],
    estimatedMinutes: 5,
    isActive: true,
    domains: ["Meal planning", "Label reading", "Budget shopping", "Cooking confidence"],
  }),
  build({
    id: "phq-9",
    title: "PHQ-9 — Depression Check-In",
    programId: "fresh-table",
    audience: "adult",
    instrumentType: "screener",
    description: "Nine questions about the last two weeks.",
    questions: phqaItems.map((t, i) =>
      q(`phq9-${i + 1}`, i + 1, `Over the last 2 weeks, how often have you been bothered by: ${t}`, PHQ_OPTIONS, {
        domain: i === 8 ? "Safety" : "Mood",
      }),
    ),
    scoringMethod: "sum",
    bands: [
      band("Minimal", 0, 4, "good", "Very few low-mood symptoms right now."),
      band("Mild", 5, 9, "good", "Some symptoms present. Worth watching."),
      band("Moderate", 10, 14, "watch", "Symptoms are affecting daily life."),
      band("Moderately Severe", 15, 19, "alert", "Symptoms are frequent. Support is recommended."),
      band("Severe", 20, 27, "severe", "A heavy load right now. You deserve support today."),
    ],
    estimatedMinutes: 5,
    isActive: true,
    safetyItemId: "phq9-9",
    domains: ["Mood", "Safety"],
  }),
  build({
    id: "gad-7-adult",
    title: "GAD-7 — Anxiety Check-In (Adult)",
    programId: "fresh-table",
    audience: "adult",
    instrumentType: "screener",
    description: "Seven questions about worry over the last two weeks.",
    questions: gad7Items.map((t, i) =>
      q(`gad7a-${i + 1}`, i + 1, `Over the last 2 weeks, how often have you been bothered by: ${t}`, PHQ_OPTIONS, {
        domain: "Anxiety",
      }),
    ),
    scoringMethod: "sum",
    bands: [
      band("Minimal", 0, 4, "good", "Very little anxiety showing up."),
      band("Mild", 5, 9, "good", "Some worry present."),
      band("Moderate", 10, 14, "watch", "Worry is affecting your days."),
      band("Severe", 15, 21, "severe", "Anxiety is heavy right now."),
    ],
    estimatedMinutes: 4,
    isActive: true,
    domains: ["Anxiety"],
  }),
  build({
    id: "caregiver-stress",
    title: "Caregiver Stress & Support Check",
    programId: "sprout-society",
    audience: "adult",
    instrumentType: "self-report",
    description: "Ten items on stress load, social support, respite, and supporting your child.",
    questions: caregiverStressItems.map(([t, d], i) =>
      q(`cgs-${i + 1}`, i + 1, t, FREQ5, { domain: d, reverseScored: d === "Stress load" }),
    ),
    scoringMethod: "sum-reverse",
    bands: [
      band("Stretched thin", 10, 24, "alert", "You're carrying a lot with limited support."),
      band("Managing", 25, 39, "watch", "You're holding steady with some gaps."),
      band("Well supported", 40, 50, "good", "You have good support around you."),
    ],
    estimatedMinutes: 5,
    isActive: true,
    domains: ["Stress load", "Social support", "Respite access", "Supporting my child"],
  }),
  build({
    id: "workshop-reflection",
    title: "Workshop Reflection",
    programId: "sprout-society",
    audience: "adult",
    instrumentType: "feedback",
    description: "A short post-workshop reflection.",
    questions: [
      q("wsr-1", 1, "How useful was today's workshop?", [
        { label: "Not useful", value: 1 },
        { label: "Slightly useful", value: 2 },
        { label: "Useful", value: 3 },
        { label: "Very useful", value: 4 },
        { label: "Extremely useful", value: 5 },
      ]),
      q("wsr-2", 2, "How much more confident do you feel about this topic?", CONF5),
      {
        id: "wsr-3",
        order: 3,
        text: "What is one thing you're taking away from today?",
        type: "text",
        options: [],
        required: false,
        reverseScored: false,
      },
    ],
    scoringMethod: "sum",
    bands: [
      band("Low value", 2, 4, "watch", "This session missed the mark for you."),
      band("Helpful", 5, 7, "good", "The session helped."),
      band("Very helpful", 8, 10, "good", "The session landed well."),
    ],
    estimatedMinutes: 2,
    isActive: true,
  }),
];

export const assessmentById = (id: string) => assessments.find((a) => a.id === id);

export const SAFETY_DISCLAIMER =
  "These check-ins help us understand how you're doing and improve our programs. They are not a medical diagnosis. If you need clinical care, we can connect you with a licensed provider.";

export const SAFETY_MESSAGE =
  "Thanks for being honest. Some of your answers tell us you could use extra support right now, and that's okay. Here's who you can reach.";
